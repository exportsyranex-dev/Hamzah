# Excel Quantity Assistant

A local-first, deterministic engineering quantity takeoff, validation,
ingestion, aggregation, comparison, costing, and reporting application,
with a real Streamlit UI on top. Built against the Master Development
Prompt V2.0 spec (referenced below as "the spec", section numbers as "§N").

**Status: functionally complete for the core workflow**, including Profile
persistence across sessions, Schema Drift protection, optional Costing, and
optional/gracefully-degrading AI. Not yet packaged as a desktop app/EXE —
see "What's left before packaging" at the end.

---

## 1. How to run the application today

```bash
pip install -r requirements.txt
streamlit run app/ui/streamlit_app.py
```

This opens the UI in your browser (Streamlit's default: http://localhost:8501).
Everything runs locally — no internet connection is required or used by the
pipeline itself (§5 Local-First). The Profile database and generated
reports are stored under your OS's normal per-user app-data folder — never
inside the installed application's own folder (important once this is
packaged: on Windows, an app installed under `Program Files` typically
cannot write next to itself without admin rights).

> **Note on this delivery environment:** the sandbox this project was built
> in has no internet access, so `streamlit` (and `pytest`) could not
> actually be `pip install`-ed here, and no real browser was available to
> click through the UI. **This is stated plainly, not glossed over.**
> What *was* possible, and was done: every line of `app/ui/streamlit_app.py`
> was exercised by calling its real `main()` function with a fake
> `streamlit` widget layer standing in for the browser (see
> `tests/integration/test_streamlit_app_smoke.py` and
> `tests/fixtures/fake_streamlit.py`) — the business logic, controller
> calls, and session-state transitions are real and tested; the actual
> browser rendering is not. **A real click-through on a machine with
> internet access and a browser is still required before packaging.**

---

## 2. Using the UI

1. **Upload a file.** Under "1. Choose an Excel file", pick your `.xlsx`
   quantities file. Optionally also upload a "Reference file" — if you do,
   the report will include a full comparison (§28) against it.
2. **File validation happens automatically.** Empty, corrupt, wrong-format,
   or unreadable files produce a plain-language error immediately — never
   a Python traceback.
3. **Profile Matching happens automatically (§15).** The app fingerprints
   the file's structure (§14) and checks it against previously saved
   Profiles:
   - **Exact one match** → applied automatically, no re-mapping needed.
   - **Multiple matches** → you pick which saved Profile to use from a list.
   - **No match** → you map columns by hand (next step), and afterward you
     can name and save that mapping as a Profile so future uploads of the
     same layout skip this step entirely and gain Schema Drift protection.
4. **Confirm the column mapping** (only shown when no Profile matched).
   The app suggests a mapping from your file's actual headers using
   deterministic name-matching (§37 — never AI, never auto-applied without
   your review). Adjust any dropdown, and pick each dimension column's
   unit. Ready Quantity is m³-only in this version (§10).
5. **(Optional) Advanced settings:** waste %, comparison threshold %,
   mismatch tolerance %, and costing (a currency + a unit rate per Element
   Type — leave a rate blank to skip costing that type; §35/§36).
6. **Click "Process file".** A spinner shows while validation → Schema
   Drift check → ingestion → quantity engine → aggregation → comparison →
   costing → report-building run for real, against your actual file.
7. **Read the results summary** and, if this was a fresh mapping,
   **optionally save it as a Profile** for next time.
8. **Download the Excel report and/or the PDF report.**
9. **Click "Process another file"** to reset the whole form (including the
   file picker itself) without restarting the app.

---

## 3. Required Excel format

- File must be a real `.xlsx` workbook (not `.xls`, not a renamed CSV).
- Row 1 of each sheet is treated as the header row.
- At minimum, an **Element Type** column is required, and either:
  - a **Ready Quantity** column (in m³), or
  - **Length / Width / Height** columns (in your chosen unit), or both
    (both is fine — the app cross-checks them and warns if they disagree
    by more than your configured tolerance, §22 State A).
- **Floor**: either a Floor column, or — if your workbook has one sheet
  per floor — no Floor column at all (the sheet name becomes the floor).
  A *single-sheet* workbook with *no* Floor column is rejected up front
  with a clear message (§20).
- **Item Code** is optional unless you choose "Item Code as comparison
  key", in which case it's required per row.
- V1 element types: `COLUMN`, `BEAM`, `SLAB`, `FOUNDATION` — all computed
  as **rectangular prisms**. A circular column mapped as `COLUMN` will get
  a silently wrong volume; this is a disclosed V1 limitation (§18), not a
  bug, and it's repeated verbatim in every report.
- **Once you save a Profile for a template, re-uploading a file with a
  different structure (missing/renamed/new columns, or a numeric column
  now full of text) is rejected up front with a Schema Drift message
  (§16)** rather than silently mis-processed.

---

## 4. What the errors and warnings mean

| You'll see | Meaning |
|---|---|
| **File cannot be processed** | Wrong extension, empty, or corrupt file (§13). Nothing was read. |
| **This file's structure no longer matches the saved template** | Schema Drift (§16): column(s) missing, new unexpected column(s), a likely rename, or a column's data no longer looks like the right type. **The whole file is stopped on purpose** — no partial/guessed processing. The message lists exactly which columns and what to fix. Only triggers for a file whose fingerprint matches a *saved* Profile — a brand-new template you're mapping for the first time has no baseline to drift from yet. |
| **A row is excluded / errored** | That specific row had a real problem — invalid dimension, invalid or missing Ready Quantity with no usable dimensions either, unresolved Floor, etc. (§21/§22, States C/D). Only that row is skipped; the rest of the file still processes. Full detail is in the Excel report's "الأخطاء والاستثناءات" sheet. |
| **A row has a warning** | The row still produced a quantity, but something is worth a second look — e.g. Ready Quantity and the row's own dimensions disagree by more than the tolerance, or a slab is unusually thin (§22/§30). Detail is in the Audit Trail sheet. |
| **COST_NOT_AVAILABLE** on a group | Costing was enabled but no unit rate was entered for that Element Type/Item Code — the app never guesses a rate (§36). |
| **CURRENCY_NOT_DEFINED** | Unit rates were entered but no currency was set — costing is skipped for the whole run rather than assuming a currency (§36). |
| **"Processing failed unexpectedly"** | An unanticipated error. You'll never see a raw traceback in the main message; a "Technical details" expander (developer-facing, exception class + message only, still no stack trace) is available if you need to report a bug. |

---

## 5. What the Excel and PDF reports contain

**Excel (`Quantity_Report_<timestamp>.xlsx`)** — 5 sheets, exactly per §31:

1. **الكميات المجمعة** (Aggregated Quantities) — one row per Floor×Element
   Type (or per Item Code), Net Quantity, BOQ-with-waste, DIRECT/CALCULATED
   source mix, aggregate-level warnings, and — if costing is configured —
   Estimated Cost + a Cost Note column.
2. **المقارنة** (Comparison) — only populated if a reference file was
   given; otherwise says so plainly. Shows MATCHED / NEW_ITEM /
   REMOVED_ITEM per key, with percentage difference and OK/OVER_THRESHOLD.
3. **الأخطاء والاستثناءات** (Errors & Exceptions) — every row-level error,
   from both files, with sheet/row/field/value/code/message.
4. **Audit Trail** — every row (valid or not) from both files: original
   values, normalized values, units, formula used, quantity, DIRECT vs
   CALCULATED, warnings, and a plain validation status.
5. **Run Metadata** — engine/taxonomy version, profile name, all the
   thresholds used, filenames, and the full §34 mandatory limitations text
   (verbatim, every run).

**PDF (`Quantity_Report_<timestamp>.pdf`)** — an executive summary: totals,
warnings/errors counts, comparison summary + over-threshold table, top
aggregated rows, a costing summary (if configured), an AI-executive-summary
section, and the same §34 disclosures verbatim.

Filenames always include a timestamp and never overwrite an existing file
(§32) — a collision gets `_001`, `_002`, etc.

---

## 6. Profile persistence (§15/§17) — fully wired, not optional

Saved Profiles (column mapping, units, thresholds, and the Schema Drift
baseline) live in a local SQLite database at your OS's per-user app-data
location (`app/config/settings.py` — Windows `%APPDATA%`, macOS
`~/Library/Application Support`, Linux `$XDG_DATA_HOME` or `~/.local/share`,
under `ExcelQuantityAssistant/`). This is core to the original spec's
Canonical Data Flow (§7: Fingerprint → Profile Matching → Manual Mapping →
Save Profile), not an optional enhancement — so it's implemented and used
by the UI on every upload, not just available as a library function.

## 7. AI is fully optional — the core pipeline never depends on it

`app/reporting/report_service.run_full_report` accepts an optional
`ai_provider` and an optional `ai_executive_summary_text`. With neither
supplied (the UI's current default — there's no AI provider configuration
screen yet), the PDF shows the exact fallback text `"Executive Summary
unavailable."` (§40) and every other part of the report is unaffected.
If a provider IS supplied and it raises (network error, timeout, bad key,
anything), the failure is caught and the same fallback text is used —
report generation itself can never fail because of AI (§43). This is
verified by `tests/integration/test_ai_optionality.py`, including a test
that the *engineering numbers themselves* are byte-for-byte identical with
or without AI involved.

---

## 8. Running the tests

```bash
pip install -r requirements.txt
pytest -q
```

**143 tests, 0 failures.** Covers everything from the previous passes plus,
this round:

- **Streamlit UI smoke tests** (`tests/integration/test_streamlit_app_smoke.py`):
  the real `app/ui/streamlit_app.py` `main()` function, driven by a fake
  widget layer (`tests/fixtures/fake_streamlit.py`) since `streamlit`
  itself can't be installed in this sandbox — full successful run + save
  Profile, a second independent "session" auto-applying a previously saved
  Profile, an empty file producing a friendly error, Schema Drift firing
  even on an auto-applied Profile (same column names, drifted data), and
  "Process another file" resetting session state and the uploader itself.
  **This proves the UI's own code is exception-free and correctly wired —
  it does not replace an actual browser click-through.**
- **Profile persistence** end-to-end: fingerprinting, AUTO_APPLY /
  USER_MUST_SELECT / OPEN_MANUAL_MAPPING, save-then-reload.
- **Cross-platform path resolution** (`tests/unit/test_settings_paths.py`):
  Windows `%APPDATA%`, macOS `Application Support`, Linux `XDG_DATA_HOME`,
  and a structural test that the DB/reports paths can never land inside
  the installed package directory.
- **AI optionality**: no provider, a provider that raises, a provider that
  works, explicit text overriding a provider, and identical quantities
  regardless.
- Everything from before: all 4 Ready-Quantity states, both Floor
  Resolution cases, Schema Drift (missing/new/renamed/type-drift columns)
  through the real `run_full_report` entrypoint, Costing (rate resolution,
  missing rate/currency), all 3 Comparison states, real Excel/PDF file
  generation re-opened from disk, and the `float`/AI-isolation regressions.

(This sandbox has no network access, so `pytest` itself couldn't be
installed here either. All 143 tests were verified with
`run_tests_offline.py`, a small script that discovers and runs the exact
same `test_*.py` files using a local `pytest.raises`/`pytest.mark.parametrize`
shim. That shim is **not part of the delivered project** — delete
`run_tests_offline.py` and just run `pytest -q` in your own environment.)

---

## 9. Architecture map

```
app/
├── ui/                    streamlit_app.py (real UI) + controller.py
│                          (UI-agnostic, no Streamlit import — the ONE
│                          code path both the UI and its tests call).
├── ingestion/             File validation, raw Excel reading, row mapping,
│                          Schema Drift detection.
├── validation/            Row validation, Floor Resolution.
├── quantity_engine/       Ready-Quantity 4-state engine.
├── rules_engine/          Row-level and aggregate-level engineering rules.
├── aggregation/           Central-Key-Builder-based grouping.
├── comparison/            3-state comparison engine.
├── costing/               Estimated Cost = Net Quantity × Unit Rate.
├── reporting/             Excel (5 sheets) + PDF report builders, file
│                          naming, mandatory disclosures, and
│                          report_service.run_full_report() — the single
│                          end-to-end orchestrator the UI calls.
├── profiles/, database/   SQLite Profile storage (fingerprint matching,
│                          Schema Drift baseline), at a cross-platform
│                          per-user data path (app/config/settings.py).
├── ai/                    Two isolated AI roles (executive summary text
│                          only; a design-time-only UI copy advisor) —
│                          both fully optional, both fail gracefully.
├── taxonomy/, units/      Type→formula registry, unit conversion.
└── config/                Decimal precision, versioning, error/warning
                           codes, cross-platform app-data paths.
```

Every number shown in the UI or written into a report traces back to
`RowResult` / `AggregatedGroup` / `ComparisonRow` / `CostResult` objects
produced by the deterministic pipeline — the UI and its controller never
compute or invent a number themselves (§2, §6).

---

## 10. Known limitations (unchanged, disclosed everywhere in the app)

- Rectangular-prism-only geometry (no circular/tapered columns) — §18/§49.
- Ready Quantity is m³ only, never converted from L/ft³/cm³ — §10/§49.
- Waste % is one global value per run, not per Floor/Type — §25/§49.
- Excel formulas: cached values only, never recalculated — §12/§49.
- Single local user/session assumption for the SQLite profile DB — §49
  (SQLite WAL mode is enabled as a mitigation, not a full multi-user
  concurrency guarantee).
- Schema Drift's "renamed column" hint is a heuristic (equal-count
  missing/new pairing) — it's a hint in the message, not authoritative;
  the underlying missing/new column lists are always exact.
- The UI has no screen to configure a live AI provider yet (§7 above) —
  the option exists in `report_service`/`controller` but isn't exposed as
  a UI control. This does not block anything; it's a "not yet offered"
  feature, not a broken one.
- Cross-profile comparison consistency check (§27) exists as a standalone
  function (`app/services/key_builder.check_profile_consistency`) but
  isn't called automatically when the Reference and New files use
  different Profiles.
- **The Streamlit UI has not been clicked through in a real browser** —
  see §1's note. Its logic is tested; its rendering is not.

## 11. What's left before packaging (EXE/Installer)

- **A real click-through on Windows** with internet access to install
  `streamlit`, actually launch `streamlit run app/ui/streamlit_app.py`,
  and use it in a browser. This is the single biggest remaining unknown —
  everything else in this list is secondary to it.
- Decide whether to expose AI provider configuration in the UI, or leave
  it as a code-level option (current state) for this version.
- Optionally wire the cross-profile comparison consistency check (§27)
  into the UI's "pick a Reference file" flow if Reference and New end up
  resolving to different saved Profiles.
