"""
Global application configuration.

§8  Numerical Accuracy    - Decimal precision is set once, here, at process start.
§17 engine_version / taxonomy_version - stamped into every processing_log row and
    into Report Sheet 5 (Run Metadata) for reproducibility.
§28 Comparison default threshold (5.0%).
§22 Ready-Quantity vs dimension-based mismatch tolerance default (2.0%).

Nothing in this module performs engineering calculations. It only supplies
constants that other deterministic modules read.
"""
from __future__ import annotations

import decimal
import os
import sys
from dataclasses import dataclass, field
from pathlib import Path

# ---------------------------------------------------------------------------
# §8 — Decimal precision. Must be set before any Decimal arithmetic happens.
# ---------------------------------------------------------------------------
DECIMAL_PRECISION = 28
decimal.getcontext().prec = DECIMAL_PRECISION

# ---------------------------------------------------------------------------
# Versioning (§17, §31 Sheet 5, §51 Auditability)
# ---------------------------------------------------------------------------
ENGINE_VERSION = "1.0.0"
TAXONOMY_VERSION = "1.0.0"

# ---------------------------------------------------------------------------
# Defaults (overridable per-Profile — these are only the system defaults)
# ---------------------------------------------------------------------------
DEFAULT_COMPARISON_THRESHOLD_PERCENTAGE = decimal.Decimal("5.0")
DEFAULT_MISMATCH_TOLERANCE_PERCENTAGE = decimal.Decimal("2.0")
DEFAULT_WASTE_PERCENTAGE = decimal.Decimal("0.0")
DEFAULT_DECIMAL_DISPLAY_PLACES = 4  # display/report rounding only, never internal (§8)

# ---------------------------------------------------------------------------
# Paths.
#
# Deliberately NOT relative to the installed application directory
# (Path(__file__)-based). A packaged desktop app is very often installed
# somewhere the OS does not let a normal user write to (e.g. Program Files
# on Windows without admin rights), so writing the Profile database or
# generated reports "next to the app" is a real, common failure mode once
# this is packaged (§5 Local-First still applies -- this is local storage,
# just in the OS's normal per-user data location instead of the install
# folder). This uses only the standard library (os/sys/pathlib) -- no new
# dependency such as `platformdirs` is introduced for this.
# ---------------------------------------------------------------------------
APP_DIR_NAME = "ExcelQuantityAssistant"


def _default_app_data_dir() -> Path:
    if sys.platform == "win32":
        base = os.environ.get("APPDATA") or str(Path.home() / "AppData" / "Roaming")
        return Path(base) / APP_DIR_NAME
    if sys.platform == "darwin":
        return Path.home() / "Library" / "Application Support" / APP_DIR_NAME
    base = os.environ.get("XDG_DATA_HOME") or str(Path.home() / ".local" / "share")
    return Path(base) / APP_DIR_NAME


APP_DATA_DIR = _default_app_data_dir()
DB_PATH = APP_DATA_DIR / "data" / "profiles.db"
REPORTS_DIR = APP_DATA_DIR / "reports"


@dataclass(frozen=True)
class AppConfig:
    """Immutable snapshot of runtime configuration, injected into Services.

    Kept deliberately tiny and dependency-free (§6: business logic must not
    depend on Streamlit; this must not depend on anything AI- or UI-related).
    """

    engine_version: str = ENGINE_VERSION
    taxonomy_version: str = TAXONOMY_VERSION
    decimal_precision: int = DECIMAL_PRECISION
    db_path: Path = field(default_factory=lambda: DB_PATH)
    reports_dir: Path = field(default_factory=lambda: REPORTS_DIR)


def get_default_config() -> AppConfig:
    return AppConfig()
