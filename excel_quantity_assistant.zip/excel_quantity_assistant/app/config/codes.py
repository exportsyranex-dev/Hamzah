"""
Central registry of every deterministic error/warning code referenced in the
spec (§29, §51: "every error/warning code referenced in this document has a
corresponding, tested code path"). Using an Enum instead of raw strings means
a typo becomes an ImportError/AttributeError at dev time, not a silent bug.
"""
from __future__ import annotations

from enum import Enum


class ErrorCode(str, Enum):
    # File / ingestion (§13, §16)
    UNSUPPORTED_FILE_FORMAT = "UNSUPPORTED_FILE_FORMAT"
    EMPTY_FILE = "EMPTY_FILE"
    CORRUPT_WORKBOOK = "CORRUPT_WORKBOOK"
    NO_USABLE_DATA = "NO_USABLE_DATA"
    SCHEMA_DRIFT_DETECTED = "SCHEMA_DRIFT_DETECTED"

    # Profiles (§15, §20)
    PROFILE_INVALID_FLOOR_CONFIG = "PROFILE_INVALID_FLOOR_CONFIG"
    FLOOR_UNRESOLVED = "FLOOR_UNRESOLVED"

    # Units (§10)
    UNSUPPORTED_UNIT = "UNSUPPORTED_UNIT"

    # Taxonomy (§18)
    UNKNOWN_ELEMENT_TYPE = "UNKNOWN_ELEMENT_TYPE"

    # Row validation (§21, §24)
    INVALID_NUMERIC_VALUE = "INVALID_NUMERIC_VALUE"
    INVALID_DIMENSION_VALUE = "INVALID_DIMENSION_VALUE"
    MISSING_REQUIRED_FIELD = "MISSING_REQUIRED_FIELD"
    INVALID_ITEM_CODE = "INVALID_ITEM_CODE"

    # Ready Quantity states C & D (§22)
    INVALID_READY_QUANTITY = "INVALID_READY_QUANTITY"
    NO_QUANTITY_SOURCE_AVAILABLE = "NO_QUANTITY_SOURCE_AVAILABLE"

    # Costing (§36)
    COST_NOT_AVAILABLE = "COST_NOT_AVAILABLE"
    CURRENCY_NOT_DEFINED = "CURRENCY_NOT_DEFINED"


class WarningCode(str, Enum):
    DUPLICATE_ROW = "DUPLICATE_ROW"
    READY_QUANTITY_CALCULATED_MISMATCH = "READY_QUANTITY_CALCULATED_MISMATCH"
    ENGINEERING_CONSTRAINT_WARNING = "ENGINEERING_CONSTRAINT_WARNING"
    PROFILE_COMPARISON_CONSISTENCY_WARNING = "PROFILE_COMPARISON_CONSISTENCY_WARNING"


class QuantitySource(str, Enum):
    """§22 — where a row's Net Quantity came from."""

    DIRECT = "DIRECT"
    CALCULATED = "CALCULATED"


class ComparisonStatus(str, Enum):
    """§28 — the 3-state comparison model (replaces the old contradictory 2-rule draft)."""

    MATCHED = "MATCHED"
    NEW_ITEM = "NEW_ITEM"
    REMOVED_ITEM = "REMOVED_ITEM"


class ComparisonResult(str, Enum):
    OK = "OK"
    OVER_THRESHOLD = "OVER_THRESHOLD"


class SheetStructureType(str, Enum):
    SINGLE_SHEET = "single_sheet"
    SHEET_PER_FLOOR = "sheet_per_floor"
