"""
Section 15 -- Profile Matching.
Section 20 -- Profile-save validation gate: a profile cannot be saved if
sheet_structure_type = single_sheet AND no Floor column is defined -- that
configuration has no possible floor source. Rejected HERE, at save time,
with PROFILE_INVALID_FLOOR_CONFIG -- never discovered later at runtime
(app/validation/floor_resolution.py asserts on this instead of raising a
normal error, precisely because it should be unreachable).
"""
from __future__ import annotations

import sqlite3
from dataclasses import dataclass
from datetime import datetime, timezone
from decimal import Decimal
from enum import Enum
from typing import Any, Optional

from app.config.codes import SheetStructureType
from app.database import db


class ProfileMatchOutcome(str, Enum):
    AUTO_APPLY = "AUTO_APPLY"
    USER_MUST_SELECT = "USER_MUST_SELECT"
    OPEN_MANUAL_MAPPING = "OPEN_MANUAL_MAPPING"


class ProfileInvalidFloorConfigError(Exception):
    def __init__(self, detail: str = ""):
        self.code = "PROFILE_INVALID_FLOOR_CONFIG"
        msg = "PROFILE_INVALID_FLOOR_CONFIG: single_sheet structure with no Floor column has no possible floor source."
        if detail:
            msg += f" ({detail})"
        super().__init__(msg)


@dataclass
class ProfileMatchResult:
    outcome: ProfileMatchOutcome
    matches: list[sqlite3.Row]


def match_profiles(conn: sqlite3.Connection, fingerprint_hash: str) -> ProfileMatchResult:
    """Section 15 profile matching.

    - Exactly one Profile matches -> AUTO_APPLY.
    - Multiple Profiles match -> USER_MUST_SELECT. No AI selection, ever.
    - No Profile matches -> OPEN_MANUAL_MAPPING.
    """
    matches = db.find_profiles_by_fingerprint(conn, fingerprint_hash)
    if len(matches) == 1:
        return ProfileMatchResult(ProfileMatchOutcome.AUTO_APPLY, matches)
    if len(matches) > 1:
        return ProfileMatchResult(ProfileMatchOutcome.USER_MUST_SELECT, matches)
    return ProfileMatchResult(ProfileMatchOutcome.OPEN_MANUAL_MAPPING, [])


def validate_floor_config_for_save(
    *, sheet_structure_type: SheetStructureType, floor_column_defined: bool
) -> None:
    """Raises ProfileInvalidFloorConfigError if the combination is impossible.

    This is the ONLY place this check should run. Call it before ever
    persisting a profile (see save_profile below).
    """
    if sheet_structure_type == SheetStructureType.SINGLE_SHEET and not floor_column_defined:
        raise ProfileInvalidFloorConfigError(
            "sheet_structure_type=single_sheet requires an explicit Floor column."
        )


def save_profile(conn: sqlite3.Connection, *, name: str, fingerprint_hash: str,
                  column_mapping: dict[str, Any], sheet_structure_type: SheetStructureType,
                  unit_per_field: dict[str, str], waste_percentage: Decimal,
                  decimal_precision: int, floor_synonyms: dict[str, str],
                  type_formula_map: dict[str, str], item_code_is_comparison_key: bool,
                  comparison_threshold_percentage: Decimal,
                  mismatch_tolerance_percentage: Decimal,
                  floor_column_defined: bool,
                  expected_columns: Optional[dict[str, list[str]]] = None) -> int:
    """Validate-then-persist. Raises ProfileInvalidFloorConfigError before
    touching the database if the floor configuration is impossible (Section 20).

    expected_columns (Section 16): the {sheet_name: [column_names]} baseline
    captured from the workbook this profile was created against, used later
    by app.ingestion.schema_drift to detect missing/new/renamed columns.
    Optional so profiles created without going through the ingestion
    pipeline (e.g. hand-authored in a test) don't have to supply it --
    Schema Drift simply isn't checked for such a profile until it is.
    """
    validate_floor_config_for_save(
        sheet_structure_type=sheet_structure_type,
        floor_column_defined=floor_column_defined,
    )

    now = datetime.now(timezone.utc).isoformat()
    profile = {
        "name": name,
        "fingerprint_hash": fingerprint_hash,
        "column_mapping_json": db.dumps(column_mapping),
        "sheet_structure_type": sheet_structure_type.value,
        "unit_per_field_json": db.dumps(unit_per_field),
        "waste_percentage": str(waste_percentage),
        "decimal_precision": decimal_precision,
        "floor_synonyms_json": db.dumps(floor_synonyms),
        "type_formula_map_json": db.dumps(type_formula_map),
        "item_code_is_comparison_key": int(item_code_is_comparison_key),
        "comparison_threshold_percentage": str(comparison_threshold_percentage),
        "mismatch_tolerance_percentage": str(mismatch_tolerance_percentage),
        "expected_columns_json": db.dumps(expected_columns) if expected_columns is not None else None,
        "created_at": now,
        "updated_at": now,
    }
    return db.insert_profile(conn, profile)


def load_expected_columns(row: sqlite3.Row) -> Optional[dict[str, list[str]]]:
    """Deserialize a template_profiles row's expected_columns_json, if set."""
    raw = row["expected_columns_json"] if "expected_columns_json" in row.keys() else None
    if not raw:
        return None
    return db.loads(raw)
