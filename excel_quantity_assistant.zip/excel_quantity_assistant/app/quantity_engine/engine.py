"""
Section 22 -- Ready Quantity Rule, 4 states.
Section 23 -- Quantity Engine (formula resolution + Decimal calculation + audit trace).

State A -- Ready Quantity valid (numeric > 0, unit m3): SOURCE = DIRECT.
           Cross-check: if dimensions are ALSO present and fully valid, also
           compute the dimension-based volume for comparison only (never
           stored). If the relative difference exceeds
           mismatch_tolerance_percentage, emit WARNING:
           READY_QUANTITY_CALCULATED_MISMATCH recording both values. The
           final stored quantity remains the DIRECT value regardless.
State B -- Ready Quantity absent, dimensions valid: SOURCE = CALCULATED.
State C -- Ready Quantity present but invalid (zero/negative/bad unit/non-
           numeric): ERROR: INVALID_READY_QUANTITY. Never falls back to
           dimensions. Row excluded from quantities.
State D -- Ready Quantity absent AND dimensions missing/invalid:
           ERROR: NO_QUANTITY_SOURCE_AVAILABLE. Row excluded.

This module never rounds (Section 8) and never guesses a missing value.
"""
from __future__ import annotations

from decimal import Decimal
from typing import Mapping, Optional

from app.config.codes import ErrorCode, QuantitySource, WarningCode
from app.models.domain import QuantityCalculationTrace, RowValidationIssue
from app.taxonomy.formula_registry import get_formula


def _pct_diff(direct: Decimal, calculated: Decimal) -> Decimal:
    # direct is guaranteed > 0 here (State A precondition), so division is safe.
    return abs(direct - calculated) / direct * Decimal("100")


def resolve_ready_quantity_state(
    *,
    sheet: str,
    row: int,
    ready_quantity_present: bool,
    ready_quantity_valid: bool,
    ready_quantity_m3: Optional[Decimal],
    dimensions_valid: bool,
    dimensions_m: Mapping[str, Decimal],
    formula_id: Optional[str],
    mismatch_tolerance_percentage: Decimal,
) -> tuple[Optional[QuantityCalculationTrace], Optional[RowValidationIssue], list[RowValidationIssue]]:
    """Implements the Section 22 4-state decision table for one row.

    Returns (trace_or_None, error_or_None, warnings).
    Exactly one of (trace, error) is non-None on return.
    """
    warnings: list[RowValidationIssue] = []

    # --- State C: Ready Quantity present but invalid -----------------------
    if ready_quantity_present and not ready_quantity_valid:
        error = RowValidationIssue(
            sheet=sheet,
            row=row,
            field="Ready Quantity",
            value=ready_quantity_m3,
            code=ErrorCode.INVALID_READY_QUANTITY,
            message="Ready Quantity is present but invalid (zero, negative, or bad unit); "
            "never falling back to dimensions (Section 22 State C).",
        )
        return None, error, warnings

    # --- State A: Ready Quantity valid --------------------------------------
    if ready_quantity_present and ready_quantity_valid:
        assert ready_quantity_m3 is not None
        trace = QuantityCalculationTrace(
            input_values={"ready_quantity_m3": ready_quantity_m3},
            normalized_values_m={},
            formula_id=None,
            result_m3=ready_quantity_m3,
            source=QuantitySource.DIRECT,
        )

        if dimensions_valid and formula_id is not None:
            formula = get_formula(formula_id)
            calculated = formula(**dimensions_m)
            diff_pct = _pct_diff(ready_quantity_m3, calculated)
            if diff_pct > mismatch_tolerance_percentage:
                warnings.append(
                    RowValidationIssue(
                        sheet=sheet,
                        row=row,
                        field="Ready Quantity",
                        value={
                            "direct_m3": str(ready_quantity_m3),
                            "calculated_m3": str(calculated),
                            "difference_percentage": str(diff_pct),
                        },
                        code=WarningCode.READY_QUANTITY_CALCULATED_MISMATCH,
                        message=(
                            f"DIRECT value {ready_quantity_m3} m3 differs from "
                            f"dimension-based {calculated} m3 by {diff_pct:.4f}% "
                            f"(tolerance {mismatch_tolerance_percentage}%). "
                            "Stored quantity remains the DIRECT value."
                        ),
                    )
                )
        return trace, None, warnings

    # --- State B: Ready Quantity absent, dimensions valid -------------------
    if not ready_quantity_present and dimensions_valid and formula_id is not None:
        formula = get_formula(formula_id)
        calculated = formula(**dimensions_m)
        trace = QuantityCalculationTrace(
            input_values=dict(dimensions_m),
            normalized_values_m=dict(dimensions_m),
            formula_id=formula_id,
            result_m3=calculated,
            source=QuantitySource.CALCULATED,
        )
        return trace, None, warnings

    # --- State D: neither a valid Ready Quantity nor valid dimensions -------
    error = RowValidationIssue(
        sheet=sheet,
        row=row,
        field="Ready Quantity / Dimensions",
        value=None,
        code=ErrorCode.NO_QUANTITY_SOURCE_AVAILABLE,
        message="No Ready Quantity and no valid dimensions -- row has no possible quantity source (Section 22 State D).",
    )
    return None, error, warnings
