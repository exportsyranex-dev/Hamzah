"""
Section 21 -- Row Validation.
Section 24 -- Zero / Negative Dimension Policy.

Validates one row at a time. A bad row never stops the whole workbook (only
file-level corruption or schema drift do, per Section 16). Every failure
produces a RowValidationIssue with an ErrorCode -- never a silent skip.
"""
from __future__ import annotations

from decimal import Decimal, InvalidOperation
from typing import Optional

from app.config.codes import ErrorCode
from app.models.domain import RowValidationIssue
from app.units.registry import UnsupportedUnitError, is_supported_linear_unit, validate_ready_quantity_unit


def parse_numeric(raw_value: object) -> Optional[Decimal]:
    """Parse a raw cell value into a Decimal, or None if it isn't numeric.

    Never uses float() as an intermediate step (Section 8) -- goes straight
    from the original representation to Decimal via str().
    """
    if raw_value is None:
        return None
    if isinstance(raw_value, Decimal):
        return raw_value
    if isinstance(raw_value, bool):  # bool is an int subclass -- reject explicitly
        return None
    if isinstance(raw_value, int):
        return Decimal(raw_value)
    if isinstance(raw_value, float):
        # A float already in memory (e.g. from openpyxl) is converted via
        # its repr, which is the closest we can get to "what the user
        # typed" without re-reading the original string -- still routed
        # through Decimal immediately and never used in arithmetic as float.
        return Decimal(repr(raw_value))
    text = str(raw_value).strip()
    if text == "":
        return None
    try:
        return Decimal(text)
    except InvalidOperation:
        return None


def validate_required_dimension(
    *, sheet: str, row: int, field_name: str, raw_value: object, unit: Optional[str]
) -> tuple[Optional[Decimal], list[RowValidationIssue]]:
    """Validate one required numeric dimension field (Section 21, Section 24).

    Returns (parsed_value_or_None, issues). If issues is non-empty the field
    is invalid and the caller must not use parsed_value_or_None.
    """
    issues: list[RowValidationIssue] = []

    if raw_value is None or str(raw_value).strip() == "":
        issues.append(
            RowValidationIssue(
                sheet=sheet,
                row=row,
                field=field_name,
                value=raw_value,
                code=ErrorCode.MISSING_REQUIRED_FIELD,
                message=f"'{field_name}' is required but missing",
            )
        )
        return None, issues

    parsed = parse_numeric(raw_value)
    if parsed is None:
        issues.append(
            RowValidationIssue(
                sheet=sheet,
                row=row,
                field=field_name,
                value=raw_value,
                code=ErrorCode.INVALID_NUMERIC_VALUE,
                message=f"'{field_name}' value '{raw_value}' is not numeric",
            )
        )
        return None, issues

    if unit is None or not is_supported_linear_unit(unit):
        issues.append(
            RowValidationIssue(
                sheet=sheet,
                row=row,
                field=field_name,
                value=unit,
                code=ErrorCode.UNSUPPORTED_UNIT,
                message=f"'{field_name}' unit '{unit}' is not supported",
            )
        )
        return None, issues

    # Section 24 -- zero / negative dimension policy: V1 never permits <= 0.
    if parsed <= Decimal("0"):
        issues.append(
            RowValidationIssue(
                sheet=sheet,
                row=row,
                field=field_name,
                value=raw_value,
                code=ErrorCode.INVALID_DIMENSION_VALUE,
                message=f"'{field_name}' = {parsed} is <= 0, which V1 never permits",
            )
        )
        return None, issues

    return parsed, issues


def validate_optional_dimension(
    *, sheet: str, row: int, field_name: str, raw_value: object, unit: Optional[str]
) -> tuple[Optional[Decimal], list[RowValidationIssue]]:
    """Validate a dimension that is not mandatory for every row (Section 21/22).

    A dimension column may exist in the template without every row using
    it -- some rows may supply Ready Quantity directly instead (Section 22
    State A/B). So a BLANK cell here is not itself an error; it simply means
    "this dimension is not available for this row", which the Quantity
    Engine's State A-D logic already handles.

    A NON-blank cell that is invalid (garbage text, unsupported unit, or
    <= 0) IS still a row-level error -- exactly the spec's own example
    (Sheet 'Level 02', Row 17, Field Width, Value '-', INVALID_NUMERIC_VALUE)
    -- regardless of whether that dimension would ultimately have been used.
    """
    if raw_value is None or str(raw_value).strip() == "":
        return None, []
    # Non-blank: delegate to the strict required-field checks (numeric, unit,
    # positivity) but skip the "missing" branch, which can't trigger here.
    return validate_required_dimension(
        sheet=sheet, row=row, field_name=field_name, raw_value=raw_value, unit=unit
    )


def validate_element_type(*, sheet: str, row: int, raw_value: object) -> tuple[Optional[str], list[RowValidationIssue]]:
    """Element Type is always required (Section 21). Its *content* (unknown
    type) is validated later by app.taxonomy.type_taxonomy.resolve_formula_id
    -- this function only checks presence, since only the taxonomy knows
    what a valid type looks like once Profile label overrides are applied.
    """
    text = None if raw_value is None else str(raw_value).strip()
    if not text:
        return None, [
            RowValidationIssue(
                sheet=sheet,
                row=row,
                field="Element Type",
                value=raw_value,
                code=ErrorCode.MISSING_REQUIRED_FIELD,
                message="Element Type is required but missing",
            )
        ]
    return text, []


def validate_ready_quantity(
    *, sheet: str, row: int, raw_value: object, unit: Optional[str]
) -> tuple[bool, bool, Optional[Decimal], list[RowValidationIssue]]:
    """Section 22 -- classify Ready Quantity for one row.

    Returns (present, valid, value_or_None, issues):
      present = the cell is non-blank (something was supplied).
      valid   = present AND numeric AND unit is exactly m3 AND value > 0.
      issues  = non-empty only when present-but-invalid (State C material),
                using ErrorCode.INVALID_READY_QUANTITY so callers don't need
                to re-derive the error code themselves.

    This function never falls back to dimensions -- that decision belongs
    entirely to app.quantity_engine.engine.resolve_ready_quantity_state,
    which receives (present, valid, value) as plain booleans/Decimal and
    implements the 4-state table. This function only classifies.
    """
    if raw_value is None or str(raw_value).strip() == "":
        return False, False, None, []

    present = True
    parsed = parse_numeric(raw_value)

    if parsed is None:
        return present, False, None, [
            RowValidationIssue(
                sheet=sheet, row=row, field="Ready Quantity", value=raw_value,
                code=ErrorCode.INVALID_READY_QUANTITY,
                message=f"Ready Quantity '{raw_value}' is not numeric",
            )
        ]

    try:
        validate_ready_quantity_unit(unit or "")
    except UnsupportedUnitError:
        return present, False, None, [
            RowValidationIssue(
                sheet=sheet, row=row, field="Ready Quantity", value=unit,
                code=ErrorCode.INVALID_READY_QUANTITY,
                message=f"Ready Quantity unit '{unit}' is not m3 (Section 10: no volume conversion in V1)",
            )
        ]

    if parsed <= Decimal("0"):
        return present, False, None, [
            RowValidationIssue(
                sheet=sheet, row=row, field="Ready Quantity", value=raw_value,
                code=ErrorCode.INVALID_READY_QUANTITY,
                message=f"Ready Quantity = {parsed} is <= 0",
            )
        ]

    return present, True, parsed, []


def validate_item_code(*, sheet: str, row: int, raw_value: object, required: bool) -> tuple[Optional[str], list[RowValidationIssue]]:
    issues: list[RowValidationIssue] = []
    text = None if raw_value is None else str(raw_value).strip()
    if not text:
        if required:
            issues.append(
                RowValidationIssue(
                    sheet=sheet,
                    row=row,
                    field="Item Code",
                    value=raw_value,
                    code=ErrorCode.INVALID_ITEM_CODE,
                    message="Item Code is required (comparison key) but missing",
                )
            )
        return None, issues
    return text, issues
