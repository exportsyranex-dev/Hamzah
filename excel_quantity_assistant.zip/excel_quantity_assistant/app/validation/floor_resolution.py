"""
Section 20 -- Floor Resolution.

Case 1: Profile defines a Floor column -> that column is the ONLY source of
        Floor. Blank -> ERROR: FLOOR_UNRESOLVED. Never fall back to sheet name.

Case 2: Profile does not define a Floor column:
        - sheet_structure_type = sheet_per_floor: raw floor identifier is the
          SHEET NAME, resolved to a canonical floor via floor_synonyms.
          Unmapped sheet name -> ERROR: FLOOR_UNRESOLVED.
        - sheet_structure_type = single_sheet: impossible configuration.
          This must be rejected at profile *save* time (see
          app/profiles/profile_store.py, PROFILE_INVALID_FLOOR_CONFIG) and
          must never reach this function. If it somehow does, that is a
          programming error, not a data error, so we raise AssertionError
          rather than a normal ErrorCode -- silently downgrading it to a
          per-row error would hide a broken profile behind a wall of
          per-row noise.

No AI inference in either case (Section 2).
"""
from __future__ import annotations

from typing import Mapping, Optional

from app.config.codes import ErrorCode, SheetStructureType


class FloorUnresolvedError(Exception):
    def __init__(self, detail: str):
        self.code = ErrorCode.FLOOR_UNRESOLVED
        super().__init__(f"{self.code.value}: {detail}")


def resolve_floor(
    *,
    sheet_structure_type: SheetStructureType,
    floor_column_defined: bool,
    floor_column_value: Optional[str],
    sheet_name: str,
    floor_synonyms: Mapping[str, str],
) -> str:
    """Resolve the canonical Floor for one row.

    floor_synonyms maps a raw identifier (sheet name, or floor-column value)
    to a canonical floor name, e.g. {'GF': 'Ground Floor', 'Ground': 'Ground
    Floor', 'الدور الأرضي': 'Ground Floor'}. An identifier not present in
    floor_synonyms is treated as already-canonical if it is a non-empty
    string; this lets simple profiles skip defining synonyms for every floor.
    """
    if floor_column_defined:
        # Case 1
        raw = (floor_column_value or "").strip()
        if not raw:
            raise FloorUnresolvedError("Floor column is blank")
        return floor_synonyms.get(raw, raw)

    # Case 2
    if sheet_structure_type == SheetStructureType.SINGLE_SHEET:
        raise AssertionError(
            "single_sheet with no Floor column reached resolve_floor(); "
            "this profile should have been rejected at save time "
            "(PROFILE_INVALID_FLOOR_CONFIG, see profiles/profile_store.py)."
        )

    raw = sheet_name.strip()
    canonical = floor_synonyms.get(raw)
    if canonical is None:
        raise FloorUnresolvedError(f"Sheet name '{sheet_name}' has no floor synonym mapping")
    return canonical
