"""
Section 39 -- PDF Executive Report.
Section 40 -- AI Executive Summary integration point (text only, optional).

Every numerical value in this PDF comes directly from ReportInput, which is
itself assembled straight from deterministic pipeline output (Section 39:
"AI never writes numbers into the PDF independently"). The only place AI
text can appear is report.ai_executive_summary_text, and even that is
pure narration handed in from outside -- this module never calls an AI
provider itself, it only renders whatever string (or None) it's given.

If report.ai_executive_summary_text is None, the PDF shows
"Executive Summary unavailable." verbatim (Section 40) rather than failing
to build the rest of the report.
"""
from __future__ import annotations

from collections import Counter
from datetime import datetime
from decimal import Decimal
from pathlib import Path
from typing import Optional

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import cm
from reportlab.platypus import (
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)

from app.config.codes import ComparisonResult, ComparisonStatus
from app.reporting.disclosures import MANDATORY_DISCLOSURES
from app.reporting.report_data import ReportInput

_STYLES = getSampleStyleSheet()
_TITLE = ParagraphStyle("QATitle", parent=_STYLES["Title"], textColor=colors.HexColor("#1F2937"))
_H2 = ParagraphStyle("QAH2", parent=_STYLES["Heading2"], textColor=colors.HexColor("#1F2937"), spaceBefore=14)
_BODY = _STYLES["BodyText"]
_SMALL = ParagraphStyle("QASmall", parent=_STYLES["BodyText"], fontSize=8, textColor=colors.HexColor("#4B5563"))

_TABLE_HEADER_STYLE = TableStyle(
    [
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1F2937")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 8),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#D1D5DB")),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#F3F4F6")]),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
    ]
)


def _sum_decimal(values) -> Decimal:
    total = Decimal("0")
    for v in values:
        if v is not None:
            total += v
    return total


def _fmt(d: Optional[Decimal], places: int = 4) -> str:
    if d is None:
        return "-"
    return str(d.quantize(Decimal("1").scaleb(-places)))


def build_pdf(report: ReportInput, output_path: Path) -> Path:
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    doc = SimpleDocTemplate(
        str(output_path), pagesize=A4,
        topMargin=1.5 * cm, bottomMargin=1.5 * cm, leftMargin=1.8 * cm, rightMargin=1.8 * cm,
    )
    story = []

    # --- Header ------------------------------------------------------------
    story.append(Paragraph("Excel Quantity Assistant -- Executive Report", _TITLE))
    story.append(Paragraph(report.project_name, _H2))
    meta_lines = [
        f"Report generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        f"Reference file: {report.reference_filename or '(none -- single-file run)'}",
        f"New file: {report.new_filename}",
        f"Engine version: {report.metadata.engine_version} | Taxonomy version: {report.metadata.taxonomy_version}",
        f"Profile used: {report.metadata.profile_used}",
    ]
    for line in meta_lines:
        story.append(Paragraph(line, _BODY))
    story.append(Spacer(1, 10))

    # --- Total quantities ----------------------------------------------------
    story.append(Paragraph("Total Quantities", _H2))
    total_net = _sum_decimal(g.net_quantity_m3 for g in report.new_aggregated_groups)
    total_boq = _sum_decimal(g.boq_quantity_with_waste_m3 for g in report.new_aggregated_groups)
    totals_table = Table(
        [
            ["Metric", "Value"],
            ["Total Net Quantity (m3)", _fmt(total_net)],
            ["Total BOQ Quantity With Waste (m3)", _fmt(total_boq)],
            ["Aggregated Groups", str(len(report.new_aggregated_groups))],
        ],
        colWidths=[9 * cm, 6 * cm],
    )
    totals_table.setStyle(_TABLE_HEADER_STYLE)
    story.append(totals_table)
    story.append(Spacer(1, 10))

    # --- Warnings / errors summary ------------------------------------------
    story.append(Paragraph("Warnings & Errors Summary", _H2))
    errors_count = sum(1 for rr in report.new_row_results if rr.error is not None)
    errors_count += sum(1 for rr in report.reference_row_results if rr.error is not None)
    warnings_count = sum(len(rr.warnings) for rr in report.new_row_results)
    warnings_count += sum(len(rr.warnings) for rr in report.reference_row_results)
    warnings_count += sum(len(g.aggregate_warnings) for g in report.new_aggregated_groups)
    we_table = Table(
        [["Metric", "Count"], ["Rows Errored", str(errors_count)], ["Warnings Raised", str(warnings_count)]],
        colWidths=[9 * cm, 6 * cm],
    )
    we_table.setStyle(_TABLE_HEADER_STYLE)
    story.append(we_table)
    story.append(Spacer(1, 10))

    # --- Comparison summary --------------------------------------------------
    story.append(Paragraph("Comparison Summary", _H2))
    if not report.comparison_rows:
        story.append(Paragraph("Comparison was not performed for this run.", _BODY))
    else:
        status_counts = Counter(cr.status for cr in report.comparison_rows)
        over_threshold = sum(1 for cr in report.comparison_rows if cr.result == ComparisonResult.OVER_THRESHOLD)
        comp_table = Table(
            [
                ["Status", "Count"],
                ["MATCHED", str(status_counts.get(ComparisonStatus.MATCHED, 0))],
                ["  of which OVER_THRESHOLD", str(over_threshold)],
                ["NEW_ITEM", str(status_counts.get(ComparisonStatus.NEW_ITEM, 0))],
                ["REMOVED_ITEM", str(status_counts.get(ComparisonStatus.REMOVED_ITEM, 0))],
            ],
            colWidths=[9 * cm, 6 * cm],
        )
        comp_table.setStyle(_TABLE_HEADER_STYLE)
        story.append(comp_table)
        story.append(Spacer(1, 8))

        over_rows = [cr for cr in report.comparison_rows if cr.result == ComparisonResult.OVER_THRESHOLD]
        if over_rows:
            story.append(Paragraph("Items Over Threshold", _H2))
            data = [["Key", "Reference (m3)", "New (m3)", "Diff %"]]
            for cr in over_rows[:25]:
                data.append([
                    cr.key, _fmt(cr.reference_quantity_m3), _fmt(cr.new_quantity_m3),
                    _fmt(cr.percentage_difference, places=2),
                ])
            t = Table(data, colWidths=[6.5 * cm, 3 * cm, 3 * cm, 2.5 * cm])
            t.setStyle(_TABLE_HEADER_STYLE)
            story.append(t)
            if len(over_rows) > 25:
                story.append(Paragraph(f"...and {len(over_rows) - 25} more (see Excel report).", _SMALL))

    story.append(Spacer(1, 10))

    # --- Costing (Section 35/36, optional) -----------------------------------
    if report.cost_by_key is not None:
        story.append(Paragraph("Costing Summary", _H2))
        costed = [c for c in report.cost_by_key.values() if c.error_code is None]
        not_available = [c for c in report.cost_by_key.values() if c.error_code is not None]
        total_cost = _sum_decimal(c.estimated_cost for c in costed)
        cost_table = Table(
            [
                ["Metric", "Value"],
                [f"Total Estimated Cost ({report.cost_currency or 'N/A'})", _fmt(total_cost, places=2)],
                ["Groups Costed", str(len(costed))],
                ["Groups Without Cost Data", str(len(not_available))],
            ],
            colWidths=[9 * cm, 6 * cm],
        )
        cost_table.setStyle(_TABLE_HEADER_STYLE)
        story.append(cost_table)
        story.append(Spacer(1, 10))

    # --- Key aggregated table (top rows) -------------------------------------
    story.append(Paragraph("Aggregated Quantities (Top Rows)", _H2))
    if report.new_aggregated_groups:
        data = [["Floor", "Element Type", "Item Code", "Net (m3)", "BOQ w/ Waste (m3)"]]
        for g in report.new_aggregated_groups[:25]:
            data.append([
                g.floor or "", g.element_type or "", g.item_code or "",
                _fmt(g.net_quantity_m3), _fmt(g.boq_quantity_with_waste_m3),
            ])
        t = Table(data, colWidths=[3 * cm, 3 * cm, 3 * cm, 3 * cm, 3.5 * cm])
        t.setStyle(_TABLE_HEADER_STYLE)
        story.append(t)
        if len(report.new_aggregated_groups) > 25:
            story.append(Paragraph(
                f"...and {len(report.new_aggregated_groups) - 25} more groups (see Excel report, Sheet 1).",
                _SMALL,
            ))
    else:
        story.append(Paragraph("No aggregated quantities were produced for this run.", _BODY))

    story.append(Spacer(1, 12))

    # --- AI Executive Summary (§40) -------------------------------------------
    story.append(Paragraph("AI Executive Summary", _H2))
    story.append(Paragraph(report.ai_executive_summary_text or "Executive Summary unavailable.", _BODY))
    story.append(Spacer(1, 12))

    # --- Mandatory disclosures (§34) ------------------------------------------
    story.append(Paragraph("System Limitations", _H2))
    for disclosure in MANDATORY_DISCLOSURES:
        story.append(Paragraph(disclosure, _SMALL))

    doc.build(story)
    return output_path
