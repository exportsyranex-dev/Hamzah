"""
Section 31 -- Audit Trail (Excel Report Sheets).
Section 33 -- Excel Report Formatting.

Builds the workbook from a ReportInput assembled purely from real pipeline
output (RowResult / AggregatedGroup / ComparisonRow) -- this module reads
those objects and writes cells; it makes no engineering decisions and
invents no numbers (Section 2, Section 39: "AI never writes numbers into
the PDF independently" -- the same principle applies here: this code
doesn't either, it only formats what the deterministic pipeline computed).
"""
from __future__ import annotations

from decimal import ROUND_HALF_UP, Decimal
from typing import Optional

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.worksheet import Worksheet

from app.config.codes import ComparisonResult, ComparisonStatus, ErrorCode, QuantitySource
from app.config.settings import DEFAULT_DECIMAL_DISPLAY_PLACES
from app.models.domain import RowResult, RowValidationIssue
from app.reporting.disclosures import MANDATORY_DISCLOSURES
from app.reporting.report_data import ReportInput

# ---------------------------------------------------------------------------
# §33 -- shared styling constants
# ---------------------------------------------------------------------------
HEADER_FILL = PatternFill(start_color="1F2937", end_color="1F2937", fill_type="solid")
HEADER_FONT = Font(color="FFFFFF", bold=True)
TITLE_FONT = Font(bold=True, size=14, color="1F2937")
SECTION_FONT = Font(bold=True, size=11, color="374151")
THIN_BORDER = Border(*(Side(style="thin", color="D1D5DB"),) * 4)

ERROR_FILL = PatternFill(start_color="FFC7CE", end_color="FFC7CE", fill_type="solid")
ERROR_FONT = Font(color="9C0006")
WARNING_FILL = PatternFill(start_color="FFEB9C", end_color="FFEB9C", fill_type="solid")
WARNING_FONT = Font(color="9C6500")
OK_FILL = PatternFill(start_color="C6EFCE", end_color="C6EFCE", fill_type="solid")
OK_FONT = Font(color="006100")
DIRECT_FILL = PatternFill(start_color="DBEAFE", end_color="DBEAFE", fill_type="solid")
CALCULATED_FILL = PatternFill(start_color="EDE9FE", end_color="EDE9FE", fill_type="solid")

DECIMAL_NUMBER_FORMAT = "0." + "0" * DEFAULT_DECIMAL_DISPLAY_PLACES
PERCENTAGE_NUMBER_FORMAT = "0.00"


def _round_for_display(value: Optional[Decimal], places: int = DEFAULT_DECIMAL_DISPLAY_PLACES) -> Optional[float]:
    """§8 -- rounding is permitted ONLY for UI/Excel/PDF presentation. The
    internal Decimal (full precision) is never mutated; this always
    receives a value already computed at full precision and only rounds
    the copy that goes into a display cell.
    """
    if value is None:
        return None
    quant = Decimal("1").scaleb(-places)
    return float(value.quantize(quant, rounding=ROUND_HALF_UP))


def _fmt_dimensions(d: dict) -> str:
    if not d:
        return ""
    parts = []
    for name, val in d.items():
        if isinstance(val, tuple):  # raw_dimensions: (value, unit)
            parts.append(f"{name}={val[0]} {val[1]}")
        else:  # normalized_values_m: Decimal already in meters
            parts.append(f"{name}={val} m")
    return ", ".join(parts)


def _fmt_composition(comp: dict) -> str:
    if not comp:
        return ""
    return " / ".join(f"{src.value}: {count}" for src, count in comp.items())


def _fmt_warnings(warnings: list[RowValidationIssue]) -> str:
    return "; ".join(f"[{w.code.value}] {w.message}" for w in warnings)


def _write_title(ws: Worksheet, title: str, subtitle: str = "") -> int:
    ws["A1"] = title
    ws["A1"].font = TITLE_FONT
    row = 2
    if subtitle:
        ws["A2"] = subtitle
        ws["A2"].font = SECTION_FONT
        row = 3
    return row + 1  # first blank row before the header row


def _write_header_row(ws: Worksheet, row: int, headers: list[str]) -> None:
    for col_idx, header in enumerate(headers, start=1):
        cell = ws.cell(row=row, column=col_idx, value=header)
        cell.font = HEADER_FONT
        cell.fill = HEADER_FILL
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = THIN_BORDER


def _autosize_and_finalize(ws: Worksheet, header_row: int, n_cols: int, n_data_rows: int) -> None:
    """§33 -- frozen header, autofilter, readable column widths."""
    ws.freeze_panes = ws.cell(row=header_row + 1, column=1)
    if n_data_rows > 0:
        last_col_letter = get_column_letter(n_cols)
        ws.auto_filter.ref = f"A{header_row}:{last_col_letter}{header_row + n_data_rows}"

    for col_idx in range(1, n_cols + 1):
        letter = get_column_letter(col_idx)
        max_len = len(str(ws.cell(row=header_row, column=col_idx).value or ""))
        for r in range(header_row + 1, header_row + 1 + n_data_rows):
            v = ws.cell(row=r, column=col_idx).value
            max_len = max(max_len, len(str(v)) if v is not None else 0)
        ws.column_dimensions[letter].width = min(max(max_len + 2, 10), 60)


# ---------------------------------------------------------------------------
# Sheet 1 -- الكميات المجمعة
# ---------------------------------------------------------------------------
def _build_sheet1_aggregated(wb: Workbook, report: ReportInput) -> None:
    ws = wb.create_sheet("الكميات المجمعة")
    ws.sheet_view.rightToLeft = True
    header_row = _write_title(ws, "الكميات المجمعة — Aggregated Quantities", report.project_name)
    headers = [
        "Floor", "Element Type", "Item Code", "Net Quantity (m³)",
        "BOQ Quantity With Waste (m³)", "Source Composition", "Aggregate-Level Warnings",
    ]
    has_costing = report.cost_by_key is not None
    if has_costing:
        headers += [f"Estimated Cost ({report.cost_currency or 'N/A'})", "Cost Note"]
    _write_header_row(ws, header_row, headers)

    r = header_row
    for g in report.new_aggregated_groups:
        r += 1
        ws.cell(row=r, column=1, value=g.floor or "")
        ws.cell(row=r, column=2, value=g.element_type or "")
        ws.cell(row=r, column=3, value=g.item_code or "")
        c4 = ws.cell(row=r, column=4, value=_round_for_display(g.net_quantity_m3))
        c4.number_format = DECIMAL_NUMBER_FORMAT
        c5 = ws.cell(row=r, column=5, value=_round_for_display(g.boq_quantity_with_waste_m3))
        c5.number_format = DECIMAL_NUMBER_FORMAT
        ws.cell(row=r, column=6, value=_fmt_composition(g.source_composition))
        warn_cell = ws.cell(row=r, column=7, value=_fmt_warnings(g.aggregate_warnings))
        if g.aggregate_warnings:
            for col in range(1, len(headers) + 1):
                ws.cell(row=r, column=col).fill = WARNING_FILL

        if has_costing:
            cost_result = report.cost_by_key.get(g.key) if report.cost_by_key else None
            if cost_result is None:
                ws.cell(row=r, column=8, value=None)
                ws.cell(row=r, column=9, value="")
            elif cost_result.error_code is not None:
                ws.cell(row=r, column=8, value=None)
                note_cell = ws.cell(row=r, column=9, value=cost_result.error_code.value)
                note_cell.fill = WARNING_FILL
                note_cell.font = WARNING_FONT
            else:
                cost_cell = ws.cell(row=r, column=8, value=_round_for_display(cost_result.estimated_cost, places=2))
                cost_cell.number_format = "0.00"
                ws.cell(row=r, column=9, value="")

    _autosize_and_finalize(ws, header_row, len(headers), len(report.new_aggregated_groups))


# ---------------------------------------------------------------------------
# Sheet 2 -- المقارنة
# ---------------------------------------------------------------------------
def _build_sheet2_comparison(wb: Workbook, report: ReportInput) -> None:
    ws = wb.create_sheet("المقارنة")
    ws.sheet_view.rightToLeft = True
    header_row = _write_title(ws, "المقارنة — Comparison", report.project_name)
    headers = [
        "Key", "Status", "Reference Quantity (m³)", "New Quantity (m³)",
        "Absolute Difference (m³)", "Percentage Difference (%)", "Threshold (%)", "Result",
    ]
    _write_header_row(ws, header_row, headers)

    r = header_row
    rows = report.comparison_rows or []
    if not rows:
        r += 1
        ws.cell(
            row=r, column=1,
            value="Comparison was not performed for this run (single-file quantity report).",
        )
        ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=len(headers))
    else:
        for cr in rows:
            r += 1
            ws.cell(row=r, column=1, value=cr.key)
            ws.cell(row=r, column=2, value=cr.status.value)
            c3 = ws.cell(row=r, column=3, value=_round_for_display(cr.reference_quantity_m3))
            c3.number_format = DECIMAL_NUMBER_FORMAT
            c4 = ws.cell(row=r, column=4, value=_round_for_display(cr.new_quantity_m3))
            c4.number_format = DECIMAL_NUMBER_FORMAT
            c5 = ws.cell(row=r, column=5, value=_round_for_display(cr.absolute_difference_m3))
            c5.number_format = DECIMAL_NUMBER_FORMAT
            c6 = ws.cell(row=r, column=6, value=_round_for_display(cr.percentage_difference, places=2))
            c6.number_format = PERCENTAGE_NUMBER_FORMAT
            ws.cell(row=r, column=7, value=float(cr.threshold_percentage))
            result_text = cr.result.value if cr.result else ""
            ws.cell(row=r, column=8, value=result_text)

            fill = None
            if cr.status == ComparisonStatus.NEW_ITEM:
                fill = DIRECT_FILL
            elif cr.status == ComparisonStatus.REMOVED_ITEM:
                fill = WARNING_FILL
            elif cr.result == ComparisonResult.OVER_THRESHOLD:
                fill = ERROR_FILL
            elif cr.result == ComparisonResult.OK:
                fill = OK_FILL
            if fill is not None:
                for col in range(1, 9):
                    ws.cell(row=r, column=col).fill = fill

    _autosize_and_finalize(ws, header_row, len(headers), r - header_row)


# ---------------------------------------------------------------------------
# Sheet 3 -- الأخطاء والاستثناءات
# ---------------------------------------------------------------------------
def _collect_all_error_issues(report: ReportInput) -> list[tuple[str, RowValidationIssue]]:
    """Union of (a) ingestion-layer issues carrying an ErrorCode and (b) each
    RowResult.error, tagged with which file they came from. This is a UNION,
    not a re-derivation -- Section 3 rows can legitimately show two issues
    for the same physical row (e.g. a bad Width value AND the resulting
    NO_QUANTITY_SOURCE_AVAILABLE), matching the spec's own worked example.
    """
    out: list[tuple[str, RowValidationIssue]] = []
    for label, issues in (
        (report.new_filename, report.new_ingestion_issues),
        (report.reference_filename or "", report.reference_ingestion_issues),
    ):
        for issue in issues:
            if isinstance(issue.code, ErrorCode):
                out.append((label, issue))
    for label, results in (
        (report.new_filename, report.new_row_results),
        (report.reference_filename or "", report.reference_row_results),
    ):
        for rr in results:
            if rr.error is not None:
                out.append((label, rr.error))
    return out


def _build_sheet3_errors(wb: Workbook, report: ReportInput) -> None:
    ws = wb.create_sheet("الأخطاء والاستثناءات")
    ws.sheet_view.rightToLeft = True
    header_row = _write_title(ws, "الأخطاء والاستثناءات — Errors & Exceptions", report.project_name)
    headers = ["Source File", "Sheet", "Row", "Field", "Value", "Error Code", "Message"]
    _write_header_row(ws, header_row, headers)

    all_issues = _collect_all_error_issues(report)
    r = header_row
    for source_file, issue in all_issues:
        r += 1
        ws.cell(row=r, column=1, value=source_file)
        ws.cell(row=r, column=2, value=issue.sheet)
        ws.cell(row=r, column=3, value=issue.row)
        ws.cell(row=r, column=4, value=issue.field)
        ws.cell(row=r, column=5, value=str(issue.value) if issue.value is not None else "")
        ws.cell(row=r, column=6, value=issue.code.value)
        ws.cell(row=r, column=7, value=issue.message)
        for col in range(1, 8):
            ws.cell(row=r, column=col).fill = ERROR_FILL
            ws.cell(row=r, column=col).font = ERROR_FONT

    _autosize_and_finalize(ws, header_row, len(headers), len(all_issues))


# ---------------------------------------------------------------------------
# Sheet 4 -- Audit Trail
# ---------------------------------------------------------------------------
def _validation_status_text(rr: RowResult) -> str:
    if rr.error is not None:
        return f"ERROR: {rr.error.code.value}"
    if rr.warnings:
        return "OK (with warnings)"
    return "OK"


def _build_sheet4_audit(wb: Workbook, report: ReportInput) -> None:
    ws = wb.create_sheet("Audit Trail")
    header_row = _write_title(ws, "Audit Trail", report.project_name)
    headers = [
        "Source File", "Sheet", "Row", "Element Type", "Floor",
        "Original Dimensions", "Normalized Dimensions", "Units", "Formula",
        "Quantity (m³)", "Source", "Row-Level Warnings", "Validation Status",
    ]
    _write_header_row(ws, header_row, headers)

    all_rows = list(report.new_row_results) + list(report.reference_row_results)
    r = header_row
    for rr in all_rows:
        r += 1
        ws.cell(row=r, column=1, value=rr.source_file)
        ws.cell(row=r, column=2, value=rr.sheet)
        ws.cell(row=r, column=3, value=rr.row)
        ws.cell(row=r, column=4, value=rr.element_type)
        ws.cell(row=r, column=5, value=rr.floor)
        ws.cell(row=r, column=6, value=_fmt_dimensions(rr.raw_dimensions))
        normalized = rr.trace.normalized_values_m if rr.trace else {}
        ws.cell(row=r, column=7, value=_fmt_dimensions(normalized))
        units_text = ", ".join(f"{k}={v[1]}" for k, v in rr.raw_dimensions.items())
        ws.cell(row=r, column=8, value=units_text)
        ws.cell(row=r, column=9, value=(rr.trace.formula_id if rr.trace and rr.trace.formula_id else
                                          ("N/A (Ready Quantity)" if rr.trace else "")))
        qty_cell = ws.cell(row=r, column=10, value=_round_for_display(rr.net_quantity_m3))
        qty_cell.number_format = DECIMAL_NUMBER_FORMAT
        source_val = rr.trace.source.value if rr.trace else ""
        source_cell = ws.cell(row=r, column=11, value=source_val)
        if rr.trace and rr.trace.source == QuantitySource.DIRECT:
            source_cell.fill = DIRECT_FILL
        elif rr.trace and rr.trace.source == QuantitySource.CALCULATED:
            source_cell.fill = CALCULATED_FILL
        ws.cell(row=r, column=12, value=_fmt_warnings(rr.warnings))
        status_cell = ws.cell(row=r, column=13, value=_validation_status_text(rr))
        if rr.error is not None:
            status_cell.fill = ERROR_FILL
            status_cell.font = ERROR_FONT
        elif rr.warnings:
            status_cell.fill = WARNING_FILL
            status_cell.font = WARNING_FONT
        else:
            status_cell.fill = OK_FILL
            status_cell.font = OK_FONT

    _autosize_and_finalize(ws, header_row, len(headers), len(all_rows))


# ---------------------------------------------------------------------------
# Sheet 5 -- Run Metadata (+ mandatory disclosures, §34)
# ---------------------------------------------------------------------------
def _build_sheet5_metadata(wb: Workbook, report: ReportInput) -> None:
    ws = wb.create_sheet("Run Metadata")
    header_row = _write_title(ws, "Run Metadata", report.project_name)
    headers = ["Field", "Value"]
    _write_header_row(ws, header_row, headers)

    m = report.metadata
    rows_data = [
        ("engine_version", m.engine_version),
        ("taxonomy_version", m.taxonomy_version),
        ("profile_used", m.profile_used),
        ("mismatch_tolerance_percentage", f"{m.mismatch_tolerance_percentage}%"),
        ("comparison_threshold_percentage", f"{m.comparison_threshold_percentage}%"),
        ("waste_percentage", f"{m.waste_percentage}%"),
        ("reference_filename", report.reference_filename or "(none -- single-file run)"),
        ("new_filename", report.new_filename),
    ]
    r = header_row
    for field_name, value in rows_data:
        r += 1
        ws.cell(row=r, column=1, value=field_name).font = Font(bold=True)
        ws.cell(row=r, column=2, value=str(value))

    _autosize_and_finalize(ws, header_row, len(headers), len(rows_data))

    # §34 -- mandatory disclosures, verbatim, appended below the metadata table.
    r += 2
    ws.cell(row=r, column=1, value="Mandatory System Limitations (§34)").font = SECTION_FONT
    for disclosure in MANDATORY_DISCLOSURES:
        r += 1
        cell = ws.cell(row=r, column=1, value=disclosure)
        cell.alignment = Alignment(wrap_text=True)
        ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=2)


def build_workbook(report: ReportInput) -> Workbook:
    """Build the full 5-sheet Excel report from real pipeline output.

    Order matches §31 exactly. The default sheet openpyxl creates on
    Workbook() is removed once real sheets exist.
    """
    wb = Workbook()
    default_sheet = wb.active
    _build_sheet1_aggregated(wb, report)
    _build_sheet2_comparison(wb, report)
    _build_sheet3_errors(wb, report)
    _build_sheet4_audit(wb, report)
    _build_sheet5_metadata(wb, report)
    wb.remove(default_sheet)
    return wb
