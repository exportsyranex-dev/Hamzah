"""
Top-level orchestrator: Excel file(s) -> ingestion -> quantity pipeline ->
optional comparison -> Excel report (Section 31) + PDF report (Section 39).

This is the Service layer (Section 6: "Streamlit calls Services; Services
orchestrate modules"). It contains no engineering decisions of its own --
every number it reports came out of app.quantity_engine / app.aggregation /
app.comparison. Its only jobs are: run ingestion for one or two files, run
the pipeline, optionally compare, hand the results to the report builders,
and save with a Section-32-compliant filename.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from decimal import Decimal
from pathlib import Path
from typing import Mapping, Optional

from app.config.settings import AppConfig, get_default_config
from app.costing.costing_engine import CostResult, compute_cost
from app.ai.executive_summary.summary import (
    AIProvider,
    ExecutiveSummaryInput,
    generate_executive_summary,
)
from app.config.codes import ComparisonResult, ComparisonStatus
from app.ingestion.excel_reader import read_raw_rows, read_workbook_structure
from app.ingestion.file_validation import validate_file
from app.ingestion.row_mapper import MappingProfile, map_raw_row
from app.ingestion.schema_drift import SchemaDriftError, detect_schema_drift
from app.models.domain import AggregatedGroup, RowValidationIssue, ValidatedRow
from app.reporting.excel_report import build_workbook
from app.reporting.file_naming import build_report_filename, resolve_output_path
from app.reporting.pdf_report import build_pdf
from app.reporting.report_data import ReportInput, RunMetadata
from app.services.key_builder import KeyBuilderConfig
from app.services.pipeline_service import PipelineRunResult, run_quantity_pipeline
from app.comparison.comparison_engine import compare_aggregated_groups


@dataclass
class IngestAndRunOutcome:
    validated_rows: list[ValidatedRow]
    ingestion_issues: list[RowValidationIssue]
    pipeline_result: PipelineRunResult


def ingest_and_run(
    path: Path,
    profile: MappingProfile,
    *,
    waste_percentage: Decimal,
    mismatch_tolerance_percentage: Decimal,
    key_config: KeyBuilderConfig,
    label_overrides: Optional[dict[str, str]] = None,
    formula_overrides: Optional[dict[str, str]] = None,
    expected_columns: Optional[dict[str, list[str]]] = None,
) -> IngestAndRunOutcome:
    """Section 13 File Validation -> Section 16 Schema Drift (if a baseline
    is supplied) -> Section 11 raw ingestion -> row mapping (Section
    20/21/22 classification) -> Section 7 quantity pipeline, for ONE
    workbook. Called once per file (Reference and/or New).

    expected_columns is the {sheet_name: [columns]} baseline captured when
    the matched Profile was saved (Section 17 expected_columns_json). When
    None (e.g. a freshly hand-built Profile that hasn't been saved/matched
    yet, per Section 15 Manual Mapping), Schema Drift simply isn't checked
    -- there is no baseline to drift from yet.
    """
    validate_file(path)

    raw_rows = list(read_raw_rows(path))

    if expected_columns is not None:
        actual_structure = read_workbook_structure(path)
        drift_report = detect_schema_drift(
            expected_columns=expected_columns,
            actual_columns=actual_structure.sheet_columns,
            raw_rows=raw_rows,
            profile=profile,
        )
        if drift_report.has_drift:
            raise SchemaDriftError(drift_report.user_message())

    validated_rows: list[ValidatedRow] = []
    ingestion_issues: list[RowValidationIssue] = []
    for raw_row in raw_rows:
        vr, issues = map_raw_row(raw_row, profile)
        ingestion_issues.extend(issues)
        if vr is not None:
            validated_rows.append(vr)

    pipeline_result = run_quantity_pipeline(
        validated_rows,
        key_config=key_config,
        waste_percentage=waste_percentage,
        mismatch_tolerance_percentage=mismatch_tolerance_percentage,
        label_overrides=label_overrides,
        formula_overrides=formula_overrides,
    )

    return IngestAndRunOutcome(
        validated_rows=validated_rows,
        ingestion_issues=ingestion_issues,
        pipeline_result=pipeline_result,
    )


def _resolve_unit_rate(group: AggregatedGroup, unit_rates: Mapping[str, Decimal]) -> Optional[Decimal]:
    """Item Code takes priority over Element Type when both are configured
    (a per-item override is more specific than a per-type default rate)."""
    if group.item_code and group.item_code in unit_rates:
        return unit_rates[group.item_code]
    if group.element_type and group.element_type in unit_rates:
        return unit_rates[group.element_type]
    return None


def compute_costs_for_groups(
    groups: list[AggregatedGroup], *, unit_rates: Mapping[str, Decimal], currency: Optional[str]
) -> dict[str, CostResult]:
    """Section 35/36 -- Estimated Cost = Net Quantity x Unit Rate, per
    AggregatedGroup. Reuses app.costing.costing_engine.compute_cost
    unchanged (Section 36 safety rules: missing rate/currency never
    guessed) -- this function only resolves WHICH rate applies to which
    group and loops, it invents no costing logic of its own.
    """
    return {
        g.key: compute_cost(
            net_quantity_m3=g.net_quantity_m3,
            unit_rate=_resolve_unit_rate(g, unit_rates),
            currency=currency,
        )
        for g in groups
    }


def _build_executive_summary_input(
    *,
    new_groups: list[AggregatedGroup],
    reference_groups: list[AggregatedGroup],
    comparison_rows,
    new_row_results,
    reference_row_results,
) -> ExecutiveSummaryInput:
    """Assembles EXACTLY the structured object shape Section 40 defines,
    from data the pipeline has already finalized. This function itself
    never talks to an AI provider -- see generate_executive_summary for
    that, and its own module docstring for why it never receives raw
    Excel data or write-access to any number.
    """
    total_new = sum((g.net_quantity_m3 for g in new_groups), Decimal("0"))
    total_reference = sum((g.net_quantity_m3 for g in reference_groups), Decimal("0"))

    items_over_threshold: list[str] = []
    items_new: list[str] = []
    items_removed: list[str] = []
    if comparison_rows:
        for cr in comparison_rows:
            if cr.status == ComparisonStatus.MATCHED and cr.result == ComparisonResult.OVER_THRESHOLD:
                items_over_threshold.append(cr.key)
            elif cr.status == ComparisonStatus.NEW_ITEM:
                items_new.append(cr.key)
            elif cr.status == ComparisonStatus.REMOVED_ITEM:
                items_removed.append(cr.key)

    errors_count = sum(1 for rr in new_row_results if rr.error is not None)
    errors_count += sum(1 for rr in reference_row_results if rr.error is not None)
    warnings_count = sum(len(rr.warnings) for rr in new_row_results)
    warnings_count += sum(len(rr.warnings) for rr in reference_row_results)

    return ExecutiveSummaryInput(
        total_reference_quantity=str(total_reference),
        total_new_quantity=str(total_new),
        items_over_threshold=items_over_threshold,
        items_new=items_new,
        items_removed=items_removed,
        warnings_count=warnings_count,
        errors_count=errors_count,
    )


@dataclass
class GeneratedReport:
    excel_path: Path
    pdf_path: Path
    report_input: ReportInput


def run_full_report(
    *,
    new_file: Path,
    new_profile: MappingProfile,
    project_name: str,
    profile_name: str,
    output_dir: Path,
    waste_percentage: Decimal = Decimal("0"),
    mismatch_tolerance_percentage: Decimal = Decimal("2.0"),
    comparison_threshold_percentage: Decimal = Decimal("5.0"),
    item_code_is_comparison_key: bool = False,
    reference_file: Optional[Path] = None,
    reference_profile: Optional[MappingProfile] = None,
    label_overrides: Optional[dict[str, str]] = None,
    formula_overrides: Optional[dict[str, str]] = None,
    ai_executive_summary_text: Optional[str] = None,
    ai_provider: Optional[AIProvider] = None,
    company_logo_path: Optional[str] = None,
    app_config: Optional[AppConfig] = None,
    now: Optional[datetime] = None,
    expected_columns: Optional[dict[str, list[str]]] = None,
    reference_expected_columns: Optional[dict[str, list[str]]] = None,
    unit_rates: Optional[Mapping[str, Decimal]] = None,
    cost_currency: Optional[str] = None,
) -> GeneratedReport:
    """End-to-end: Excel input(s) -> deterministic pipeline -> saved Excel +
    PDF reports on disk. This is the single function a UI layer (Section 6)
    would call.

    If reference_file is given, Section 28 Comparison is run automatically
    (New quantities aggregated by the same Central Key Builder as
    Reference, per Section 27) and Sheet 2 / the PDF comparison section are
    populated. Otherwise this is a single-file quantity report and Sheet 2
    says so explicitly rather than being silently empty.

    expected_columns / reference_expected_columns (Section 16): pass the
    saved Profile's column baseline to enable Schema Drift checking for
    that file. Raises SchemaDriftError (a plain, user-facing message, not
    a traceback) and stops before any pipeline work if drift is found --
    exactly Section 16's "stop processing the entire file, no auto-repair".

    unit_rates / cost_currency (Section 35/36, optional): when both are
    given, Sheet 1 and the PDF gain Estimated Cost columns/sections; when
    either is omitted, costing is skipped entirely (never a guessed rate
    or an invented currency).

    ai_executive_summary_text / ai_provider (Section 40, both optional and
    independent of everything else): if ai_executive_summary_text is
    given explicitly, it is used verbatim (caller's own text wins). Else,
    if ai_provider is given, a summary is generated automatically from the
    already-finalized totals/comparison via
    app.ai.executive_summary.generate_executive_summary -- which itself
    falls back to the static "Executive Summary unavailable." text on ANY
    failure (network error, timeout, bad provider, etc.), so a broken or
    absent AI provider can never break report generation (Section 43: "the
    application never fails because local AI is unavailable"). If neither
    is given (the default), the PDF simply shows the fallback text and no
    AI code path is touched at all -- the entire pipeline is provably
    AI-independent by default.
    """
    app_config = app_config or get_default_config()
    key_config = KeyBuilderConfig(item_code_is_comparison_key=item_code_is_comparison_key)

    new_outcome = ingest_and_run(
        new_file, new_profile,
        waste_percentage=waste_percentage,
        mismatch_tolerance_percentage=mismatch_tolerance_percentage,
        key_config=key_config,
        label_overrides=label_overrides,
        formula_overrides=formula_overrides,
        expected_columns=expected_columns,
    )

    reference_outcome: Optional[IngestAndRunOutcome] = None
    comparison_rows = None
    if reference_file is not None:
        ref_profile = reference_profile or new_profile
        reference_outcome = ingest_and_run(
            reference_file, ref_profile,
            waste_percentage=waste_percentage,
            mismatch_tolerance_percentage=mismatch_tolerance_percentage,
            key_config=key_config,
            label_overrides=label_overrides,
            formula_overrides=formula_overrides,
            expected_columns=reference_expected_columns,
        )
        reference_groups = {g.key: g for g in reference_outcome.pipeline_result.aggregated_groups}
        new_groups = {g.key: g for g in new_outcome.pipeline_result.aggregated_groups}
        comparison_rows = compare_aggregated_groups(
            reference_groups=reference_groups,
            new_groups=new_groups,
            threshold_percentage=comparison_threshold_percentage,
        )

    metadata = RunMetadata(
        engine_version=app_config.engine_version,
        taxonomy_version=app_config.taxonomy_version,
        profile_used=profile_name,
        mismatch_tolerance_percentage=mismatch_tolerance_percentage,
        comparison_threshold_percentage=comparison_threshold_percentage,
        waste_percentage=waste_percentage,
    )

    cost_by_key = None
    if unit_rates is not None and cost_currency is not None:
        cost_by_key = compute_costs_for_groups(
            new_outcome.pipeline_result.aggregated_groups,
            unit_rates=unit_rates,
            currency=cost_currency,
        )

    resolved_summary_text = ai_executive_summary_text
    if resolved_summary_text is None and ai_provider is not None:
        summary_input = _build_executive_summary_input(
            new_groups=new_outcome.pipeline_result.aggregated_groups,
            reference_groups=(reference_outcome.pipeline_result.aggregated_groups if reference_outcome else []),
            comparison_rows=comparison_rows,
            new_row_results=new_outcome.pipeline_result.row_results,
            reference_row_results=(reference_outcome.pipeline_result.row_results if reference_outcome else []),
        )
        # generate_executive_summary itself never raises -- any provider
        # failure becomes the static fallback text (Section 40/43).
        resolved_summary_text = generate_executive_summary(summary_input, ai_provider)

    report_input = ReportInput(
        project_name=project_name,
        new_filename=str(new_file),
        metadata=metadata,
        new_row_results=new_outcome.pipeline_result.row_results,
        new_aggregated_groups=new_outcome.pipeline_result.aggregated_groups,
        new_ingestion_issues=new_outcome.ingestion_issues,
        reference_filename=str(reference_file) if reference_file else None,
        reference_row_results=(reference_outcome.pipeline_result.row_results if reference_outcome else []),
        reference_ingestion_issues=(reference_outcome.ingestion_issues if reference_outcome else []),
        comparison_rows=comparison_rows,
        cost_by_key=cost_by_key,
        cost_currency=cost_currency if cost_by_key is not None else None,
        company_logo_path=company_logo_path,
        ai_executive_summary_text=resolved_summary_text,
    )

    now = now or datetime.now()
    output_dir = Path(output_dir)

    excel_filename = build_report_filename(prefix="Quantity_Report", timestamp=now, extension=".xlsx")
    excel_path = resolve_output_path(output_dir, excel_filename)
    wb = build_workbook(report_input)
    wb.save(str(excel_path))

    pdf_filename = build_report_filename(prefix="Quantity_Report", timestamp=now, extension=".pdf")
    pdf_path = resolve_output_path(output_dir, pdf_filename)
    build_pdf(report_input, pdf_path)

    return GeneratedReport(excel_path=excel_path, pdf_path=pdf_path, report_input=report_input)
