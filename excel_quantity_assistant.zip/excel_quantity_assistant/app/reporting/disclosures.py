"""
Section 34 -- Static Engineering Limitations (mandatory disclosures).

Every report must include these, verbatim. This is the single source of
truth for the exact wording -- both the Excel report (Run Metadata sheet)
and the PDF Executive Report (Section 39) import this list rather than
duplicating the text, so the two can never drift out of sync.
"""
from __future__ import annotations

from typing import Final

MANDATORY_DISCLOSURES: Final[list[str]] = [
    "System Limitation: V1 does not deduct openings, voids, or penetrations "
    "from calculated concrete quantities.",
    "System Limitation: V1 assumes rectangular-prism geometry for all "
    "element types (COLUMN, BEAM, SLAB, FOUNDATION). Circular, tapered, or "
    "irregular geometries are not supported and will produce an incorrect "
    "volume if mapped as-is. See Section 18.",
    "System Limitation: Ready Quantity is accepted in m3 only; other volume "
    "units are rejected, not converted. See Section 10.",
    "System Limitation: Waste percentage is applied uniformly per Profile, "
    "not per Floor or per Element Type.",
    "Quantity accuracy depends on the correctness and completeness of "
    "source data.",
    "Excel formula results are dependent on cached values available in the "
    "source workbook (see Section 12).",
]
