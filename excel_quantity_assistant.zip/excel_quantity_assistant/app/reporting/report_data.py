"""
The structured input both report builders (excel_report.py, pdf_report.py)
consume. Assembled by report_service.py directly from real pipeline output
(RowResult, AggregatedGroup, ComparisonRow) -- this module holds no logic,
only the shape of the data reporting needs.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal
from typing import Optional

from app.costing.costing_engine import CostResult
from app.models.domain import AggregatedGroup, ComparisonRow, RowResult, RowValidationIssue


@dataclass
class RunMetadata:
    """§17 / §31 Sheet 5 -- reproducibility metadata for one report run."""

    engine_version: str
    taxonomy_version: str
    profile_used: str
    mismatch_tolerance_percentage: Decimal
    comparison_threshold_percentage: Decimal
    waste_percentage: Decimal


@dataclass
class ReportInput:
    """Everything the report builders need for one run.

    reference_* fields are None/empty when this run has no Comparison
    (§28 is optional -- V1 supports running the Quantity Engine and
    reporting Sheet 1/3/4/5 alone, without a second file).
    """

    project_name: str
    new_filename: str
    metadata: RunMetadata

    new_row_results: list[RowResult]
    new_aggregated_groups: list[AggregatedGroup]
    # Ingestion-layer issues not otherwise captured on a RowResult.error
    # (e.g. a non-blocking bad dimension value on an otherwise-fine row) --
    # still required in Report Sheet 3 (§31) even though they didn't
    # individually exclude the row.
    new_ingestion_issues: list[RowValidationIssue] = field(default_factory=list)

    reference_filename: Optional[str] = None
    reference_row_results: list[RowResult] = field(default_factory=list)
    reference_ingestion_issues: list[RowValidationIssue] = field(default_factory=list)

    comparison_rows: Optional[list[ComparisonRow]] = None

    # Section 35/36 -- WBS & Costing (optional Enterprise extension). None
    # means costing was not configured for this run -- the report simply
    # omits cost columns rather than showing them empty/zero (Section 36:
    # never invent a rate, never assume zero). Keyed by AggregatedGroup.key,
    # same keys as new_aggregated_groups.
    cost_by_key: Optional[dict[str, CostResult]] = None
    cost_currency: Optional[str] = None

    company_logo_path: Optional[str] = None
    ai_executive_summary_text: Optional[str] = None  # §40 -- None => "unavailable" fallback
