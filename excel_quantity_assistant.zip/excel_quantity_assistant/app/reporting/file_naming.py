"""
Section 32 -- Report Generation & File Naming.

Never overwrite source files or previous reports. Output filename must
contain a timestamp: Quantity_Report_2026-09-08_143025.xlsx
On filename collision, append a deterministic sequence: _001, _002, ...
"""
from __future__ import annotations

from datetime import datetime
from pathlib import Path


def build_report_filename(*, prefix: str, timestamp: datetime, extension: str) -> str:
    ts = timestamp.strftime("%Y-%m-%d_%H%M%S")
    ext = extension if extension.startswith(".") else f".{extension}"
    return f"{prefix}_{ts}{ext}"


def resolve_output_path(directory: Path, filename: str) -> Path:
    """Return a path guaranteed not to overwrite an existing file.

    If `filename` already exists in `directory`, append a deterministic
    _001, _002, ... sequence before the extension until a free name is found.
    """
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)

    candidate = directory / filename
    if not candidate.exists():
        return candidate

    stem = candidate.stem
    suffix = candidate.suffix
    n = 1
    while True:
        candidate = directory / f"{stem}_{n:03d}{suffix}"
        if not candidate.exists():
            return candidate
        n += 1
