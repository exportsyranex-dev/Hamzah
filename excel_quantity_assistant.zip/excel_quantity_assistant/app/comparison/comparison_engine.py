"""
Section 28 -- Comparison Engine.

V1 supports exactly two files. The FIRST uploaded file is always REFERENCE;
the second is NEW. Matching priority: Item Code if configured, otherwise
Floor + Element Type, via the Central Key Builder (Section 27) -- the same
key logic Aggregation uses (Section 26).

A valid, finalized Net Quantity can never legitimately be zero (rejected
earlier at Section 22 States A-D and Section 24), so a reference value of
exactly 0 cannot occur for a real matched row. The old draft's "reference =
0 -> NEW ITEM" rule described an impossible state and conflicted with "never
assume missing = zero." Replaced here with a clean 3-state model:

  MATCHED      - key present in both files. percentage_difference is ALWAYS
                 computable (reference guaranteed non-zero for a valid row).
  NEW_ITEM     - key present in New only. Absolute value only, no percentage.
  REMOVED_ITEM - key present in Reference only. Absolute value only, no percentage.
"""
from __future__ import annotations

from decimal import Decimal
from typing import Mapping

from app.config.codes import ComparisonResult as ComparisonResultCode
from app.config.codes import ComparisonStatus
from app.models.domain import AggregatedGroup, ComparisonRow


def compare_aggregated_groups(
    *,
    reference_groups: Mapping[str, AggregatedGroup],
    new_groups: Mapping[str, AggregatedGroup],
    threshold_percentage: Decimal,
) -> list[ComparisonRow]:
    """Compare two key->AggregatedGroup mappings (Reference vs New).

    Both mappings must already be keyed by the SAME Central Key Builder
    logic (Section 27) -- callers are responsible for having verified
    cross-profile consistency (app/services/key_builder.check_profile_consistency)
    before calling this if Reference and New came from different Profiles.
    """
    all_keys = set(reference_groups) | set(new_groups)
    results: list[ComparisonRow] = []

    for key in sorted(all_keys):
        ref = reference_groups.get(key)
        new = new_groups.get(key)

        if ref is not None and new is not None:
            reference_qty = ref.net_quantity_m3
            new_qty = new.net_quantity_m3
            # Guaranteed non-zero: Section 22/24 never let a valid quantity be 0.
            absolute_difference = abs(new_qty - reference_qty)
            percentage_difference = absolute_difference / reference_qty * Decimal("100")
            result = (
                ComparisonResultCode.OK
                if percentage_difference <= threshold_percentage
                else ComparisonResultCode.OVER_THRESHOLD
            )
            results.append(
                ComparisonRow(
                    key=key,
                    status=ComparisonStatus.MATCHED,
                    reference_quantity_m3=reference_qty,
                    new_quantity_m3=new_qty,
                    absolute_difference_m3=absolute_difference,
                    percentage_difference=percentage_difference,
                    threshold_percentage=threshold_percentage,
                    result=result,
                )
            )
        elif ref is None and new is not None:
            results.append(
                ComparisonRow(
                    key=key,
                    status=ComparisonStatus.NEW_ITEM,
                    reference_quantity_m3=None,
                    new_quantity_m3=new.net_quantity_m3,
                    absolute_difference_m3=None,
                    percentage_difference=None,
                    threshold_percentage=threshold_percentage,
                    result=None,
                )
            )
        else:
            assert ref is not None and new is None
            results.append(
                ComparisonRow(
                    key=key,
                    status=ComparisonStatus.REMOVED_ITEM,
                    reference_quantity_m3=ref.net_quantity_m3,
                    new_quantity_m3=None,
                    absolute_difference_m3=None,
                    percentage_difference=None,
                    threshold_percentage=threshold_percentage,
                    result=None,
                )
            )

    return results
