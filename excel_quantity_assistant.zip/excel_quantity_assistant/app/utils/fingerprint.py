"""
§14 — Fingerprint.

Deterministic SHA-256 fingerprint over *sheet names + column names per sheet*
only. Explicitly ignores row data, row order, column order, and sheet order,
so that reordering sheets/columns in an otherwise-identical template does not
break Profile matching.

This module performs structural identification ONLY. It is not schema
validation (§16) and must never be used as a substitute for it.
"""
from __future__ import annotations

import hashlib
from typing import Iterable, Mapping


def _canonicalize(sheet_columns: Mapping[str, Iterable[str]]) -> str:
    """Produce a stable, order-independent textual representation.

    - Sheet order ignored: sheets sorted by name.
    - Column order ignored per sheet: columns sorted.
    - Whitespace-trimmed, case preserved (column names may be intentionally
      case-sensitive in some engineering templates; changing case is a
      genuine schema change, not noise).
    """
    lines = []
    for sheet_name in sorted(sheet_columns.keys()):
        columns = sorted(str(c).strip() for c in sheet_columns[sheet_name])
        lines.append(f"SHEET::{sheet_name.strip()}")
        for col in columns:
            lines.append(f"COL::{col}")
    return "\n".join(lines)


def compute_fingerprint(sheet_columns: Mapping[str, Iterable[str]]) -> str:
    """Compute the deterministic fingerprint hash.

    Parameters
    ----------
    sheet_columns:
        Mapping of sheet name -> iterable of column header names, as
        extracted by the ingestion layer (§11). Row data must NOT be passed
        here.

    Returns
    -------
    Lowercase hex SHA-256 digest string.
    """
    canonical = _canonicalize(sheet_columns)
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()
