"""
Services orchestrate modules; business logic itself lives in the modules
(Section 6: "UI contains no business logic", "Streamlit calls Services").

This pipeline_service covers the deterministic core from ValidatedRow onward
(Section 7): Quantity Engine -> Row-Level Rules -> Aggregation -> Aggregate-
Level Rules -> (optional) Comparison. Ingestion/parsing of the raw Excel
file (Section 11-16) is a separate concern (app/ingestion/) not implemented
in this scaffold pass.
"""
from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from typing import Optional

from app.aggregation.aggregator import aggregate_rows
from app.models.domain import AggregatedGroup, RowResult, ValidatedRow
from app.quantity_engine.engine import resolve_ready_quantity_state
from app.rules_engine.aggregate_level.rules import AggregateLevelRule, apply_aggregate_level_rules
from app.rules_engine.row_level.rules import RowLevelRule, apply_row_level_rules
from app.services.key_builder import KeyBuilderConfig
from app.taxonomy.type_taxonomy import UnknownElementTypeError, resolve_formula_id


@dataclass
class PipelineRunResult:
    row_results: list[RowResult]
    aggregated_groups: list[AggregatedGroup]
    rows_errored: int
    rows_warned: int


def run_quantity_pipeline(
    validated_rows: list[ValidatedRow],
    *,
    key_config: KeyBuilderConfig,
    waste_percentage: Decimal,
    mismatch_tolerance_percentage: Decimal,
    label_overrides: Optional[dict[str, str]] = None,
    formula_overrides: Optional[dict[str, str]] = None,
    row_level_rules: Optional[list[RowLevelRule]] = None,
    aggregate_level_rules: Optional[list[AggregateLevelRule]] = None,
) -> PipelineRunResult:
    """Run Quantity Engine -> Row-Level Rules -> Aggregation -> Aggregate-Level Rules.

    Comparison is intentionally separate (it needs TWO pipeline runs -- one
    for Reference, one for New) and is orchestrated by the caller using
    app.comparison.comparison_engine directly on the resulting AggregatedGroups.
    """
    row_results: list[RowResult] = []

    for vr in validated_rows:
        try:
            formula_id = resolve_formula_id(
                vr.element_type,
                label_overrides=label_overrides,
                formula_overrides=formula_overrides,
            )
        except UnknownElementTypeError as exc:
            from app.models.domain import RowValidationIssue

            row_results.append(
                RowResult(
                    source_file=vr.source_file,
                    sheet=vr.sheet,
                    row=vr.row,
                    floor=vr.floor,
                    element_type=vr.element_type,
                    item_code=vr.item_code,
                    trace=None,
                    net_quantity_m3=None,
                    raw_dimensions=vr.raw_dimensions,
                    error=RowValidationIssue(
                        sheet=vr.sheet,
                        row=vr.row,
                        field="Element Type",
                        value=vr.element_type,
                        code=exc.code,
                        message=str(exc),
                    ),
                )
            )
            continue

        required_dims = {"length", "width", "height"}
        dims_present = required_dims.issubset(vr.dimensions_m.keys())

        trace, error, warnings = resolve_ready_quantity_state(
            sheet=vr.sheet,
            row=vr.row,
            ready_quantity_present=vr.ready_quantity_present,
            ready_quantity_valid=vr.ready_quantity_present and vr.ready_quantity_m3 is not None,
            ready_quantity_m3=vr.ready_quantity_m3,
            dimensions_valid=dims_present,
            dimensions_m=vr.dimensions_m,
            formula_id=formula_id,
            mismatch_tolerance_percentage=mismatch_tolerance_percentage,
        )

        row_result = RowResult(
            source_file=vr.source_file,
            sheet=vr.sheet,
            row=vr.row,
            floor=vr.floor,
            element_type=vr.element_type,
            item_code=vr.item_code,
            trace=trace,
            net_quantity_m3=trace.result_m3 if trace else None,
            error=error,
            warnings=list(warnings),
            raw_dimensions=vr.raw_dimensions,
        )

        if row_result.is_valid:
            row_result.warnings.extend(apply_row_level_rules(row_result, row_level_rules))

        row_results.append(row_result)

    aggregated = aggregate_rows(row_results, key_config=key_config, waste_percentage=waste_percentage)

    for group in aggregated:
        group.aggregate_warnings.extend(apply_aggregate_level_rules(group, aggregate_level_rules))

    rows_errored = sum(1 for r in row_results if r.error is not None)
    rows_warned = sum(1 for r in row_results if r.warnings)

    return PipelineRunResult(
        row_results=row_results,
        aggregated_groups=aggregated,
        rows_errored=rows_errored,
        rows_warned=rows_warned,
    )
