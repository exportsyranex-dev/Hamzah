"""
Section 27 -- Central Key Builder.

Exactly ONE key-building function. Both Aggregation (Section 26) and
Comparison (Section 28) call this -- no duplicated key logic anywhere else.

Also implements the cross-profile consistency check: if Reference and New
files are matched against DIFFERENT Profiles, verify both profiles agree on
(1) item_code_is_comparison_key and (2) taxonomy resolution for any type
that appears in both files. If this cannot be verified, the caller must
raise PROFILE_COMPARISON_CONSISTENCY_WARNING and require explicit user
acknowledgment before comparison proceeds.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping, Optional

from app.config.codes import WarningCode


@dataclass(frozen=True)
class KeyBuilderConfig:
    item_code_is_comparison_key: bool


def build_key(
    *,
    config: KeyBuilderConfig,
    floor: Optional[str],
    element_type: Optional[str],
    item_code: Optional[str],
) -> str:
    """Build the canonical grouping/matching key for one row.

    Section 27: key = Floor x Element Type, OR Item Code when explicitly
    configured as the comparison key. This is the ONLY place either
    Aggregation or Comparison may construct a key.
    """
    if config.item_code_is_comparison_key:
        if not item_code:
            raise ValueError(
                "item_code_is_comparison_key=True but item_code is missing; "
                "this row should have failed row validation (INVALID_ITEM_CODE) earlier."
            )
        return f"ITEM::{item_code}"
    return f"FLOOR_TYPE::{floor}::{element_type}"


@dataclass(frozen=True)
class ProfileComparisonConsistency:
    """Result of checking two Profiles used for Reference vs New (Section 27)."""

    consistent: bool
    warning_code: Optional[WarningCode]
    detail: str


def check_profile_consistency(
    *,
    reference_config: KeyBuilderConfig,
    new_config: KeyBuilderConfig,
    reference_type_resolutions: Mapping[str, str],
    new_type_resolutions: Mapping[str, str],
) -> ProfileComparisonConsistency:
    """Verify the two Profiles agree on comparison-key configuration and on
    taxonomy resolution for any canonical type appearing in both files.

    reference_type_resolutions / new_type_resolutions map a raw label seen
    in that file to the canonical type it resolved to under that file's
    Profile.
    """
    if reference_config.item_code_is_comparison_key != new_config.item_code_is_comparison_key:
        return ProfileComparisonConsistency(
            consistent=False,
            warning_code=WarningCode.PROFILE_COMPARISON_CONSISTENCY_WARNING,
            detail=(
                "Reference and New profiles disagree on item_code_is_comparison_key "
                f"({reference_config.item_code_is_comparison_key} vs {new_config.item_code_is_comparison_key})."
            ),
        )

    shared_labels = set(reference_type_resolutions) & set(new_type_resolutions)
    conflicts = [
        label
        for label in shared_labels
        if reference_type_resolutions[label] != new_type_resolutions[label]
    ]
    if conflicts:
        return ProfileComparisonConsistency(
            consistent=False,
            warning_code=WarningCode.PROFILE_COMPARISON_CONSISTENCY_WARNING,
            detail=(
                "Raw Element Type labels resolve to different canonical types "
                f"under the two profiles: {conflicts}."
            ),
        )

    return ProfileComparisonConsistency(consistent=True, warning_code=None, detail="Consistent.")
