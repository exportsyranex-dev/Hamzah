"""
Core domain objects passed between pipeline stages (§7 Canonical Data Flow).

These are plain dataclasses only — no business logic lives here. Every field
that feeds a report sheet (§31) is named to match that sheet's columns so the
reporting layer can consume them with minimal translation.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal
from typing import Optional

from app.config.codes import ComparisonResult as ComparisonResultCode
from app.config.codes import ComparisonStatus, ErrorCode, QuantitySource, WarningCode


@dataclass(frozen=True)
class RawRow:
    """A single row as extracted from ingestion (§11), before any validation."""

    source_file: str
    sheet_name: str
    row_number: int
    raw_values: dict  # column_name -> raw cell value (untouched)


@dataclass
class RowValidationIssue:
    sheet: str
    row: int
    field: str
    value: object
    code: ErrorCode | WarningCode
    message: str


@dataclass
class ValidatedRow:
    """A row that has passed Row Validation (§21) and Floor Resolution (§20).

    dimensions_m holds already-unit-normalized values (still full Decimal
    precision, §8) keyed by dimension name ('length', 'width', 'height').
    """

    source_file: str
    sheet: str
    row: int
    floor: str
    element_type: str
    item_code: Optional[str]
    dimensions_m: dict[str, Decimal]
    ready_quantity_m3: Optional[Decimal]
    ready_quantity_present: bool
    # §23/§31 Sheet 4 audit trail needs the ORIGINAL pre-normalization value
    # too, not just the normalized meters -- dim_name -> (raw_value, unit).
    # Populated by app/ingestion/row_mapper.py; empty dict is a safe default
    # for any ValidatedRow constructed directly (e.g. existing unit tests).
    raw_dimensions: dict[str, tuple[object, str]] = field(default_factory=dict)


@dataclass
class QuantityCalculationTrace:
    """§23 — full audit trace for one row's Net Quantity."""

    input_values: dict
    normalized_values_m: dict[str, Decimal]
    formula_id: Optional[str]
    result_m3: Decimal
    source: QuantitySource


@dataclass
class RowResult:
    """Output of the Quantity Engine (§23) plus Row-Level Rules (§30) for one row.

    error is set (and quantity excluded) for Ready-Quantity States C/D
    (§22) or any other row-level ERROR. warnings accumulate independently
    and never block the row unless paired with an error.
    """

    source_file: str
    sheet: str
    row: int
    floor: str
    element_type: str
    item_code: Optional[str]
    trace: Optional[QuantityCalculationTrace]
    net_quantity_m3: Optional[Decimal]
    error: Optional[RowValidationIssue] = None
    warnings: list[RowValidationIssue] = field(default_factory=list)
    raw_dimensions: dict[str, tuple[object, str]] = field(default_factory=dict)

    @property
    def is_valid(self) -> bool:
        return self.error is None and self.net_quantity_m3 is not None


@dataclass
class AggregatedGroup:
    """§26 — one row of Report Sheet 1 (الكميات المجمعة)."""

    key: str  # rendered Floor|ElementType or ItemCode, per Central Key Builder
    floor: Optional[str]
    element_type: Optional[str]
    item_code: Optional[str]
    net_quantity_m3: Decimal
    boq_quantity_with_waste_m3: Decimal
    source_composition: dict[QuantitySource, int]  # e.g. {DIRECT: 3, CALCULATED: 1}
    aggregate_warnings: list[RowValidationIssue] = field(default_factory=list)
    member_row_results: list[RowResult] = field(default_factory=list)


@dataclass
class ComparisonRow:
    """§28 — one row of Report Sheet 2 (المقارنة)."""

    key: str
    status: ComparisonStatus
    reference_quantity_m3: Optional[Decimal]
    new_quantity_m3: Optional[Decimal]
    absolute_difference_m3: Optional[Decimal]
    percentage_difference: Optional[Decimal]
    threshold_percentage: Decimal
    result: Optional[ComparisonResultCode]
