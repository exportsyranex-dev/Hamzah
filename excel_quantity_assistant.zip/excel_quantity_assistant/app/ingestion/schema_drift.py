"""
Section 16 -- Schema Drift.

"Fingerprint matching does not eliminate schema validation. Always validate
the actual workbook against the selected Profile. Missing required columns
or expected structure: SCHEMA_DRIFT_DETECTED. Stop processing the entire
file. No auto-repair."

This module compares the CURRENT workbook's structure against the
`expected_columns` baseline captured when the matched Profile was saved
(see app/profiles/profile_store.py, expected_columns_json). It detects:

  1. Missing columns  -- a column the Profile expects is no longer present.
  2. New/unexpected columns -- a column exists now that wasn't part of the
     original template.
  3. Suspected renames -- a heuristic pairing when a sheet lost exactly the
     columns it gained, which usually means a rename rather than an
     addition+removal (surfaced only as a hint in the message; the
     underlying facts are still reported as missing + new).
  4. Impactful data-type drift -- a column the Profile maps to a NUMERIC
     field (length/width/height/ready_quantity) still exists under the
     same header, but its actual cell values no longer look numeric (e.g.
     the column was repurposed for free text). Header-name matching alone
     would miss this silently.

Any of these STOPS the whole file (no partial processing, no auto-repair)
-- matching Section 16 exactly. This module raises SchemaDriftError with a
message written for a human, not a stack trace, per the product
requirement that end users never see a Python traceback.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Iterable, Mapping

from app.config.codes import ErrorCode
from app.ingestion.row_mapper import MappingProfile
from app.models.domain import RawRow
from app.validation.row_validation import parse_numeric

NUMERIC_FIELDS = ("length", "width", "height", "ready_quantity")

# A column is only flagged as type-drifted if there are at least this many
# non-blank sampled values (too few samples -> not enough evidence either way)
# and at least this fraction of them fail to parse as numeric.
MIN_SAMPLES_FOR_TYPE_DRIFT = 3
TYPE_DRIFT_FAILURE_RATIO = 0.5


class SchemaDriftError(Exception):
    def __init__(self, message: str):
        self.code = ErrorCode.SCHEMA_DRIFT_DETECTED
        super().__init__(f"{self.code.value}: {message}")


@dataclass(frozen=True)
class SchemaDriftReport:
    missing_columns: list[tuple[str, str]] = field(default_factory=list)
    new_unexpected_columns: list[tuple[str, str]] = field(default_factory=list)
    suspected_renames: list[tuple[str, str, str]] = field(default_factory=list)  # (sheet, old, new)
    type_drift_columns: list[tuple[str, str, str]] = field(default_factory=list)  # (sheet, col, reason)

    @property
    def has_drift(self) -> bool:
        return bool(
            self.missing_columns or self.new_unexpected_columns
            or self.type_drift_columns
        )

    def user_message(self) -> str:
        """A plain-language, actionable message -- never a stack trace."""
        lines = ["The uploaded Excel file's structure no longer matches the saved template."]

        if self.missing_columns:
            lines.append("\nMissing columns (present when the template was created, missing now):")
            for sheet, col in self.missing_columns:
                lines.append(f"  - Sheet '{sheet}': column '{col}' is missing.")

        if self.new_unexpected_columns:
            lines.append("\nNew, unexpected columns (not part of the original template):")
            for sheet, col in self.new_unexpected_columns:
                lines.append(f"  - Sheet '{sheet}': column '{col}' was not expected.")

        if self.suspected_renames:
            lines.append("\nThis pattern looks like a column rename, not just an add/remove:")
            for sheet, old, new in self.suspected_renames:
                lines.append(f"  - Sheet '{sheet}': '{old}' may have been renamed to '{new}'.")

        if self.type_drift_columns:
            lines.append("\nColumns whose data no longer looks like the expected type:")
            for sheet, col, reason in self.type_drift_columns:
                lines.append(f"  - Sheet '{sheet}': column '{col}' -- {reason}")

        lines.append(
            "\nWhat to do: fix the source workbook so its columns match the "
            "original template (restore the missing column(s), remove or "
            "map the new one(s), and ensure numeric columns contain numeric "
            "values), or create/select a new Profile for this updated "
            "layout. The file was not processed."
        )
        return "\n".join(lines)


def detect_column_drift(
    expected: Mapping[str, list[str]], actual: Mapping[str, list[str]]
) -> tuple[list[tuple[str, str]], list[tuple[str, str]], list[tuple[str, str, str]]]:
    """Compare two {sheet_name: [columns]} structures.

    A sheet present in `expected` but entirely absent from `actual` counts
    as every one of its columns being missing (the sheet itself vanishing
    is certainly "expected structure" changing, per Section 16).
    """
    missing: list[tuple[str, str]] = []
    new: list[tuple[str, str]] = []
    renames: list[tuple[str, str, str]] = []

    all_sheets = set(expected.keys()) | set(actual.keys())
    for sheet in sorted(all_sheets):
        expected_cols = set(expected.get(sheet, []))
        actual_cols = set(actual.get(sheet, []))

        sheet_missing = sorted(expected_cols - actual_cols)
        sheet_new = sorted(actual_cols - expected_cols)

        missing.extend((sheet, c) for c in sheet_missing)
        new.extend((sheet, c) for c in sheet_new)

        # Heuristic rename hint: same count lost as gained on this sheet.
        if sheet_missing and sheet_new and len(sheet_missing) == len(sheet_new):
            for old, new_name in zip(sheet_missing, sheet_new):
                renames.append((sheet, old, new_name))

    return missing, new, renames


def _sample_column_values(raw_rows: Iterable[RawRow], sheet: str, header: str, limit: int) -> list[object]:
    values = []
    for raw_row in raw_rows:
        if raw_row.sheet_name != sheet:
            continue
        v = raw_row.raw_values.get(header)
        if v is not None and str(v).strip() != "":
            values.append(v)
        if len(values) >= limit:
            break
    return values


def detect_type_drift(
    raw_rows: Iterable[RawRow], profile: MappingProfile, *, sample_limit: int = 20
) -> list[tuple[str, str, str]]:
    """Section 16 -- 'data type/structure changes when impactful'.

    raw_rows must be a materialized list (or re-iterable), since each
    mapped numeric field samples it independently. Only checks fields the
    Profile actually maps to a header (an unmapped dimension is simply not
    used, per Section 22, and isn't a drift concern).
    """
    raw_rows = list(raw_rows)
    drift: list[tuple[str, str, str]] = []

    # Determine which sheet(s) are relevant -- all sheets present in raw_rows.
    sheets = sorted({r.sheet_name for r in raw_rows})

    for field_name in NUMERIC_FIELDS:
        header = profile.column_mapping.get(field_name)
        if header is None:
            continue
        for sheet in sheets:
            samples = _sample_column_values(raw_rows, sheet, header, sample_limit)
            if len(samples) < MIN_SAMPLES_FOR_TYPE_DRIFT:
                continue
            failures = sum(1 for v in samples if parse_numeric(v) is None)
            ratio = failures / len(samples)
            if ratio >= TYPE_DRIFT_FAILURE_RATIO:
                drift.append((
                    sheet, header,
                    f"{failures}/{len(samples)} sampled values are not numeric "
                    f"(expected numeric values for '{field_name}')",
                ))

    return drift


def detect_schema_drift(
    *,
    expected_columns: Mapping[str, list[str]],
    actual_columns: Mapping[str, list[str]],
    raw_rows: Iterable[RawRow],
    profile: MappingProfile,
) -> SchemaDriftReport:
    """Full Section 16 check: structural (column) drift + impactful type drift."""
    missing, new, renames = detect_column_drift(expected_columns, actual_columns)
    type_drift = detect_type_drift(raw_rows, profile)
    return SchemaDriftReport(
        missing_columns=missing,
        new_unexpected_columns=new,
        suspected_renames=renames,
        type_drift_columns=type_drift,
    )
