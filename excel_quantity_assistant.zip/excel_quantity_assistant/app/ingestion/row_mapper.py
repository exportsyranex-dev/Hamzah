"""
Bridges Section 11 (raw ingestion) to Section 7's canonical pipeline input
(ValidatedRow). Applies a Profile's column_mapping/unit_per_field to each
RawRow, running:

  - Element Type presence (Section 21)
  - Floor Resolution (Section 20, both cases)
  - Item Code validation (Section 21)
  - Dimension validation, optional-per-row (Section 21/22)
  - Ready Quantity classification (Section 22)

Ownership boundary (important): this module NEVER decides Ready-Quantity
States A-D itself -- that decision belongs entirely to
app.quantity_engine.engine.resolve_ready_quantity_state (Section 22), which
is the single authoritative place those states are resolved and tested.
So a present-but-invalid Ready Quantity is passed through as
(ready_quantity_present=True, ready_quantity_m3=None) rather than excluding
the row here -- the engine turns that into ERROR: INVALID_READY_QUANTITY
(State C). Likewise a present-but-invalid dimension is simply dropped from
dimensions_m (making that dimension "not available", contributing to
State D only if nothing else is available either) -- but the bad raw value
is still recorded as a RowValidationIssue for the audit trail (Section 31
Sheet 3), it just doesn't unilaterally kill the row.

A row IS excluded here only when there is no reasonable path to identify
*what* the row even is: unresolved Floor, missing Element Type, or a
missing Item Code that the Profile requires as the comparison key. Those
are structural failures, not quantity-domain failures.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping, Optional

from app.config.codes import SheetStructureType
from app.models.domain import RawRow, RowValidationIssue, ValidatedRow
from app.units.registry import normalize_length
from app.validation.floor_resolution import FloorUnresolvedError, resolve_floor
from app.validation.row_validation import (
    validate_element_type,
    validate_item_code,
    validate_optional_dimension,
    validate_ready_quantity,
)

DIMENSION_FIELDS = ("length", "width", "height")


@dataclass(frozen=True)
class MappingProfile:
    """The subset of a saved Profile (Section 17) this module needs.

    column_mapping: canonical field name -> source column header. Canonical
    fields: 'floor', 'element_type', 'item_code', 'length', 'width',
    'height', 'ready_quantity', and optionally 'ready_quantity_unit' (a
    per-row unit COLUMN, distinct from unit_per_field['ready_quantity']
    which is a fixed profile-level default -- Section 15 lists both 'Unit
    per dimension' and 'Ready Quantity Unit' as things the user maps, so
    both paths are supported).
    unit_per_field: canonical dimension/ready_quantity field -> fixed unit
    string, used whenever there is no per-row unit column for that field.
    """

    sheet_structure_type: SheetStructureType
    column_mapping: Mapping[str, str]
    unit_per_field: Mapping[str, str]
    floor_synonyms: Mapping[str, str]
    item_code_is_comparison_key: bool

    @property
    def floor_column_defined(self) -> bool:
        return "floor" in self.column_mapping


def _get(raw: Mapping[str, Any], header: Optional[str]) -> Any:
    if header is None:
        return None
    return raw.get(header)


def map_raw_row(
    raw_row: RawRow, profile: MappingProfile
) -> tuple[Optional[ValidatedRow], list[RowValidationIssue]]:
    """Map one RawRow through Profile-driven validation.

    Returns (validated_row_or_None, issues). issues always accumulates
    everything worth recording in the audit trail (Section 31 Sheet 3),
    including non-blocking ones (bad-but-optional dimension values,
    present-but-invalid Ready Quantity -- both left for the Quantity Engine
    to turn into a proper State C/D error). validated_row_or_None is None
    only for the structural failures described in the module docstring.
    """
    sheet = raw_row.sheet_name
    row_num = raw_row.row_number
    cm = profile.column_mapping
    raw = raw_row.raw_values
    issues: list[RowValidationIssue] = []
    blocking = False

    element_type, et_issues = validate_element_type(
        sheet=sheet, row=row_num, raw_value=_get(raw, cm.get("element_type"))
    )
    issues.extend(et_issues)
    if element_type is None:
        blocking = True

    try:
        floor = resolve_floor(
            sheet_structure_type=profile.sheet_structure_type,
            floor_column_defined=profile.floor_column_defined,
            floor_column_value=_get(raw, cm.get("floor")),
            sheet_name=sheet,
            floor_synonyms=profile.floor_synonyms,
        )
    except FloorUnresolvedError as exc:
        floor = None
        blocking = True
        issues.append(
            RowValidationIssue(
                sheet=sheet, row=row_num, field="Floor", value=_get(raw, cm.get("floor")),
                code=exc.code, message=str(exc),
            )
        )

    item_code, ic_issues = validate_item_code(
        sheet=sheet,
        row=row_num,
        raw_value=_get(raw, cm.get("item_code")),
        required=profile.item_code_is_comparison_key,
    )
    issues.extend(ic_issues)
    if profile.item_code_is_comparison_key and item_code is None:
        blocking = True

    # --- Dimensions: non-blocking. Bad values are recorded but dropped. ---
    dimensions_m: dict = {}
    raw_dimensions: dict = {}
    for dim in DIMENSION_FIELDS:
        header = cm.get(dim)
        if header is None:
            continue  # this template has no column for this dimension at all
        unit = profile.unit_per_field.get(dim)
        raw_cell_value = _get(raw, header)
        parsed, dim_issues = validate_optional_dimension(
            sheet=sheet, row=row_num, field_name=dim.capitalize(),
            raw_value=raw_cell_value, unit=unit,
        )
        issues.extend(dim_issues)
        if parsed is not None and unit is not None:
            dimensions_m[dim] = normalize_length(parsed, unit, field_name=dim)
            raw_dimensions[dim] = (raw_cell_value, unit)

    # --- Ready Quantity: non-blocking. Present-but-invalid is passed through
    # as (present=True, value=None) so the Quantity Engine raises State C. ---
    rq_header = cm.get("ready_quantity")
    rq_unit_header = cm.get("ready_quantity_unit")
    rq_unit = _get(raw, rq_unit_header) if rq_unit_header is not None else profile.unit_per_field.get(
        "ready_quantity", "m3"
    )

    ready_present, ready_valid, ready_value, rq_issues = validate_ready_quantity(
        sheet=sheet, row=row_num, raw_value=_get(raw, rq_header), unit=rq_unit
    )
    issues.extend(rq_issues)

    if blocking:
        return None, issues

    validated = ValidatedRow(
        source_file=raw_row.source_file,
        sheet=sheet,
        row=row_num,
        floor=floor,
        element_type=element_type,
        item_code=item_code,
        dimensions_m=dimensions_m,
        ready_quantity_m3=ready_value if ready_valid else None,
        ready_quantity_present=ready_present,
        raw_dimensions=raw_dimensions,
    )
    return validated, issues
