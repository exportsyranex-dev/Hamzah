"""
Section 11 -- Excel Ingestion.
Section 12 -- Formula Cache Limitation.

Uses openpyxl.load_workbook(..., data_only=True): reads CACHED formula
results, never recalculates. If a formula cell has no cached value (e.g. the
workbook was never opened/saved in Excel), openpyxl returns None -- which
this module surfaces as an ordinary blank cell. It is the caller's
responsibility (row_mapper.py) to treat a blank *required* value as a
validation error; this module does not decide that a formula's missing
cache is special versus any other blank cell -- both simply come through as
None, per Section 12 ("the system never guesses formula results").

Extracts sheet names, headers (assumed to be row 1 of each sheet), the
actual used data range, and raw row values. Ignores fully empty rows and
columns. Makes NO engineering decisions (Section 11).
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Iterator

import openpyxl

from app.models.domain import RawRow


@dataclass(frozen=True)
class WorkbookStructure:
    """Structural information only -- feeds the fingerprint (Section 14).

    sheet_columns: sheet_name -> list of header strings, in their original
    sheet order (fingerprinting re-sorts them; this preserves order for
    display/debugging).
    """

    sheet_columns: dict[str, list[str]]


def _is_row_empty(row_values: tuple) -> bool:
    return all(v is None or str(v).strip() == "" for v in row_values)


def _header_row(ws) -> list[str]:
    """First row of the sheet, treated as headers. Blank header cells are
    skipped entirely (not given a synthetic name) -- a column with no header
    is, by definition, not mappable to anything and ingestion has no
    business inventing a name for it.
    """
    first_row = next(ws.iter_rows(min_row=1, max_row=1, values_only=True), ())
    headers = []
    for v in first_row:
        if v is not None and str(v).strip() != "":
            headers.append(str(v).strip())
    return headers


def read_workbook_structure(path: Path) -> WorkbookStructure:
    """Section 11 + Section 14 input: sheet names and column headers only, no row data."""
    wb = openpyxl.load_workbook(str(path), data_only=True, read_only=True)
    try:
        sheet_columns = {name: _header_row(wb[name]) for name in wb.sheetnames}
    finally:
        wb.close()
    return WorkbookStructure(sheet_columns=sheet_columns)


def read_raw_rows(path: Path, *, sheets: list[str] | None = None) -> Iterator[RawRow]:
    """Yield one RawRow per non-empty data row (row 2 onward) across the
    requested sheets (default: all sheets).

    raw_values maps header string -> raw cell value, UNTOUCHED (no type
    coercion, no unit handling, no engineering decisions -- Section 11).
    A row is skipped entirely if every cell in it is empty (Section 11:
    "ignore fully empty rows").
    """
    wb = openpyxl.load_workbook(str(path), data_only=True, read_only=True)
    try:
        target_sheets = sheets if sheets is not None else wb.sheetnames
        for sheet_name in target_sheets:
            ws = wb[sheet_name]
            headers = _header_row(ws)
            if not headers:
                continue  # a sheet with no header row has no mappable columns
            n_cols = len(headers)

            for row_idx, row_values in enumerate(
                ws.iter_rows(min_row=2, values_only=True), start=2
            ):
                trimmed = row_values[:n_cols]
                if _is_row_empty(trimmed):
                    continue
                raw_values = dict(zip(headers, trimmed))
                yield RawRow(
                    source_file=str(path),
                    sheet_name=sheet_name,
                    row_number=row_idx,
                    raw_values=raw_values,
                )
    finally:
        wb.close()
