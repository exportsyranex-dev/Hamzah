"""
Section 13 -- File Validation.

Reject immediately if: extension is not .xlsx, file is empty, workbook
cannot be opened, workbook is corrupt, or workbook has no usable data.
Reject .xls with a specific, actionable message. Never trust the extension
alone -- actual workbook readability is verified by attempting to open it.

This module performs NO engineering decisions (Section 11) -- it only
answers "can this file even be processed at all?".
"""
from __future__ import annotations

from pathlib import Path

import openpyxl
from openpyxl.utils.exceptions import InvalidFileException

from app.config.codes import ErrorCode


class FileValidationError(Exception):
    def __init__(self, code: ErrorCode, message: str):
        self.code = code
        super().__init__(f"{code.value}: {message}")


def validate_file(path: Path) -> None:
    """Raise FileValidationError if the file cannot be processed at all.

    Does not return the opened workbook -- callers open it again via
    excel_reader.open_workbook, which performs the same checks defensively
    (this function may be called standalone, e.g. from an upload handler,
    before any reading is attempted).
    """
    path = Path(path)

    if path.suffix.lower() == ".xls":
        raise FileValidationError(
            ErrorCode.UNSUPPORTED_FILE_FORMAT,
            "Unsupported file format: .xls. Please save the workbook as .xlsx.",
        )

    if path.suffix.lower() != ".xlsx":
        raise FileValidationError(
            ErrorCode.UNSUPPORTED_FILE_FORMAT,
            f"Unsupported file format: '{path.suffix}'. Only .xlsx is supported.",
        )

    if not path.exists():
        raise FileValidationError(ErrorCode.EMPTY_FILE, f"File not found: {path}")

    if path.stat().st_size == 0:
        raise FileValidationError(ErrorCode.EMPTY_FILE, f"File is empty: {path}")

    try:
        wb = openpyxl.load_workbook(str(path), data_only=True, read_only=True)
    except InvalidFileException as exc:
        raise FileValidationError(ErrorCode.CORRUPT_WORKBOOK, f"Workbook cannot be opened: {exc}") from exc
    except Exception as exc:  # noqa: BLE001 -- openpyxl can raise various zip/xml errors for corrupt files
        raise FileValidationError(ErrorCode.CORRUPT_WORKBOOK, f"Workbook is corrupt or unreadable: {exc}") from exc

    try:
        sheet_names = wb.sheetnames
        if not sheet_names:
            raise FileValidationError(ErrorCode.NO_USABLE_DATA, "Workbook has no sheets.")

        has_any_data = False
        for name in sheet_names:
            ws = wb[name]
            if ws.max_row and ws.max_row >= 1 and ws.max_column and ws.max_column >= 1:
                # max_row/max_column can report 1x1 for a truly empty sheet in
                # some openpyxl versions -- confirm at least one non-empty cell.
                for row in ws.iter_rows(values_only=True):
                    if any(cell is not None and str(cell).strip() != "" for cell in row):
                        has_any_data = True
                        break
            if has_any_data:
                break
        if not has_any_data:
            raise FileValidationError(ErrorCode.NO_USABLE_DATA, "Workbook has no usable data.")
    finally:
        wb.close()
