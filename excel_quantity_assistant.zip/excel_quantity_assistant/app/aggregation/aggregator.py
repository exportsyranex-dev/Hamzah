"""
Section 26 -- Aggregation.

Occurs before comparison. Uses the Central Key Builder (app/services/key_builder.py)
-- the ONLY key logic in the app. All repeated rows sharing a key are merged.
Never compares raw rows (that's Comparison's job, Section 28).

Section 26 fix: an aggregated group can merge DIRECT and CALCULATED rows, so
there is no single "Source" value -- report a Source Composition instead
(e.g. {DIRECT: 3, CALCULATED: 1}). Full per-row source detail stays in the
Audit Trail sheet (Section 31, Sheet 4) via member_row_results.
"""
from __future__ import annotations

from collections import OrderedDict, defaultdict
from decimal import Decimal
from typing import Iterable

from app.models.domain import AggregatedGroup, RowResult
from app.services.key_builder import KeyBuilderConfig, build_key


def aggregate_rows(
    row_results: Iterable[RowResult],
    *,
    key_config: KeyBuilderConfig,
    waste_percentage: Decimal,
) -> list[AggregatedGroup]:
    """Aggregate valid RowResults into AggregatedGroups.

    Rows with row_result.error set (Ready-Quantity States C/D, or any other
    row-level error) are excluded entirely -- they never enter aggregation,
    matching Section 22 ("Row excluded from quantities, counted in
    rows_errored").
    """
    groups: "OrderedDict[str, list[RowResult]]" = OrderedDict()

    for rr in row_results:
        if not rr.is_valid:
            continue
        key = build_key(
            config=key_config,
            floor=rr.floor,
            element_type=rr.element_type,
            item_code=rr.item_code,
        )
        groups.setdefault(key, []).append(rr)

    waste_factor = Decimal("1") + (waste_percentage / Decimal("100"))

    aggregated: list[AggregatedGroup] = []
    for key, members in groups.items():
        net_total = sum((m.net_quantity_m3 for m in members), start=Decimal("0"))

        composition: dict = defaultdict(int)
        for m in members:
            if m.trace is not None:
                composition[m.trace.source] += 1

        # aggregate-level warnings are attached later by the rules_engine
        # aggregate-level stage (see app/rules_engine/aggregate_level/rules.py);
        # aggregation itself never invents engineering judgement.
        first = members[0]
        aggregated.append(
            AggregatedGroup(
                key=key,
                floor=first.floor,
                element_type=first.element_type,
                item_code=first.item_code if key_config.item_code_is_comparison_key else None,
                net_quantity_m3=net_total,
                boq_quantity_with_waste_m3=net_total * waste_factor,
                source_composition=dict(composition),
                member_row_results=members,
            )
        )

    return aggregated
