"""
§9  Standard Output Unit — all volumes are ultimately expressed in m3.
§10 Unit Registry & Volume Unit Policy.

Deliberate V1 scope decision (not an oversight, see §10/§34/§49):
Ready Quantity accepts m3 ONLY. There is no volume-unit registry in V1.
Liters, ft3, cm3 are REJECTED, not converted.

All conversion factors are declared as Decimal STRINGS (§8) — never
Decimal(0.001), which would silently inherit float imprecision.
"""
from __future__ import annotations

from decimal import Decimal
from typing import Final

from app.config.codes import ErrorCode


class UnsupportedUnitError(Exception):
    """Raised whenever a unit cannot be resolved. Carries ErrorCode.UNSUPPORTED_UNIT."""

    def __init__(self, unit: str, context: str = ""):
        self.code = ErrorCode.UNSUPPORTED_UNIT
        self.unit = unit
        self.context = context
        msg = f"{self.code.value}: unit '{unit}'"
        if context:
            msg += f" ({context})"
        super().__init__(msg)


# ---------------------------------------------------------------------------
# §10 — V1 linear units, Decimal STRING conversion factors to meters.
# ---------------------------------------------------------------------------
LINEAR_UNITS_TO_METERS: Final[dict[str, Decimal]] = {
    "m": Decimal("1"),
    "cm": Decimal("0.01"),
    "mm": Decimal("0.001"),
    "ft": Decimal("0.3048"),
    "in": Decimal("0.0254"),
}

# §10 — Ready Quantity V1 accepts m3 only. Explicitly NOT a conversion table;
# this set exists purely so callers can recognize "this is a volume unit,
# and the only one we accept" vs. "this is a linear unit" vs. "unknown".
READY_QUANTITY_ACCEPTED_UNITS: Final[frozenset[str]] = frozenset({"m3", "m^3", "m³"})

# Volume units that are recognizably volume units but explicitly rejected
# (surfaced distinctly so validation can give a clearer message than a bare
# "unknown unit" — still resolves to the same ErrorCode.UNSUPPORTED_UNIT).
KNOWN_REJECTED_VOLUME_UNITS: Final[frozenset[str]] = frozenset(
    {"l", "liter", "liters", "litre", "litres", "ft3", "ft^3", "cm3", "cm^3"}
)


def normalize_length(value: Decimal, unit: str, *, field_name: str = "") -> Decimal:
    """Convert a linear dimension value to meters.

    Never guesses, never silently converts an unsupported unit (§10). Does
    NOT round (§8) — full precision is preserved for downstream calculation.
    """
    key = unit.strip().lower()
    factor = LINEAR_UNITS_TO_METERS.get(key)
    if factor is None:
        raise UnsupportedUnitError(unit, context=field_name or "linear dimension")
    return value * factor


def validate_ready_quantity_unit(unit: str) -> None:
    """Raise UnsupportedUnitError unless the unit is exactly m3 (§10).

    This function performs no conversion — by design. A caller holding a
    Ready Quantity in liters must not have it silently turned into m3; the
    row is rejected (§22 State C) instead.
    """
    key = unit.strip().lower()
    if key in READY_QUANTITY_ACCEPTED_UNITS:
        return
    raise UnsupportedUnitError(unit, context="Ready Quantity (m3 only, see spec §10)")


def is_supported_linear_unit(unit: str) -> bool:
    return unit.strip().lower() in LINEAR_UNITS_TO_METERS
