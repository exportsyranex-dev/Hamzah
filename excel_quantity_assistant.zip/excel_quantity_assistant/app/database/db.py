"""
Section 17 -- Profile Database.

SQLite via stdlib sqlite3 (no ORM dependency needed for this scope -- keeps
the tech stack within Section 4's approved list). Transactions are used for
every write. No business logic lives in this module -- it only persists and
retrieves rows; validation of profile *content* (e.g. PROFILE_INVALID_FLOOR_CONFIG)
happens in app/profiles/profile_store.py before this layer is ever called.
"""
from __future__ import annotations

import contextlib
import json
import sqlite3
from pathlib import Path
from typing import Any, Iterator

SCHEMA = """
CREATE TABLE IF NOT EXISTS template_profiles (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    fingerprint_hash TEXT NOT NULL,
    column_mapping_json TEXT NOT NULL,
    sheet_structure_type TEXT NOT NULL,
    unit_per_field_json TEXT NOT NULL,
    waste_percentage TEXT NOT NULL,
    decimal_precision INTEGER NOT NULL,
    floor_synonyms_json TEXT NOT NULL,
    type_formula_map_json TEXT NOT NULL,
    item_code_is_comparison_key INTEGER NOT NULL,
    comparison_threshold_percentage TEXT NOT NULL,
    mismatch_tolerance_percentage TEXT NOT NULL,
    expected_columns_json TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS processing_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp TEXT NOT NULL,
    run_type TEXT NOT NULL,
    filename TEXT,
    reference_filename TEXT,
    new_filename TEXT,
    profile_used TEXT,
    engine_version TEXT NOT NULL,
    taxonomy_version TEXT NOT NULL,
    rows_processed INTEGER NOT NULL DEFAULT 0,
    rows_direct INTEGER NOT NULL DEFAULT 0,
    rows_calculated INTEGER NOT NULL DEFAULT 0,
    rows_errored INTEGER NOT NULL DEFAULT 0,
    rows_warned INTEGER NOT NULL DEFAULT 0,
    status TEXT NOT NULL,
    error_summary TEXT,
    report_filename TEXT
);
"""


def get_connection(db_path: Path) -> sqlite3.Connection:
    db_path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(db_path))
    conn.execute("PRAGMA journal_mode=WAL;")  # Section 49 item 5: concurrency mitigation
    conn.row_factory = sqlite3.Row
    return conn


def _run_migrations(conn: sqlite3.Connection) -> None:
    """Additive, idempotent migrations for columns introduced after the
    original Section 17 schema shipped. Guarded so this is safe to call on
    both a brand-new database (column already exists via CREATE TABLE
    above) and an older one created before this column was added.

    expected_columns_json (Section 16, Schema Drift Detection): the exact
    {sheet_name: [column_names]} structure captured at profile-save time,
    needed to detect missing/new/renamed columns later. The original
    Section 17 schema only stored fingerprint_hash, which is a one-way
    digest and cannot itself be used to report *which* column changed --
    this column fills that gap so Schema Drift can give the user a
    specific, actionable message instead of just "something changed".
    """
    existing_cols = {row["name"] for row in conn.execute("PRAGMA table_info(template_profiles)")}
    if "expected_columns_json" not in existing_cols:
        with transaction(conn):
            conn.execute("ALTER TABLE template_profiles ADD COLUMN expected_columns_json TEXT")


def initialize_schema(conn: sqlite3.Connection) -> None:
    with conn:
        conn.executescript(SCHEMA)
    _run_migrations(conn)


@contextlib.contextmanager
def transaction(conn: sqlite3.Connection) -> Iterator[sqlite3.Connection]:
    """Explicit transaction context manager (Section 17: 'Use transactions')."""
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise


def insert_profile(conn: sqlite3.Connection, profile: dict[str, Any]) -> int:
    fields = [
        "name", "fingerprint_hash", "column_mapping_json", "sheet_structure_type",
        "unit_per_field_json", "waste_percentage", "decimal_precision",
        "floor_synonyms_json", "type_formula_map_json", "item_code_is_comparison_key",
        "comparison_threshold_percentage", "mismatch_tolerance_percentage",
        "expected_columns_json", "created_at", "updated_at",
    ]
    placeholders = ", ".join("?" for _ in fields)
    columns = ", ".join(fields)
    with transaction(conn):
        cur = conn.execute(
            f"INSERT INTO template_profiles ({columns}) VALUES ({placeholders})",
            [profile.get(f) for f in fields],
        )
        return cur.lastrowid


def find_profiles_by_fingerprint(conn: sqlite3.Connection, fingerprint_hash: str) -> list[sqlite3.Row]:
    cur = conn.execute(
        "SELECT * FROM template_profiles WHERE fingerprint_hash = ?", (fingerprint_hash,)
    )
    return cur.fetchall()


def insert_processing_log(conn: sqlite3.Connection, log_entry: dict[str, Any]) -> int:
    fields = [
        "timestamp", "run_type", "filename", "reference_filename", "new_filename",
        "profile_used", "engine_version", "taxonomy_version", "rows_processed",
        "rows_direct", "rows_calculated", "rows_errored", "rows_warned", "status",
        "error_summary", "report_filename",
    ]
    placeholders = ", ".join("?" for _ in fields)
    columns = ", ".join(fields)
    with transaction(conn):
        cur = conn.execute(
            f"INSERT INTO processing_log ({columns}) VALUES ({placeholders})",
            [log_entry.get(f) for f in fields],
        )
        return cur.lastrowid


def dumps(obj: Any) -> str:
    return json.dumps(obj, ensure_ascii=False)


def loads(text: str) -> Any:
    return json.loads(text)
