"""
§18 — Type Taxonomy & Formula Registry.

Formulas are plain, named, deterministic Python functions operating on
Decimal. No eval(), no arbitrary user-supplied expressions (§18, §2).

CRITICAL, MANDATORY DISCLOSURE (§18): every V1 formula is a rectangular-prism
volume. There is no circular-column formula, no cross-section-shape field in
the taxonomy. If a circular column is mapped to COLUMN, V1 computes an
incorrect volume with no warning. This must be surfaced in:
  1. the Manual Mapping UI (ui/ layer, not this module),
  2. every generated report (§34),
  3. the roadmap (§49, item 1).
This module only implements the formula and documents the limitation; it
does not and cannot detect that a "COLUMN" is actually circular.
"""
from __future__ import annotations

from decimal import Decimal
from typing import Callable, Final


class UnknownFormulaError(Exception):
    pass


def rectangular_prism_volume(length: Decimal, width: Decimal, height: Decimal) -> Decimal:
    """Volume of a rectangular prism. All dimension arguments are already
    normalized to meters (the caller runs unit normalization first) and are
    named to match ValidatedRow.dimensions_m's keys ('length', 'width',
    'height') so they can be passed straight through as **kwargs.

    No rounding (§8) — full Decimal precision preserved.
    """
    return length * width * height


# ---------------------------------------------------------------------------
# Formula Registry: formula_id -> callable. This is the single source of
# truth; the Type Taxonomy below only ever stores formula_id strings, never
# formula bodies, and rules_engine/quantity_engine never accept ad-hoc code.
# ---------------------------------------------------------------------------
FORMULA_REGISTRY: Final[dict[str, Callable[..., Decimal]]] = {
    "rectangular_prism_volume": rectangular_prism_volume,
}


def get_formula(formula_id: str) -> Callable[..., Decimal]:
    fn = FORMULA_REGISTRY.get(formula_id)
    if fn is None:
        raise UnknownFormulaError(f"No formula registered for formula_id='{formula_id}'")
    return fn
