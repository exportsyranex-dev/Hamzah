"""
Section 18 -- V1 Type Taxonomy.
Section 19 -- Taxonomy Levels: Global Taxonomy, then Profile Override (Profile wins).

Two explicit resolution layers, matching the spec's own example
("Global Pedestal -> COLUMN; Profile A overrides Pedestal -> FOUNDATION"):

    raw label  --(label_map)-->  canonical Element Type  --(type_to_formula)--> formula_id

Neither layer ever stores a formula body (see formula_registry.py) and V1
never allows the user to author arbitrary executable formulas (Section 19) --
a Profile may only point an unknown raw label at an *existing* canonical
type, or point it directly at an existing registered formula_id.
"""
from __future__ import annotations

from typing import Final, Mapping

from app.config.codes import ErrorCode

# ---------------------------------------------------------------------------
# Section 18 -- canonical Element Type -> formula_id (Global default).
# CRITICAL: every entry currently resolves to rectangular_prism_volume.
# See the mandatory disclosure in formula_registry.py and Sections 18/34/49.
# ---------------------------------------------------------------------------
GLOBAL_TYPE_TO_FORMULA: Final[dict[str, str]] = {
    "COLUMN": "rectangular_prism_volume",
    "BEAM": "rectangular_prism_volume",
    "SLAB": "rectangular_prism_volume",
    "FOUNDATION": "rectangular_prism_volume",
}

V1_ELEMENT_TYPES: Final[frozenset[str]] = frozenset(GLOBAL_TYPE_TO_FORMULA.keys())

# Global raw-label -> canonical-type map. V1 ships only the identity mapping
# (source column already using canonical names); Profiles add their own
# project-specific synonyms (e.g. "Pedestal" -> "FOUNDATION") via
# label_overrides below.
GLOBAL_LABEL_TO_TYPE: Final[dict[str, str]] = {t: t for t in V1_ELEMENT_TYPES}


class UnknownElementTypeError(Exception):
    def __init__(self, element_type: str):
        self.code = ErrorCode.UNKNOWN_ELEMENT_TYPE
        self.element_type = element_type
        super().__init__(f"{self.code.value}: '{element_type}'")


def resolve_formula_id(
    raw_label: str,
    *,
    label_overrides: Mapping[str, str] | None = None,
    formula_overrides: Mapping[str, str] | None = None,
) -> str:
    """Resolve a raw Element Type label to a formula_id.

    Parameters
    ----------
    raw_label:
        The Element Type value as it appears in the source row.
    label_overrides:
        Profile-level raw-label -> canonical-type overrides (Section 19
        example: {'Pedestal': 'FOUNDATION'}). Checked before the Global
        label map.
    formula_overrides:
        Profile-level canonical-type -> formula_id overrides. Lets a user
        map an unknown type to an *existing* Formula ID (Section 19)
        without writing new executable code.

    Raises
    ------
    UnknownElementTypeError (-> ErrorCode.UNKNOWN_ELEMENT_TYPE) if the label
    cannot be resolved through Profile override or Global Taxonomy. Never
    guesses (Section 2).
    """
    label_overrides = label_overrides or {}
    formula_overrides = formula_overrides or {}

    canonical_type = label_overrides.get(raw_label) or GLOBAL_LABEL_TO_TYPE.get(raw_label)
    if canonical_type is None:
        raise UnknownElementTypeError(raw_label)

    formula_id = formula_overrides.get(canonical_type) or GLOBAL_TYPE_TO_FORMULA.get(canonical_type)
    if formula_id is None:
        raise UnknownElementTypeError(raw_label)
    return formula_id
