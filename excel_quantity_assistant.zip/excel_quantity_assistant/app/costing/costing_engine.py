"""
Section 35 -- WBS & Cost Coding Engine.
Section 36 -- Costing Safety.

Estimated Cost = Net Quantity x Unit Rate, in Decimal. Unit rates are
deterministic local data (from the Profile); AI cannot select unit rates or
modify costs (Section 2, Section 35).

Missing Unit Rate -> COST_NOT_AVAILABLE (never assume zero, never invent).
Missing currency -> CURRENCY_NOT_DEFINED (never guess).
"""
from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from typing import Optional

from app.config.codes import ErrorCode


@dataclass(frozen=True)
class CostResult:
    estimated_cost: Optional[Decimal]
    currency: Optional[str]
    error_code: Optional[ErrorCode]


def compute_cost(
    *, net_quantity_m3: Decimal, unit_rate: Optional[Decimal], currency: Optional[str]
) -> CostResult:
    if unit_rate is None:
        return CostResult(estimated_cost=None, currency=currency, error_code=ErrorCode.COST_NOT_AVAILABLE)
    if not currency:
        return CostResult(estimated_cost=None, currency=None, error_code=ErrorCode.CURRENCY_NOT_DEFINED)
    return CostResult(
        estimated_cost=net_quantity_m3 * unit_rate,
        currency=currency,
        error_code=None,
    )
