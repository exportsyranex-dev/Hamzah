"""
Section 6 -- "UI contains no business logic. Streamlit calls Services;
Services orchestrate modules."

This module is the boundary between the real Streamlit app
(streamlit_app.py) and the deterministic pipeline (app.reporting.report_service
and everything under it). It contains no Streamlit imports, so it is fully
unit-testable on its own -- which matters because it is also the ONLY code
path the UI actually calls. There is no separate "demo" or "mock" pipeline
anywhere in this project; streamlit_app.py calls exactly these functions,
and these tests exercise exactly these functions.

Responsibilities:
  - Turn every known failure mode (bad file, schema drift, unmapped
    columns, unexpected exception) into a plain-language message, never a
    Python traceback (explicit product requirement).
  - Suggest a column mapping deterministically from the uploaded file's
    real headers (Section 37: deterministic string-similarity only, NEVER
    auto-applied -- the caller/UI must still get explicit confirmation
    before this mapping is used to process anything).
  - Summarize a finished run's real ReportInput into plain numbers for
    display (no numbers are invented here; every figure traces back to
    RowResult/AggregatedGroup/ComparisonRow already produced by the
    pipeline).
"""
from __future__ import annotations

import sqlite3
from dataclasses import dataclass
from decimal import Decimal
from pathlib import Path
from typing import Mapping, Optional

from app.ai.provider import AIProvider
from app.config.codes import ComparisonResult, ComparisonStatus, SheetStructureType
from app.config.settings import get_default_config
from app.database import db as db_module
from app.ingestion.excel_reader import read_workbook_structure
from app.ingestion.file_validation import FileValidationError, validate_file
from app.ingestion.row_mapper import MappingProfile
from app.ingestion.schema_drift import SchemaDriftError
from app.profiles import profile_store
from app.profiles.profile_store import (
    ProfileInvalidFloorConfigError,
    ProfileMatchOutcome,
    validate_floor_config_for_save,
)
from app.reporting.report_data import ReportInput
from app.reporting.report_service import GeneratedReport, run_full_report
from app.utils.fingerprint import compute_fingerprint

# ---------------------------------------------------------------------------
# Section 37 -- deterministic (non-AI) column-mapping suggestion. Exact,
# case-insensitive alias matching only -- no fuzzy/AI matching, and this
# result is a SUGGESTION: the UI must still show it for explicit user
# confirmation before it is used to process anything (never auto-applied).
# ---------------------------------------------------------------------------
CANONICAL_FIELDS = ("floor", "element_type", "item_code", "length", "width", "height", "ready_quantity")

_HEADER_ALIASES: dict[str, list[str]] = {
    "floor": ["floor", "level", "story", "storey", "floor name"],
    "element_type": ["element type", "element_type", "type", "elementtype"],
    "item_code": ["item code", "item_code", "code", "itemcode", "id"],
    "length": ["length", "length (m)", "length(m)", "l"],
    "width": ["width", "width (m)", "width(m)", "w"],
    "height": ["height", "thickness", "height/thickness", "height (m)", "h"],
    "ready_quantity": ["ready quantity", "ready_quantity", "quantity", "volume", "net quantity"],
}


def suggest_column_mapping(headers: list[str]) -> dict[str, str]:
    """Deterministic alias match, case-insensitive/trimmed. Returns
    canonical_field -> actual header string, only for fields it found a
    confident match for. Never guesses a match that isn't in the alias
    table -- an unmatched canonical field is simply absent from the
    result, and the UI must ask the user to pick it manually.
    """
    normalized = {h.strip().lower(): h for h in headers}
    suggestion: dict[str, str] = {}
    for canonical, aliases in _HEADER_ALIASES.items():
        for alias in aliases:
            if alias in normalized:
                suggestion[canonical] = normalized[alias]
                break
    return suggestion


def suggest_floor_column_defined(mapping: Mapping[str, str]) -> bool:
    return "floor" in mapping


def build_identity_floor_synonyms(sheet_names: list[str]) -> dict[str, str]:
    """Default floor-synonym table when no Floor column exists: each real
    sheet name maps to itself (Section 20 Case 2 requires an explicit
    entry per raw identifier -- this is the sensible zero-configuration
    default; the user can rename the canonical floor names afterward).
    """
    return {name: name for name in sheet_names}


@dataclass
class ValidationOutcome:
    ok: bool
    message: str
    error_code: Optional[str] = None


def validate_uploaded_file(path: Path) -> ValidationOutcome:
    """Section 13 File Validation, with a friendly message instead of a
    raised exception -- the UI calls this BEFORE offering to process.
    """
    try:
        validate_file(path)
        return ValidationOutcome(ok=True, message="File looks valid and ready to process.")
    except FileValidationError as exc:
        return ValidationOutcome(ok=False, message=str(exc).split(": ", 1)[-1], error_code=exc.code.value)
    except Exception as exc:  # noqa: BLE001 -- last-resort guard, never show a traceback to the user
        return ValidationOutcome(
            ok=False,
            message=f"The file could not be opened or read ({exc.__class__.__name__}).",
            error_code=None,
        )


def get_workbook_headers(path: Path) -> dict[str, list[str]]:
    """Real sheet_name -> [column headers], straight from the uploaded
    file (Section 11) -- used to populate the UI's mapping dropdowns with
    ACTUAL headers, never a hard-coded list.
    """
    return read_workbook_structure(path).sheet_columns


# ---------------------------------------------------------------------------
# Section 15/17 -- Profile persistence (fingerprint matching + saved
# mappings, so a user doesn't have to re-map the same template every time).
# ---------------------------------------------------------------------------
def get_profile_db_connection(db_path: Optional[Path] = None) -> sqlite3.Connection:
    """Opens (and initializes, if needed) the local Profile database.

    Defaults to the cross-platform per-user app-data location from
    app.config.settings (never a path relative to the installed app
    itself -- see that module for why). Callers (tests, or a UI wanting an
    isolated DB) may pass an explicit db_path.
    """
    path = db_path or get_default_config().db_path
    conn = db_module.get_connection(path)
    db_module.initialize_schema(conn)
    return conn


def _row_to_mapping_profile(row: sqlite3.Row) -> MappingProfile:
    return MappingProfile(
        sheet_structure_type=SheetStructureType(row["sheet_structure_type"]),
        column_mapping=db_module.loads(row["column_mapping_json"]),
        unit_per_field=db_module.loads(row["unit_per_field_json"]),
        floor_synonyms=db_module.loads(row["floor_synonyms_json"]),
        item_code_is_comparison_key=bool(row["item_code_is_comparison_key"]),
    )


@dataclass
class ProfileOption:
    id: int
    name: str
    mapping_profile: MappingProfile
    expected_columns: Optional[dict[str, list[str]]]
    waste_percentage: Decimal
    comparison_threshold_percentage: Decimal
    mismatch_tolerance_percentage: Decimal


@dataclass
class ProfileLookup:
    """Section 15's exact 3-outcome model, applied to a real uploaded file."""

    outcome: ProfileMatchOutcome
    fingerprint_hash: str
    workbook_structure: dict[str, list[str]]
    options: list[ProfileOption]


def lookup_profile_for_file(conn: sqlite3.Connection, path: Path) -> ProfileLookup:
    """Fingerprints the uploaded file (Section 14) and matches it against
    saved Profiles (Section 15) -- AUTO_APPLY / USER_MUST_SELECT /
    OPEN_MANUAL_MAPPING, exactly as specified. No AI selection, ever: this
    is a pure fingerprint-hash lookup.
    """
    structure = read_workbook_structure(path).sheet_columns
    fingerprint_hash = compute_fingerprint(structure)
    match_result = profile_store.match_profiles(conn, fingerprint_hash)
    options = [
        ProfileOption(
            id=row["id"],
            name=row["name"],
            mapping_profile=_row_to_mapping_profile(row),
            expected_columns=profile_store.load_expected_columns(row),
            waste_percentage=Decimal(row["waste_percentage"]),
            comparison_threshold_percentage=Decimal(row["comparison_threshold_percentage"]),
            mismatch_tolerance_percentage=Decimal(row["mismatch_tolerance_percentage"]),
        )
        for row in match_result.matches
    ]
    return ProfileLookup(
        outcome=match_result.outcome,
        fingerprint_hash=fingerprint_hash,
        workbook_structure=structure,
        options=options,
    )


def save_profile_for_file(
    conn: sqlite3.Connection,
    *,
    name: str,
    path: Path,
    mapping_profile: MappingProfile,
    waste_percentage: Decimal,
    comparison_threshold_percentage: Decimal,
    mismatch_tolerance_percentage: Decimal,
) -> int:
    """Section 15 'Save Profile' step, called after a successful Manual
    Mapping run so the SAME template auto-applies (and gets Schema Drift
    protection, Section 16) on every future upload. Re-validates the floor
    configuration before saving (Section 20) -- the same gate
    `validate_floor_config_for_save` enforces everywhere else.
    """
    structure = read_workbook_structure(path).sheet_columns
    fingerprint_hash = compute_fingerprint(structure)
    return profile_store.save_profile(
        conn,
        name=name,
        fingerprint_hash=fingerprint_hash,
        column_mapping=dict(mapping_profile.column_mapping),
        sheet_structure_type=mapping_profile.sheet_structure_type,
        unit_per_field=dict(mapping_profile.unit_per_field),
        waste_percentage=waste_percentage,
        decimal_precision=get_default_config().decimal_precision,
        floor_synonyms=dict(mapping_profile.floor_synonyms),
        type_formula_map={},  # no per-profile taxonomy overrides configured by this UI yet
        item_code_is_comparison_key=mapping_profile.item_code_is_comparison_key,
        comparison_threshold_percentage=comparison_threshold_percentage,
        mismatch_tolerance_percentage=mismatch_tolerance_percentage,
        floor_column_defined=mapping_profile.floor_column_defined,
        expected_columns=structure,
    )


@dataclass
class FloorConfigCheck:
    ok: bool
    message: str = ""


def check_floor_configuration(
    *, sheet_structure_type: SheetStructureType, floor_column_defined: bool
) -> FloorConfigCheck:
    """Friendly wrapper around Section 20's save-time floor-config gate,
    reused here at the UI layer so an impossible configuration (single
    sheet, no Floor column) is caught with a plain message BEFORE
    processing starts, not as a mid-run crash.
    """
    try:
        validate_floor_config_for_save(
            sheet_structure_type=sheet_structure_type, floor_column_defined=floor_column_defined
        )
        return FloorConfigCheck(ok=True)
    except ProfileInvalidFloorConfigError:
        return FloorConfigCheck(
            ok=False,
            message=(
                "This file has a single sheet and no column was mapped to 'Floor'. "
                "Please map a Floor column, or use a workbook with one sheet per floor."
            ),
        )


@dataclass
class ComparisonSummary:
    matched: int = 0
    matched_over_threshold: int = 0
    new_items: int = 0
    removed_items: int = 0


@dataclass
class RunSummary:
    """Every field here is read directly off ReportInput -- nothing is
    recomputed or estimated independently of the pipeline that already
    produced these numbers.
    """

    total_groups: int
    total_net_quantity_m3: Decimal
    total_boq_with_waste_m3: Decimal
    rows_errored: int
    rows_warned: int
    comparison: Optional[ComparisonSummary]
    total_estimated_cost: Optional[Decimal]
    cost_currency: Optional[str]
    groups_without_cost: int


def summarize_report(report_input: ReportInput) -> RunSummary:
    groups = report_input.new_aggregated_groups
    total_net = sum((g.net_quantity_m3 for g in groups), Decimal("0"))
    total_boq = sum((g.boq_quantity_with_waste_m3 for g in groups), Decimal("0"))

    rows_errored = sum(1 for rr in report_input.new_row_results if rr.error is not None)
    rows_errored += sum(1 for rr in report_input.reference_row_results if rr.error is not None)
    rows_warned = sum(1 for rr in report_input.new_row_results if rr.warnings)
    rows_warned += sum(1 for rr in report_input.reference_row_results if rr.warnings)

    comparison_summary = None
    if report_input.comparison_rows is not None:
        cs = ComparisonSummary()
        for cr in report_input.comparison_rows:
            if cr.status == ComparisonStatus.MATCHED:
                cs.matched += 1
                if cr.result == ComparisonResult.OVER_THRESHOLD:
                    cs.matched_over_threshold += 1
            elif cr.status == ComparisonStatus.NEW_ITEM:
                cs.new_items += 1
            elif cr.status == ComparisonStatus.REMOVED_ITEM:
                cs.removed_items += 1
        comparison_summary = cs

    total_cost = None
    groups_without_cost = 0
    if report_input.cost_by_key is not None:
        costed = [c for c in report_input.cost_by_key.values() if c.error_code is None]
        groups_without_cost = sum(1 for c in report_input.cost_by_key.values() if c.error_code is not None)
        total_cost = sum((c.estimated_cost for c in costed), Decimal("0"))

    return RunSummary(
        total_groups=len(groups),
        total_net_quantity_m3=total_net,
        total_boq_with_waste_m3=total_boq,
        rows_errored=rows_errored,
        rows_warned=rows_warned,
        comparison=comparison_summary,
        total_estimated_cost=total_cost,
        cost_currency=report_input.cost_currency,
        groups_without_cost=groups_without_cost,
    )


@dataclass
class ProcessingOutcome:
    success: bool
    message: str
    error_code: Optional[str] = None
    excel_path: Optional[Path] = None
    pdf_path: Optional[Path] = None
    summary: Optional[RunSummary] = None
    report_input: Optional[ReportInput] = None
    technical_detail: Optional[str] = None  # only for an optional "technical details" expander


def process_workbook(
    *,
    new_file: Path,
    new_profile: MappingProfile,
    project_name: str,
    profile_name: str,
    output_dir: Path,
    waste_percentage: Decimal = Decimal("0"),
    mismatch_tolerance_percentage: Decimal = Decimal("2.0"),
    comparison_threshold_percentage: Decimal = Decimal("5.0"),
    item_code_is_comparison_key: bool = False,
    reference_file: Optional[Path] = None,
    reference_profile: Optional[MappingProfile] = None,
    expected_columns: Optional[dict[str, list[str]]] = None,
    reference_expected_columns: Optional[dict[str, list[str]]] = None,
    unit_rates: Optional[Mapping[str, Decimal]] = None,
    cost_currency: Optional[str] = None,
    ai_provider: Optional[AIProvider] = None,
    ai_executive_summary_text: Optional[str] = None,
) -> ProcessingOutcome:
    """The single function the Streamlit app calls to run everything.
    Never raises -- every known and unknown failure mode is converted to a
    ProcessingOutcome with a plain-language message.

    ai_provider / ai_executive_summary_text (Section 40, both optional):
    passed straight through to run_full_report, which already guarantees
    a broken/absent provider never breaks report generation (Section 43).
    Neither the UI nor this controller has to duplicate that safety net.
    """
    try:
        result: GeneratedReport = run_full_report(
            new_file=new_file,
            new_profile=new_profile,
            project_name=project_name,
            profile_name=profile_name,
            output_dir=output_dir,
            waste_percentage=waste_percentage,
            mismatch_tolerance_percentage=mismatch_tolerance_percentage,
            comparison_threshold_percentage=comparison_threshold_percentage,
            item_code_is_comparison_key=item_code_is_comparison_key,
            reference_file=reference_file,
            reference_profile=reference_profile,
            expected_columns=expected_columns,
            reference_expected_columns=reference_expected_columns,
            unit_rates=unit_rates,
            cost_currency=cost_currency,
            ai_provider=ai_provider,
            ai_executive_summary_text=ai_executive_summary_text,
        )
    except FileValidationError as exc:
        return ProcessingOutcome(
            success=False,
            message=str(exc).split(": ", 1)[-1],
            error_code=exc.code.value,
        )
    except SchemaDriftError as exc:
        return ProcessingOutcome(
            success=False,
            message=str(exc).split(": ", 1)[-1],
            error_code=exc.code.value,
        )
    except Exception as exc:  # noqa: BLE001 -- last-resort guard: never surface a raw traceback
        return ProcessingOutcome(
            success=False,
            message=(
                "Processing failed unexpectedly. No report was generated. "
                "Please check the file and try again."
            ),
            technical_detail=f"{exc.__class__.__name__}: {exc}",
        )

    summary = summarize_report(result.report_input)
    return ProcessingOutcome(
        success=True,
        message="Processing completed successfully.",
        excel_path=result.excel_path,
        pdf_path=result.pdf_path,
        summary=summary,
        report_input=result.report_input,
    )
