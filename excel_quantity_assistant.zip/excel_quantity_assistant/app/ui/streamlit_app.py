"""
Excel Quantity Assistant -- Streamlit UI.

Architecture rule (Section 6): "UI contains no business logic. Streamlit
calls Services; Services orchestrate modules." Every number, validation
result, or error message shown here comes from app.ui.controller, which in
turn calls the real deterministic pipeline (app.reporting.report_service).
There is no mock or placeholder pipeline anywhere -- this file and the
automated tests in tests/integration/test_ui_controller.py call the exact
same controller functions.

Run with:
    pip install -r requirements.txt
    streamlit run app/ui/streamlit_app.py
"""
from __future__ import annotations

import tempfile
from decimal import Decimal, InvalidOperation
from pathlib import Path

import streamlit as st

from app.config.codes import SheetStructureType
from app.ingestion.row_mapper import MappingProfile
from app.profiles.profile_store import ProfileMatchOutcome
from app.ui.controller import (
    CANONICAL_FIELDS,
    build_identity_floor_synonyms,
    check_floor_configuration,
    get_profile_db_connection,
    get_workbook_headers,
    lookup_profile_for_file,
    process_workbook,
    save_profile_for_file,
    suggest_column_mapping,
    suggest_floor_column_defined,
    validate_uploaded_file,
)

st.set_page_config(page_title="Excel Quantity Assistant", page_icon=":triangular_ruler:", layout="wide")

UPLOADS_DIR = Path(tempfile.gettempdir()) / "excel_quantity_assistant_uploads"
REPORTS_DIR = Path(tempfile.gettempdir()) / "excel_quantity_assistant_reports"
UPLOADS_DIR.mkdir(parents=True, exist_ok=True)
REPORTS_DIR.mkdir(parents=True, exist_ok=True)

LINEAR_UNITS = ["m", "cm", "mm", "ft", "in"]

FIELD_LABELS = {
    "floor": "Floor",
    "element_type": "Element Type",
    "item_code": "Item Code",
    "length": "Length",
    "width": "Width",
    "height": "Height / Thickness",
    "ready_quantity": "Ready Quantity",
}


def _save_uploaded_file(uploaded_file, subdir: Path) -> Path:
    dest = subdir / uploaded_file.name
    dest.write_bytes(uploaded_file.getvalue())
    return dest


def _init_session_state() -> None:
    st.session_state.setdefault("templates", {})  # name -> {"mapping":..., "expected_columns":...}
    st.session_state.setdefault("result", None)
    st.session_state.setdefault("stage", "upload")  # upload -> map -> done
    st.session_state.setdefault("uploader_generation", 0)


def _reset_for_new_file() -> None:
    st.session_state["result"] = None
    st.session_state["stage"] = "upload"
    st.session_state["last_new_file_signature"] = None
    # Bumping this changes the file_uploader widgets' keys below, which is
    # the supported way to make Streamlit show them as empty again --
    # otherwise the previously uploaded file stays attached to the old key.
    st.session_state["uploader_generation"] += 1


def _render_header() -> None:
    st.markdown(
        "<div style='display:flex;align-items:center;gap:10px;'>"
        "<span style='font-size:26px;font-weight:700;color:#1F2937;'>Excel Quantity Assistant</span>"
        "</div>",
        unsafe_allow_html=True,
    )
    st.caption("System: OFFLINE / LOCAL — deterministic engineering quantity pipeline")
    st.divider()


def _render_mapping_form(headers_by_sheet: dict[str, list[str]], upload_path: Path) -> MappingProfile | None:
    """Section 15 Manual Mapping + Section 37: shows a deterministic
    suggestion, pre-filled but NEVER auto-applied -- the user must review
    and press 'Confirm mapping & process' before anything runs.
    """
    all_sheets = list(headers_by_sheet.keys())
    first_sheet_headers = headers_by_sheet[all_sheets[0]] if all_sheets else []
    suggestion = suggest_column_mapping(first_sheet_headers)

    st.subheader("2. Confirm column mapping")
    st.caption(
        "Detected automatically from your file's headers. Review and adjust before processing -- "
        "nothing is applied until you confirm."
    )

    none_option = "— not in this file —"
    mapping: dict[str, str] = {}
    unit_per_field: dict[str, str] = {}

    col1, col2 = st.columns(2)
    fields = list(CANONICAL_FIELDS)
    for i, field_name in enumerate(fields):
        target_col = col1 if i % 2 == 0 else col2
        options = [none_option] + first_sheet_headers
        default_value = suggestion.get(field_name, none_option)
        default_index = options.index(default_value) if default_value in options else 0
        with target_col:
            chosen = st.selectbox(
                f"{FIELD_LABELS[field_name]} column",
                options=options,
                index=default_index,
                key=f"map_{field_name}",
            )
            if chosen != none_option:
                mapping[field_name] = chosen
                if field_name in ("length", "width", "height"):
                    unit_per_field[field_name] = st.selectbox(
                        f"{FIELD_LABELS[field_name]} unit",
                        options=LINEAR_UNITS,
                        index=0,
                        key=f"unit_{field_name}",
                    )

    if "ready_quantity" in mapping:
        st.caption("Ready Quantity is accepted in m³ only in this version (see System Limitations).")
        unit_per_field["ready_quantity"] = "m3"

    floor_column_defined = suggest_floor_column_defined(mapping)
    if len(all_sheets) > 1 and not floor_column_defined:
        st.info(
            "No Floor column mapped, and this file has multiple sheets — "
            "each sheet name will be used as the Floor name."
        )
    sheet_structure_type = (
        SheetStructureType.SHEET_PER_FLOOR if len(all_sheets) > 1 or not floor_column_defined
        else SheetStructureType.SINGLE_SHEET
    )

    floor_check = check_floor_configuration(
        sheet_structure_type=sheet_structure_type, floor_column_defined=floor_column_defined
    )
    if not floor_check.ok:
        st.error(floor_check.message)
        return None

    item_code_is_key = st.checkbox(
        "Use Item Code as the comparison key (instead of Floor + Element Type)",
        value="item_code" in mapping,
    )

    floor_synonyms = build_identity_floor_synonyms(all_sheets) if not floor_column_defined else {}

    if "element_type" not in mapping:
        st.error("Please map an 'Element Type' column — it is required for every row.")
        return None

    return MappingProfile(
        sheet_structure_type=sheet_structure_type,
        column_mapping=mapping,
        unit_per_field=unit_per_field,
        floor_synonyms=floor_synonyms,
        item_code_is_comparison_key=item_code_is_key,
    )


def _render_summary(summary, cost_currency: str | None) -> None:
    st.subheader("4. Results summary")
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Aggregated groups", summary.total_groups)
    c2.metric("Total Net Quantity (m³)", f"{summary.total_net_quantity_m3:.4f}")
    c3.metric("Rows errored", summary.rows_errored)
    c4.metric("Rows with warnings", summary.rows_warned)

    if summary.comparison is not None:
        st.markdown("**Comparison (vs. reference file)**")
        cc1, cc2, cc3, cc4 = st.columns(4)
        cc1.metric("Matched", summary.comparison.matched)
        cc2.metric("Over threshold", summary.comparison.matched_over_threshold)
        cc3.metric("New items", summary.comparison.new_items)
        cc4.metric("Removed items", summary.comparison.removed_items)

    if summary.total_estimated_cost is not None:
        st.markdown("**Costing**")
        st.metric(
            f"Total Estimated Cost ({cost_currency or 'N/A'})",
            f"{summary.total_estimated_cost:,.2f}",
        )
        if summary.groups_without_cost:
            st.caption(f"{summary.groups_without_cost} group(s) had no cost data available.")

    if summary.rows_errored:
        st.warning(
            f"{summary.rows_errored} row(s) were excluded due to errors. "
            "See the 'الأخطاء والاستثناءات' sheet in the Excel report for details."
        )


def main() -> None:
    _init_session_state()
    _render_header()

    st.subheader("1. Choose an Excel file")
    gen = st.session_state["uploader_generation"]
    uploaded = st.file_uploader("New quantities file (.xlsx)", type=["xlsx"], key=f"new_upload_{gen}")
    reference_uploaded = st.file_uploader(
        "Reference file for comparison (.xlsx) — optional", type=["xlsx"], key=f"ref_upload_{gen}"
    )

    if uploaded is None:
        st.info("Upload an .xlsx file to begin.")
        return

    new_path = _save_uploaded_file(uploaded, UPLOADS_DIR)

    # A new/different file invalidates any stale column-mapping widget
    # state from a previously uploaded file (different headers) -- without
    # this, Streamlit's selectbox/text_input widgets keep their old value
    # by key across reruns, which can reference a header that no longer
    # exists in the new file and raise a StreamlitAPIException.
    file_signature = f"{uploaded.name}:{uploaded.size}"
    if st.session_state.get("last_new_file_signature") != file_signature:
        for key in list(st.session_state.keys()):
            if key.startswith("map_") or key.startswith("unit_") or key.startswith("rate_") \
                    or key.startswith("profile_select_") or key == "profile_save_name":
                del st.session_state[key]
        st.session_state["result"] = None
        st.session_state["result_profile"] = None
        st.session_state["result_save_prompt_needed"] = False
        st.session_state["result_run_settings"] = None
        st.session_state["last_new_file_signature"] = file_signature

    validation = validate_uploaded_file(new_path)
    if not validation.ok:
        st.error(f"This file cannot be processed: {validation.message}")
        return
    st.success("File validated successfully.")

    reference_path = None
    if reference_uploaded is not None:
        reference_path = _save_uploaded_file(reference_uploaded, UPLOADS_DIR)
        ref_validation = validate_uploaded_file(reference_path)
        if not ref_validation.ok:
            st.error(f"Reference file cannot be processed: {ref_validation.message}")
            return

    headers_by_sheet = get_workbook_headers(new_path)
    if not headers_by_sheet:
        st.error("No usable sheets/columns were found in this file.")
        return

    # Section 15 Profile Matching -- fingerprint the file and check the
    # local Profile DB before asking the user to map anything by hand.
    # This is a pure fingerprint-hash lookup; never AI-assisted (Section 2).
    conn = get_profile_db_connection()
    try:
        lookup = lookup_profile_for_file(conn, new_path)
    finally:
        conn.close()

    profile = None
    expected_columns = None
    save_prompt_needed = False
    default_waste, default_threshold, default_tolerance = Decimal("0"), Decimal("5.0"), Decimal("2.0")

    if lookup.outcome == ProfileMatchOutcome.AUTO_APPLY:
        chosen = lookup.options[0]
        st.subheader("2. Column mapping")
        st.success(f"This file's structure matches the saved profile '{chosen.name}' — mapping applied automatically.")
        with st.expander("Review the applied mapping"):
            st.json(dict(chosen.mapping_profile.column_mapping))
        profile = chosen.mapping_profile
        expected_columns = chosen.expected_columns
        default_waste = chosen.waste_percentage
        default_threshold = chosen.comparison_threshold_percentage
        default_tolerance = chosen.mismatch_tolerance_percentage

    elif lookup.outcome == ProfileMatchOutcome.USER_MUST_SELECT:
        st.subheader("2. Column mapping")
        st.info("Multiple saved profiles match this file's structure — choose which one to use.")
        names = [o.name for o in lookup.options]
        chosen_name = st.selectbox("Saved profile", options=names, key=f"profile_select_{gen}")
        chosen = next(o for o in lookup.options if o.name == chosen_name)
        with st.expander("Review the selected mapping"):
            st.json(dict(chosen.mapping_profile.column_mapping))
        profile = chosen.mapping_profile
        expected_columns = chosen.expected_columns
        default_waste = chosen.waste_percentage
        default_threshold = chosen.comparison_threshold_percentage
        default_tolerance = chosen.mismatch_tolerance_percentage

    else:  # OPEN_MANUAL_MAPPING -- no saved profile recognizes this file yet
        profile = _render_mapping_form(headers_by_sheet, new_path)
        if profile is None:
            return
        save_prompt_needed = True

    with st.expander("3. Advanced settings (optional)"):
        project_name = st.text_input("Project name", value=uploaded.name.rsplit(".", 1)[0])
        waste_pct = st.number_input("Waste percentage", min_value=0.0, value=float(default_waste), step=0.5)
        comparison_threshold = st.number_input(
            "Comparison threshold (%)", min_value=0.0, value=float(default_threshold), step=0.5
        )
        mismatch_tolerance = st.number_input(
            "Ready Quantity vs. dimensions mismatch tolerance (%)",
            min_value=0.0, value=float(default_tolerance), step=0.5,
        )
        enable_costing = st.checkbox("Enable costing (optional)", value=False)
        unit_rates: dict[str, Decimal] = {}
        cost_currency = None
        if enable_costing:
            cost_currency = st.text_input("Currency code", value="USD")
            st.caption("Enter a unit rate per Element Type. Leave blank to skip costing that type.")
            for et in ("COLUMN", "BEAM", "SLAB", "FOUNDATION"):
                raw_rate = st.text_input(f"Unit rate for {et}", value="", key=f"rate_{et}")
                if raw_rate.strip():
                    try:
                        unit_rates[et] = Decimal(raw_rate.strip())
                    except InvalidOperation:
                        st.error(f"Unit rate for {et} must be a number.")
                        return

    if st.button("Process file", type="primary"):
        with st.spinner("Processing — validating, calculating quantities, aggregating, building reports..."):
            outcome = process_workbook(
                new_file=new_path,
                new_profile=profile,
                project_name=project_name,
                profile_name="ui_session_profile",
                output_dir=REPORTS_DIR,
                waste_percentage=Decimal(str(waste_pct)),
                mismatch_tolerance_percentage=Decimal(str(mismatch_tolerance)),
                comparison_threshold_percentage=Decimal(str(comparison_threshold)),
                item_code_is_comparison_key=profile.item_code_is_comparison_key,
                reference_file=reference_path,
                reference_profile=profile if reference_path else None,
                unit_rates=unit_rates or None,
                cost_currency=cost_currency,
                expected_columns=expected_columns,
            )
        st.session_state["result"] = outcome
        st.session_state["result_profile"] = profile
        st.session_state["result_save_prompt_needed"] = save_prompt_needed
        st.session_state["result_run_settings"] = {
            "waste_percentage": Decimal(str(waste_pct)),
            "comparison_threshold_percentage": Decimal(str(comparison_threshold)),
            "mismatch_tolerance_percentage": Decimal(str(mismatch_tolerance)),
        }

    outcome = st.session_state.get("result")
    if outcome is None:
        return

    if not outcome.success:
        st.error(outcome.message)
        if outcome.technical_detail:
            with st.expander("Technical details (for developers)"):
                st.code(outcome.technical_detail)
        return

    st.success(outcome.message)
    _render_summary(outcome.summary, outcome.report_input.cost_currency if outcome.report_input else None)

    if st.session_state.get("result_save_prompt_needed"):
        st.subheader("Save this mapping for next time")
        st.caption(
            "This file's structure wasn't recognized, so you mapped it by hand. "
            "Save it as a Profile so future uploads of this same layout apply "
            "automatically and get Schema Drift protection (Section 16)."
        )
        profile_save_name = st.text_input("Profile name", value="", key="profile_save_name")
        if st.button("Save as Profile"):
            if not profile_save_name.strip():
                st.error("Please enter a name for this profile.")
            else:
                settings = st.session_state["result_run_settings"]
                conn = get_profile_db_connection()
                try:
                    save_profile_for_file(
                        conn,
                        name=profile_save_name.strip(),
                        path=new_path,
                        mapping_profile=st.session_state["result_profile"],
                        waste_percentage=settings["waste_percentage"],
                        comparison_threshold_percentage=settings["comparison_threshold_percentage"],
                        mismatch_tolerance_percentage=settings["mismatch_tolerance_percentage"],
                    )
                    st.success(f"Profile '{profile_save_name.strip()}' saved. Future uploads of this layout will apply it automatically.")
                    st.session_state["result_save_prompt_needed"] = False
                finally:
                    conn.close()

    st.subheader("5. Download reports")
    dcol1, dcol2 = st.columns(2)
    with dcol1:
        st.download_button(
            "Download Excel report",
            data=outcome.excel_path.read_bytes(),
            file_name=outcome.excel_path.name,
            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )
    with dcol2:
        st.download_button(
            "Download PDF report",
            data=outcome.pdf_path.read_bytes(),
            file_name=outcome.pdf_path.name,
            mime="application/pdf",
        )

    st.divider()
    if st.button("Process another file"):
        _reset_for_new_file()
        st.rerun()


if __name__ == "__main__":
    main()
