"""
Section 41 -- AI Role #2: AI-Assisted UI/UX Design Advisor.

HARD ARCHITECTURAL BOUNDARY (Section 6, Section 41, enforced by the smoke
test in tests/regression/test_ai_ui_advisor_isolation.py):

    This module and everything under app/ai/ui_advisor/ must have NO import
    path to app.quantity_engine, app.aggregation, app.comparison, or
    app.database -- not "should not", MUST NOT. The permitted input schema
    is exactly DesignBrief below: design tokens + a copy/layout brief. No
    business data of any kind.

Operating mode: primarily a design-time developer tool (a developer prompts
this with fixed design tokens + a component description, reviews suggested
markup/copy/CSS, commits it as static code). If ever exposed at runtime, it
is limited strictly to static, non-data-bound text.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional, Protocol

# NOTE: Intentionally the ONLY imports in this file. Do not add imports from
# app.quantity_engine, app.aggregation, app.comparison, or app.database --
# doing so would violate Section 41 and fail the isolation smoke test.


@dataclass(frozen=True)
class DesignTokens:
    """Section 45/46 static design tokens -- colors, fonts. No data fields."""

    color_background: str
    color_accent_primary: str
    color_accent_secondary: str
    color_card: str
    font_primary: str
    font_arabic: str


@dataclass(frozen=True)
class DesignBrief:
    """The ONLY permitted input shape for the UI/UX Advisor (Section 41)."""

    component_description: str
    tokens: DesignTokens
    copy_requirements: list[str] = field(default_factory=list)
    rtl_required: bool = False


class AIProvider(Protocol):
    def complete(self, system_prompt: str, user_prompt: str) -> str: ...


UI_ADVISOR_SYSTEM_PROMPT = (
    "You are a UI/UX design assistant for a professional engineering desktop "
    "application. You will be given fixed design tokens and a description of "
    "a UI component. Suggest copy (labels, tooltips, help text), layout, and "
    "spacing improvements. You must NEVER suggest or imply any numeric value, "
    "computed quantity, comparison result, or a reassignment of the semantic "
    "status colors (ERROR=red, WARNING=amber, DIRECT/CALCULATED indicators, "
    "OVER_THRESHOLD highlighting) -- those are fixed, deterministic, and out "
    "of scope for you. Only propose neutral/cosmetic styling and static copy."
)


def request_ui_suggestion(brief: DesignBrief, provider: Optional[AIProvider]) -> Optional[str]:
    """Ask the Advisor for a suggestion. Returns None if unavailable/failed.

    This is a design-time helper for developers; the shipped application's
    static UI (Sections 44-48) never depends on this returning anything.
    """
    if provider is None:
        return None
    try:
        import json

        user_prompt = json.dumps(
            {
                "component_description": brief.component_description,
                "tokens": brief.tokens.__dict__,
                "copy_requirements": brief.copy_requirements,
                "rtl_required": brief.rtl_required,
            },
            ensure_ascii=False,
        )
        return provider.complete(UI_ADVISOR_SYSTEM_PROMPT, user_prompt)
    except Exception:
        return None
