"""
Section 42 -- AI Provider Abstraction.
Section 43 -- Offline AI.

Never hard-codes around one AI vendor. Serves BOTH AI roles (executive_summary,
ui_advisor) with distinct prompt templates/input schemas -- the core
application does not know or need to know which provider is selected.
Switching providers never touches business logic.
"""
from __future__ import annotations

from enum import Enum
from typing import Protocol


class AIStatus(str, Enum):
    LOCAL_MODEL_AVAILABLE = "LOCAL MODEL AVAILABLE"
    LOCAL_MODEL_NOT_AVAILABLE = "LOCAL MODEL NOT AVAILABLE"
    CLOUD_PROVIDER_AVAILABLE = "AI AVAILABLE (cloud provider)"
    OFFLINE = "AI OFFLINE / UNAVAILABLE"


class AIProvider(Protocol):
    """Common interface every concrete provider implements."""

    def complete(self, system_prompt: str, user_prompt: str) -> str: ...

    def is_available(self) -> bool: ...


class NullProvider:
    """Used whenever no provider is configured. Always reports unavailable,
    never raises -- so callers relying on graceful fallback (Section 40/43)
    behave identically whether AI was never configured or failed at runtime.
    """

    def complete(self, system_prompt: str, user_prompt: str) -> str:
        raise RuntimeError("NullProvider cannot complete requests.")

    def is_available(self) -> bool:
        return False


# Concrete providers (OllamaProvider, OpenAIProvider, AnthropicProvider,
# GeminiProvider) are intentionally NOT implemented in this scaffold -- they
# are thin HTTP clients behind the same AIProvider Protocol and can be added
# without touching any module above this one.
