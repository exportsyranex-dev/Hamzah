"""
Section 40 -- AI Role #1: Local AI Executive Summary.

Receives ONLY the structured object defined below -- never raw Excel data,
never write-access to any number. If AI fails/unavailable, callers must fall
back to the static string 'Executive Summary unavailable.' (Section 40) --
the PDF/report remains fully valid either way.

This module deliberately has no import of quantity_engine, aggregation,
comparison, or database -- it only accepts the already-finalized dict shape
below, enforced by the ExecutiveSummaryInput dataclass.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional, Protocol


@dataclass(frozen=True)
class ExecutiveSummaryInput:
    """Exactly the structured object shape defined in Section 40."""

    total_reference_quantity: str
    total_new_quantity: str
    items_over_threshold: list[str] = field(default_factory=list)
    items_new: list[str] = field(default_factory=list)
    items_removed: list[str] = field(default_factory=list)
    warnings_count: int = 0
    errors_count: int = 0


class AIProvider(Protocol):
    """Matches app/ai/provider.py's AIProvider interface (Section 42)."""

    def complete(self, system_prompt: str, user_prompt: str) -> str: ...


EXECUTIVE_SUMMARY_SYSTEM_PROMPT = (
    "You are a construction-quantity reporting assistant. You will be given a "
    "small structured JSON object describing already-finalized, deterministic "
    "results (totals, item lists, counts). Write a short, plain-language "
    "executive summary of these results. Do not invent, estimate, or alter any "
    "number. Do not mention any figure that is not present in the object."
)

FALLBACK_TEXT = "Executive Summary unavailable."


def generate_executive_summary(
    summary_input: ExecutiveSummaryInput, provider: Optional[AIProvider]
) -> str:
    """Generate the narrative summary, or the static fallback on any failure.

    Section 40 / Section 43: the application never fails because local AI is
    unavailable -- any exception here is swallowed and FALLBACK_TEXT is
    returned instead.
    """
    if provider is None:
        return FALLBACK_TEXT
    try:
        import json

        user_prompt = json.dumps(summary_input.__dict__, ensure_ascii=False)
        text = provider.complete(EXECUTIVE_SUMMARY_SYSTEM_PROMPT, user_prompt)
        return text.strip() or FALLBACK_TEXT
    except Exception:
        return FALLBACK_TEXT
