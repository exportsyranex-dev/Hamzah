#!/usr/bin/env python3
"""
Minimal offline test runner used ONLY because this sandbox has no network
access to install pytest. It mimics pytest's function-based test discovery
closely enough to run this project's test suite (plain `def test_x(): assert
...` functions, no fixtures/parametrize used in this suite).

Not a replacement for pytest in real development -- requirements.txt still
declares pytest as the intended runner (Section 4 tech stack).
"""
import importlib
import sys
import traceback
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

TEST_DIRS = ["tests/unit", "tests/integration", "tests/regression", "tests/golden"]


def discover_test_files():
    files = []
    for d in TEST_DIRS:
        p = ROOT / d
        if p.exists():
            files.extend(sorted(p.glob("test_*.py")))
    return files


def module_name_for(path: Path) -> str:
    rel = path.relative_to(ROOT).with_suffix("")
    return ".".join(rel.parts)


def main() -> int:
    passed = 0
    failed = 0
    errors = []

    for path in discover_test_files():
        mod_name = module_name_for(path)
        try:
            module = importlib.import_module(mod_name)
        except Exception:
            failed += 1
            errors.append((mod_name, "<import>", traceback.format_exc()))
            continue

        test_fns = [
            getattr(module, name)
            for name in dir(module)
            if name.startswith("test_") and callable(getattr(module, name))
        ]
        for fn in test_fns:
            full_name = f"{mod_name}::{fn.__name__}"
            try:
                fn()
                passed += 1
                print(f"PASS  {full_name}")
            except AssertionError:
                failed += 1
                tb = traceback.format_exc()
                errors.append((mod_name, fn.__name__, tb))
                print(f"FAIL  {full_name}")
            except Exception:
                failed += 1
                tb = traceback.format_exc()
                errors.append((mod_name, fn.__name__, tb))
                print(f"ERROR {full_name}")

    print("\n" + "=" * 70)
    print(f"{passed} passed, {failed} failed")
    if errors:
        print("=" * 70)
        for mod_name, fn_name, tb in errors:
            print(f"\n--- {mod_name}::{fn_name} ---")
            print(tb)
    return 0 if failed == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
