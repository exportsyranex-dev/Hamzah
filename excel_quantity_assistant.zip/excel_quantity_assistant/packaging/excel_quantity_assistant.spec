# -*- mode: python ; coding: utf-8 -*-
"""
PyInstaller spec file. Build ON WINDOWS with network access (see
packaging/README_PACKAGING.md) using:

    pyinstaller packaging/excel_quantity_assistant.spec

This produces a ONEDIR build (an .exe plus a folder of dependencies), not
a single-file .exe. That is a deliberate choice, not a shortcut -- see
README_PACKAGING.md "Why onedir, not onefile" for the reasoning. It is the
standard, most reliable approach for a Streamlit app.
"""
from PyInstaller.utils.hooks import collect_all

block_cipher = None

# Streamlit ships a compiled JS/CSS frontend and reads its own package
# metadata (importlib.metadata) at runtime for version info -- both are
# easy to silently miss with a hand-written hiddenimports/datas list.
# collect_all() is the robust, community-standard way to grab a package's
# submodules, data files, AND metadata in one call. Applied to every
# third-party package this application actually imports (see
# requirements.txt) -- openpyxl and reportlab are cheap to include this
# way too and it removes an entire class of "works on my machine, fails
# when frozen" bugs (missing font metrics, missing package metadata, etc).
streamlit_imports, streamlit_datas, streamlit_binaries = collect_all("streamlit")
openpyxl_imports, openpyxl_datas, openpyxl_binaries = collect_all("openpyxl")
reportlab_imports, reportlab_datas, reportlab_binaries = collect_all("reportlab")

all_hiddenimports = streamlit_imports + openpyxl_imports + reportlab_imports
all_datas = streamlit_datas + openpyxl_datas + reportlab_datas
all_binaries = streamlit_binaries + openpyxl_binaries + reportlab_binaries

# The application's own source, bundled as plain files (not just compiled
# into the executable via normal import analysis) -- Streamlit's
# script-runner needs a real file path to app/ui/streamlit_app.py at
# runtime (see run_app.py's docstring for why), so app/ must exist as an
# actual folder inside the frozen bundle, not just be importable.
all_datas += [("../app", "app")]

a = Analysis(
    ["run_app.py"],
    pathex=[],
    binaries=all_binaries,
    datas=all_datas,
    hiddenimports=all_hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    cipher=block_cipher,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name="ExcelQuantityAssistant",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,
    console=True,  # keep a console window -- see README_PACKAGING.md
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=None,
)

coll = COLLECT(
    exe,
    a.binaries,
    a.zipfiles,
    a.datas,
    strip=False,
    upx=False,
    upx_exclude=[],
    name="ExcelQuantityAssistant",
)
