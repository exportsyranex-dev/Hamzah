; Inno Setup script for Excel Quantity Assistant.
; Compile with Inno Setup Compiler (ISCC.exe) AFTER running
; packaging\build_windows.bat (this script packages that build's output).
;
;   "C:\Program Files (x86)\Inno Setup 6\ISCC.exe" packaging\installer\excel_quantity_assistant.iss
;
; Inno Setup itself is a separate, free tool: https://jrsoftware.org/isinfo.php
; (not something this sandbox could install or run -- see
; packaging/README_PACKAGING.md for what was and wasn't verifiable here.)

#define MyAppName "Excel Quantity Assistant"
#define MyAppVersion "1.0.0"
#define MyAppExeName "ExcelQuantityAssistant.exe"
#define MyAppPublisher "Excel Quantity Assistant"

[Setup]
; Regenerate this GUID (Inno Setup IDE: Tools > Generate GUID) before a
; real release -- a fixed shared AppId is fine for local testing.
AppId={{B6E3B6B6-6E2F-4A0F-9B7E-1A2C3D4E5F60}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\{#MyAppName}
DefaultGroupName={#MyAppName}
DisableProgramGroupPage=yes
OutputDir=..\..\dist\installer
OutputBaseFilename=ExcelQuantityAssistant-Setup
Compression=lzma
SolidCompression=yes
WizardStyle=modern
ArchitecturesInstallIn64BitMode=x64compatible

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "{cm:CreateDesktopIcon}"; GroupDescription: "{cm:AdditionalIcons}"; Flags: unchecked

[Files]
; Packages the ENTIRE PyInstaller onedir output produced by
; packaging\build_windows.bat (dist\ExcelQuantityAssistant\*).
Source: "..\..\dist\ExcelQuantityAssistant\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{group}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"
Name: "{group}\{cm:UninstallProgram,{#MyAppName}}"; Filename: "{uninstallexe}"
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "{cm:LaunchProgram,{#StringChange(MyAppName, '&', '&&')}}"; Flags: nowait postinstall skipifsilent
