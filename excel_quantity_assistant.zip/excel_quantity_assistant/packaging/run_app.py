"""
Packaging entry point for PyInstaller. This file is NOT part of the
application's business logic -- it is a thin launcher whose only job is:

1. Work out where the bundled `app/` package lives (differs between a
   normal `python run_app.py` run and a frozen PyInstaller executable,
   where everything is unpacked under `sys._MEIPASS`).
2. Put that location on `sys.path` so `import app...` resolves correctly
   from inside the frozen bundle (Streamlit's own script-runner re-executes
   app/ui/streamlit_app.py by file path, and that file does
   `from app.ui.controller import ...`, `from app.config...` etc.).
3. Hand off to Streamlit's own CLI entry point exactly as if the user had
   typed `streamlit run app/ui/streamlit_app.py` in a terminal -- Streamlit
   requires a real file path (not a Python function call) because its
   rerun-on-interaction mechanism re-executes that file's source on every
   widget interaction. See packaging/README_PACKAGING.md for why this
   approach was chosen over other options.
4. Open the default browser once the local server is likely to be ready.

Nothing here computes an engineering quantity, reads a Profile, or touches
report generation -- all of that is the unmodified `app/` package.
"""
from __future__ import annotations

import sys
import threading
import time
import webbrowser
from pathlib import Path

DEFAULT_PORT = 8501
DEFAULT_URL = f"http://localhost:{DEFAULT_PORT}"


def resource_root() -> Path:
    """Where the bundled `app/` package lives.

    Frozen (PyInstaller): sys._MEIPASS is the temp/onedir extraction root
    that the .spec file's `datas` copied `app/` into (see
    excel_quantity_assistant.spec: datas=[('../app', 'app')]).
    Not frozen (plain `python packaging/run_app.py`, e.g. to sanity-check
    this launcher without building an EXE): the project root, one level up
    from this file's own `packaging/` directory.
    """
    if getattr(sys, "frozen", False) and hasattr(sys, "_MEIPASS"):
        return Path(sys._MEIPASS)
    return Path(__file__).resolve().parent.parent


def _open_browser_when_ready(url: str, timeout_seconds: float = 15.0) -> None:
    """Best-effort: open the default browser once the server is likely up.

    Streamlit's own `--server.headless=false` behavior already tries to
    open a browser itself on most platforms; this is a deliberate second,
    independent attempt so a packaged double-click experience still opens
    a browser even if Streamlit's own auto-open is suppressed by the
    environment (some Windows setups block it). Failing to open a browser
    here is not fatal -- the user can always open the URL manually, which
    is why this runs in a background thread rather than blocking startup.
    """
    import urllib.request

    deadline = time.time() + timeout_seconds
    while time.time() < deadline:
        try:
            urllib.request.urlopen(url, timeout=1)
            break
        except Exception:
            time.sleep(0.5)
    try:
        webbrowser.open(url)
    except Exception:
        pass  # never fatal -- the user can open the URL manually


def main() -> None:
    root = resource_root()
    app_root_str = str(root)
    if app_root_str not in sys.path:
        sys.path.insert(0, app_root_str)

    target_script = root / "app" / "ui" / "streamlit_app.py"
    if not target_script.exists():
        print(f"FATAL: could not find bundled app at {target_script}")
        print("This indicates a packaging problem, not an application bug.")
        print("See packaging/README_PACKAGING.md for how the bundle is laid out.")
        sys.exit(1)

    threading.Thread(target=_open_browser_when_ready, args=(DEFAULT_URL,), daemon=True).start()

    import streamlit.web.cli as stcli

    sys.argv = [
        "streamlit",
        "run",
        str(target_script),
        "--server.port", str(DEFAULT_PORT),
        "--server.headless", "false",
        "--global.developmentMode", "false",
        "--browser.gatherUsageStats", "false",
    ]
    sys.exit(stcli.main())


if __name__ == "__main__":
    main()
