# Packaging Excel Quantity Assistant for Windows

## What this sandbox could and could not do

**Could not do here (no network, no Windows, confirmed by direct test):**
`pip install pyinstaller`, `pip install streamlit`, running PyInstaller
itself, running the resulting EXE, or opening it in a browser. This
sandbox is Linux with no internet access. Nothing in this document is
presented as "already built and verified" — it is a real, complete build
setup that **you run yourself** on a Windows machine with internet access.

**Was done here:**
- Audited every path in `app/` for `Path(__file__)`-relative or
  otherwise install-location-dependent logic — none exists (see
  `app/config/settings.py`; already fixed in an earlier pass and
  re-verified now via `grep -rn "__file__" app/` → only a comment,
  no actual code depends on it).
- Wrote a PyInstaller entry point (`run_app.py`) and `.spec` file that
  follow the documented, community-standard approach for packaging a
  Streamlit app, including the two well-known Streamlit+PyInstaller
  pitfalls (missing static frontend assets, missing package metadata —
  see "Known risk areas" below).
- Wrote Windows build scripts (`.bat` and `.ps1`) that install
  dependencies and invoke PyInstaller with correct arguments.
- Wrote an Inno Setup installer script.
- Did **not** touch any file under `app/` or `tests/` — no business logic
  changed, per your instruction.

---

## One-step build (run this on your Windows machine)

**Prerequisites (one-time, on the build machine only):**
- Python 3.11+ on PATH, with internet access.
- [Inno Setup](https://jrsoftware.org/isdl.php) installed (free) — only
  needed to produce the final single installer file; if it's missing,
  the script below still builds the app and tells you exactly what to do.

**Then just double-click, or run:**
```
packaging\build_windows.bat
```

This one script does everything automatically: creates a build virtual
environment, installs all dependencies, runs PyInstaller, detects Inno
Setup if installed, and compiles the final installer. No other command is
needed. On success, the last thing it prints is:

```
dist\installer\ExcelQuantityAssistant-Setup.exe
```

**That single file is the end-user deliverable.** Copy only that one file
to any Windows machine, double-click it, and it installs the whole
application (Start Menu shortcut, optional Desktop shortcut, uninstaller)
with no Python, no terminal, and no internet needed on that machine.

(`packaging\build_windows.ps1` is the PowerShell equivalent, if preferred.)

---

## Why onedir, not onefile

PyInstaller can also produce a single `.exe` file ("onefile"), but it
works by re-extracting the entire bundle to a temp folder on **every
launch**, which is slow and has a documented history of flaky interactions
with Streamlit specifically (file-watching, static asset serving). Onedir
(a folder containing the `.exe` plus its dependencies, extracted once at
build time) is the standard recommendation for packaging Streamlit apps
and is what this setup produces. The Inno Setup installer above still
gives the end user a single normal-looking installer experience even
though the underlying build is onedir.

---

## Known risk areas (real, not hypothetical — read before you build)

These are genuine, documented pitfalls of PyInstaller + Streamlit
specifically, not invented caveats:

1. **`PackageNotFoundError` or `ModuleNotFoundError` when you run the built
   EXE.** Streamlit reads its own and some dependencies' version metadata
   via `importlib.metadata` at runtime, and dynamically imports a few
   submodules PyInstaller's static analysis can miss. The `.spec` file
   already uses `collect_all("streamlit")` (and the same for `openpyxl`,
   `reportlab`) specifically to prevent this — this is the standard fix —
   but Streamlit's exact runtime dependencies do shift between versions,
   so **if you still see this error for some other package name**, the
   fix is: add that package to the `collect_all(...)` calls (or at minimum
   `copy_metadata("<package>")` + add it to `hiddenimports`) in
   `packaging/excel_quantity_assistant.spec`, then rebuild.
2. **Antivirus/SmartScreen flags on first run.** Unsigned PyInstaller
   EXEs commonly trigger a Windows SmartScreen warning ("Windows protected
   your PC") the first time. This is expected for an unsigned build, not a
   sign of a broken build — code-signing is a separate, later step if
   this app is going to be distributed publicly.
3. **First launch is slower than a normal `streamlit run`.** The bundle
   has to initialize before the local server responds; `run_app.py`
   already waits for the server to answer before opening the browser
   (see its `_open_browser_when_ready`), but the console window may sit
   for a few seconds first — that is expected, not a hang, unless it
   never resolves (see the test checklist below for how long is normal
   vs. how long means something is actually wrong).
4. **A firewall prompt** may appear the first time (`ExcelQuantityAssistant.exe`
   binding to `localhost:8501`). Allowing it is expected and required —
   it's a local-only server, never accessed from outside the machine.

---

## Manual test checklist (for you to run on your Windows laptop)

This is exactly the "real Windows browser runtime" check that could not
be done in this sandbox. Suggested order:

1. **Launch.** Double-click `ExcelQuantityAssistant.exe`. A console window
   should appear, then your default browser should open to
   `http://localhost:8501` showing the app within roughly 5–15 seconds.
   *If it never opens:* open that URL manually in a browser while the
   console window is still running.
2. **Upload a real .xlsx file** (any of your own quantity takeoff files,
   or use one of the small fixtures under `tests/fixtures/data/` in this
   project as a first smoke test). Confirm the file-validation success
   message appears, not a Python traceback.
3. **Confirm the column mapping** shown, adjust if needed, click
   **Process file**. Confirm a results summary appears with real numbers.
4. **Download both the Excel and PDF reports** and open them (in Excel/a
   PDF viewer) — confirm the 5 Excel sheets and PDF sections described in
   the main `README.md` actually contain your data.
5. **Save this mapping as a Profile** (name it anything), then click
   **Process another file**, and **upload the exact same file again.**
   Confirm it now says the profile was applied automatically and does NOT
   show the manual mapping form again.
6. **Close the app entirely** (close the console window), relaunch the
   EXE, and upload that same file a third time. Confirm the saved Profile
   is still recognized — this proves persistence survives a real restart,
   not just "process another file" within one run.
7. **Upload a deliberately different file** — e.g. delete or rename a
   column in a copy of the same file — under the same Profile. Confirm you
   get a clear Schema Drift message naming the specific column, not a
   crash.
8. **Check where files landed:** open `%APPDATA%\ExcelQuantityAssistant\`
   in File Explorer. You should see `data\profiles.db` and it should
   **not** be inside the installed program folder.

If every step above behaves as described, the packaged build is genuinely
working end to end on Windows, in a real browser — which is the one thing
that could not be claimed from this sandbox.

---

## Files that must ship together

Whichever way you distribute this (raw folder or the Inno Setup
installer), the end user needs the **entire** `dist\ExcelQuantityAssistant\`
folder — not just the `.exe` file alone. The installer
(`ExcelQuantityAssistant-Setup.exe`) already handles this correctly by
packaging the whole folder; if you instead hand someone the raw `dist`
output directly (e.g. by zipping it), zip the **whole folder**, not just
the `.exe`.

## Does the end user need Python or the internet?

No, to both, once built. The onedir bundle contains its own embedded
Python interpreter and all dependencies (Streamlit, openpyxl, reportlab,
and everything they need). The application itself never makes a network
call (§5 Local-First) — the only network-ish thing that happens is the
EXE opening `http://localhost:...`, which is a local-only address, not the
internet.
