# Build script for Excel Quantity Assistant -- Windows EXE (PowerShell).
# Run from the project root:
#     .\packaging\build_windows.ps1
#
# Requires: Python 3.11+ on PATH, and internet access (to pip install
# streamlit/openpyxl/reportlab/pyinstaller). Does not modify application
# source code.

$ErrorActionPreference = "Stop"

$ProjectRoot = Split-Path -Parent $PSScriptRoot
Set-Location $ProjectRoot

Write-Host "=== Excel Quantity Assistant - Windows build ===" -ForegroundColor Cyan
Write-Host "Project root: $ProjectRoot"

if (-not (Test-Path ".build_venv")) {
    Write-Host "Creating build virtual environment..."
    python -m venv .build_venv
}

& ".build_venv\Scripts\Activate.ps1"

Write-Host "Installing runtime + build dependencies..."
python -m pip install --upgrade pip
pip install -r requirements.txt
pip install -r packaging\requirements-build.txt

Write-Host "Running PyInstaller..."
Push-Location packaging
try {
    pyinstaller excel_quantity_assistant.spec --distpath ..\dist --workpath ..\build --noconfirm
} finally {
    Pop-Location
}

$ExePath = Join-Path $ProjectRoot "dist\ExcelQuantityAssistant\ExcelQuantityAssistant.exe"
if (-not (Test-Path $ExePath)) {
    Write-Host "Build finished but the expected EXE was not found at $ExePath" -ForegroundColor Red
    Write-Host "Check the PyInstaller output above for errors."
    exit 1
}

Write-Host ""
Write-Host "=== PyInstaller bundle complete ===" -ForegroundColor Green
Write-Host "Looking for Inno Setup Compiler to finish the installer automatically..."

$IsccCandidates = @(
    "${env:ProgramFiles(x86)}\Inno Setup 6\ISCC.exe",
    "${env:ProgramFiles}\Inno Setup 6\ISCC.exe"
)
$Iscc = $IsccCandidates | Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $Iscc) {
    $Iscc = (Get-Command ISCC.exe -ErrorAction SilentlyContinue).Source
}

if (-not $Iscc) {
    Write-Host ""
    Write-Host "Inno Setup was not found on this machine, so the final installer" -ForegroundColor Yellow
    Write-Host "could not be built automatically. Install it once (free, one-time"
    Write-Host "only, needs internet just for this): https://jrsoftware.org/isdl.php"
    Write-Host "Then re-run this script, or run it manually:"
    Write-Host "  & `"${env:ProgramFiles(x86)}\Inno Setup 6\ISCC.exe`" packaging\installer\excel_quantity_assistant.iss"
    exit 0
}

Write-Host "Found Inno Setup: $Iscc"
Write-Host "Building the final installer..."
& $Iscc "packaging\installer\excel_quantity_assistant.iss"
if ($LASTEXITCODE -ne 0) {
    Write-Host "FAILED: Inno Setup compilation failed. See errors above." -ForegroundColor Red
    exit 1
}

Write-Host ""
Write-Host "================================================================" -ForegroundColor Green
Write-Host "  DONE. Your single installer file is ready at:"
Write-Host "  $ProjectRoot\dist\installer\ExcelQuantityAssistant-Setup.exe"
Write-Host "================================================================" -ForegroundColor Green
Write-Host "Copy that ONE file to any Windows machine, double-click it, and"
Write-Host "follow the installer. No Python, no terminal, no internet needed"
Write-Host "on that machine afterward."
