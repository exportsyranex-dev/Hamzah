@echo off
REM Excel Quantity Assistant -- ONE-STEP Windows build.
REM Double-click this file (or run it from the project root). It builds
REM the PyInstaller bundle AND, if Inno Setup is installed, compiles the
REM final ExcelQuantityAssistant-Setup.exe automatically -- no other
REM commands needed.
REM
REM Requires: Python 3.11+ on PATH, and internet access (this build step
REM only -- the installed application itself needs neither afterward).
REM This script does not modify any application source code.

setlocal

set PROJECT_ROOT=%~dp0..
cd /d "%PROJECT_ROOT%"

echo === Excel Quantity Assistant - Windows build ===
echo Project root: %PROJECT_ROOT%

if not exist ".build_venv" (
    echo Creating build virtual environment...
    python -m venv .build_venv
)

call .build_venv\Scripts\activate.bat

echo Installing runtime + build dependencies...
python -m pip install --upgrade pip
pip install -r requirements.txt
pip install -r packaging\requirements-build.txt
if errorlevel 1 (
    echo FAILED: dependency installation failed. See errors above.
    exit /b 1
)

echo Running PyInstaller...
cd packaging
pyinstaller excel_quantity_assistant.spec --distpath ..\dist --workpath ..\build --noconfirm
if errorlevel 1 (
    echo FAILED: PyInstaller build failed. See errors above.
    cd /d "%PROJECT_ROOT%"
    exit /b 1
)
cd /d "%PROJECT_ROOT%"

if not exist "dist\ExcelQuantityAssistant\ExcelQuantityAssistant.exe" (
    echo FAILED: expected EXE was not produced. See PyInstaller output above.
    exit /b 1
)

echo.
echo === PyInstaller bundle complete ===
echo Looking for Inno Setup Compiler to finish the installer automatically...

set ISCC_EXE=
set PF86=%ProgramFiles(x86)%
set PF64=%ProgramFiles%
if exist "%PF86%\Inno Setup 6\ISCC.exe" set ISCC_EXE=%PF86%\Inno Setup 6\ISCC.exe
if not defined ISCC_EXE if exist "%PF64%\Inno Setup 6\ISCC.exe" set ISCC_EXE=%PF64%\Inno Setup 6\ISCC.exe
if not defined ISCC_EXE (
    for %%P in (ISCC.exe) do (
        if not defined ISCC_EXE set ISCC_EXE=%%~$PATH:P
    )
)

if not defined ISCC_EXE (
    echo.
    echo Inno Setup was not found on this machine, so the final installer
    echo could not be built automatically. Install it once (free, one-time
    echo only, needs internet just for this): https://jrsoftware.org/isdl.php
    echo Then re-run this script, or run it manually:
    echo   "%PF86%\Inno Setup 6\ISCC.exe" packaging\installer\excel_quantity_assistant.iss
    exit /b 0
)

echo Found Inno Setup: %ISCC_EXE%
echo Building the final installer...
"%ISCC_EXE%" packaging\installer\excel_quantity_assistant.iss
if errorlevel 1 (
    echo FAILED: Inno Setup compilation failed. See errors above.
    exit /b 1
)

echo.
echo ================================================================
echo   DONE. Your single installer file is ready at:
echo   %PROJECT_ROOT%\dist\installer\ExcelQuantityAssistant-Setup.exe
echo ================================================================
echo Copy that ONE file to any Windows machine, double-click it, and
echo follow the installer. No Python, no terminal, no internet needed
echo on that machine afterward.

endlocal
