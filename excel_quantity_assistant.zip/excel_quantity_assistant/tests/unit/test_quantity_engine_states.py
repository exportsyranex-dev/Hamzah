from decimal import Decimal

from app.config.codes import ErrorCode, QuantitySource, WarningCode
from app.quantity_engine.engine import resolve_ready_quantity_state


def _dims():
    return {"length": Decimal("5.00"), "width": Decimal("0.30"), "height": Decimal("2.80")}


def test_state_a_direct_ready_quantity_no_dimensions():
    trace, error, warnings = resolve_ready_quantity_state(
        sheet="S", row=1,
        ready_quantity_present=True, ready_quantity_valid=True,
        ready_quantity_m3=Decimal("4.2"),
        dimensions_valid=False, dimensions_m={},
        formula_id="rectangular_prism_volume",
        mismatch_tolerance_percentage=Decimal("2.0"),
    )
    assert error is None
    assert trace.source == QuantitySource.DIRECT
    assert trace.result_m3 == Decimal("4.2")
    assert warnings == []


def test_state_a_direct_with_matching_dimensions_no_warning():
    trace, error, warnings = resolve_ready_quantity_state(
        sheet="S", row=1,
        ready_quantity_present=True, ready_quantity_valid=True,
        ready_quantity_m3=Decimal("4.2000"),
        dimensions_valid=True, dimensions_m=_dims(),  # 5.00*0.30*2.80 = 4.2000
        formula_id="rectangular_prism_volume",
        mismatch_tolerance_percentage=Decimal("2.0"),
    )
    assert error is None
    assert trace.source == QuantitySource.DIRECT
    assert trace.result_m3 == Decimal("4.2000")
    assert warnings == []


def test_state_a_direct_with_mismatched_dimensions_warns_but_keeps_direct_value():
    # calculated = 4.2000, direct = 5.0 -> diff ~ 19% >> 2% tolerance
    trace, error, warnings = resolve_ready_quantity_state(
        sheet="S", row=7,
        ready_quantity_present=True, ready_quantity_valid=True,
        ready_quantity_m3=Decimal("5.0"),
        dimensions_valid=True, dimensions_m=_dims(),
        formula_id="rectangular_prism_volume",
        mismatch_tolerance_percentage=Decimal("2.0"),
    )
    assert error is None
    assert trace.source == QuantitySource.DIRECT
    assert trace.result_m3 == Decimal("5.0")  # stored value stays DIRECT regardless
    assert len(warnings) == 1
    assert warnings[0].code == WarningCode.READY_QUANTITY_CALCULATED_MISMATCH


def test_state_b_calculated_from_dimensions():
    trace, error, warnings = resolve_ready_quantity_state(
        sheet="S", row=2,
        ready_quantity_present=False, ready_quantity_valid=False,
        ready_quantity_m3=None,
        dimensions_valid=True, dimensions_m=_dims(),
        formula_id="rectangular_prism_volume",
        mismatch_tolerance_percentage=Decimal("2.0"),
    )
    assert error is None
    assert trace.source == QuantitySource.CALCULATED
    assert trace.result_m3 == Decimal("4.2000")


def test_state_c_invalid_ready_quantity_never_falls_back_to_dimensions():
    trace, error, warnings = resolve_ready_quantity_state(
        sheet="S", row=3,
        ready_quantity_present=True, ready_quantity_valid=False,
        ready_quantity_m3=None,
        dimensions_valid=True, dimensions_m=_dims(),  # valid dims present but must be ignored
        formula_id="rectangular_prism_volume",
        mismatch_tolerance_percentage=Decimal("2.0"),
    )
    assert trace is None
    assert error is not None
    assert error.code == ErrorCode.INVALID_READY_QUANTITY


def test_state_d_no_quantity_source_available():
    trace, error, warnings = resolve_ready_quantity_state(
        sheet="S", row=4,
        ready_quantity_present=False, ready_quantity_valid=False,
        ready_quantity_m3=None,
        dimensions_valid=False, dimensions_m={},
        formula_id="rectangular_prism_volume",
        mismatch_tolerance_percentage=Decimal("2.0"),
    )
    assert trace is None
    assert error is not None
    assert error.code == ErrorCode.NO_QUANTITY_SOURCE_AVAILABLE
