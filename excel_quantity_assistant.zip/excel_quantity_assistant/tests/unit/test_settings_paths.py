import importlib
import os
import sys
from contextlib import contextmanager
from pathlib import Path


@contextmanager
def _patched_platform_and_env(platform_value, env=None):
    """Manual monkeypatch (no pytest fixture injection needed) that reloads
    app.config.settings under a faked sys.platform/environment, then
    restores everything and reloads again on exit so later tests in the
    same process see the real platform/env.
    """
    import app.config.settings as settings

    original_platform = sys.platform
    original_env = {k: os.environ.get(k) for k in (env or {})}
    try:
        sys.platform = platform_value
        for k, v in (env or {}).items():
            os.environ[k] = v
        yield importlib.reload(settings)
    finally:
        sys.platform = original_platform
        for k, v in original_env.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v
        importlib.reload(settings)


def test_windows_uses_appdata_roaming():
    with _patched_platform_and_env("win32", {"APPDATA": r"C:\Users\Test\AppData\Roaming"}) as settings:
        assert settings.APP_DATA_DIR == Path(r"C:\Users\Test\AppData\Roaming") / "ExcelQuantityAssistant"


def test_macos_uses_application_support():
    with _patched_platform_and_env("darwin") as settings:
        expected = Path.home() / "Library" / "Application Support" / "ExcelQuantityAssistant"
        assert settings.APP_DATA_DIR == expected


def test_linux_uses_xdg_data_home_when_set():
    with _patched_platform_and_env("linux", {"XDG_DATA_HOME": "/custom/data/home"}) as settings:
        assert settings.APP_DATA_DIR == Path("/custom/data/home") / "ExcelQuantityAssistant"


def test_paths_never_point_inside_the_installed_package_directory():
    """The bug being prevented: a packaged app installed to a read-only
    location (e.g. Program Files) must not try to write its database next
    to its own installed files."""
    import app.config.settings as settings

    app_package_dir = Path(settings.__file__).resolve().parents[1]  # .../app
    assert app_package_dir not in settings.DB_PATH.parents
    assert app_package_dir not in settings.REPORTS_DIR.parents


def test_db_path_and_reports_dir_are_under_app_data_dir():
    import app.config.settings as settings

    assert settings.APP_DATA_DIR in settings.DB_PATH.parents
    assert settings.APP_DATA_DIR in settings.REPORTS_DIR.parents
