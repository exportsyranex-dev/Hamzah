import sqlite3
import tempfile
from decimal import Decimal
from pathlib import Path

from app.config.codes import SheetStructureType
from app.database import db
from app.profiles.profile_store import load_expected_columns, save_profile


def test_fresh_database_has_expected_columns_json_column():
    with tempfile.TemporaryDirectory() as tmp:
        conn = db.get_connection(Path(tmp) / "profiles.db")
        db.initialize_schema(conn)
        cols = {row["name"] for row in conn.execute("PRAGMA table_info(template_profiles)")}
        assert "expected_columns_json" in cols
        conn.close()


def test_migration_adds_column_to_a_pre_existing_database_missing_it():
    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp) / "profiles.db"
        conn = sqlite3.connect(str(path))
        # Simulate an "old" database created before expected_columns_json existed.
        old_schema = db.SCHEMA.replace(",\n    expected_columns_json TEXT,", ",")
        conn.executescript(old_schema)
        conn.commit()
        cols_before = {row[1] for row in conn.execute("PRAGMA table_info(template_profiles)")}
        assert "expected_columns_json" not in cols_before
        conn.row_factory = sqlite3.Row
        conn.close()

        # Now open through the normal path -- migration should add it.
        conn2 = db.get_connection(path)
        db.initialize_schema(conn2)
        cols_after = {row["name"] for row in conn2.execute("PRAGMA table_info(template_profiles)")}
        assert "expected_columns_json" in cols_after
        conn2.close()


def test_migration_is_idempotent_when_run_twice():
    with tempfile.TemporaryDirectory() as tmp:
        conn = db.get_connection(Path(tmp) / "profiles.db")
        db.initialize_schema(conn)
        db.initialize_schema(conn)  # must not raise "duplicate column" on second call
        conn.close()


def test_save_and_load_expected_columns_round_trip():
    with tempfile.TemporaryDirectory() as tmp:
        conn = db.get_connection(Path(tmp) / "profiles.db")
        db.initialize_schema(conn)

        expected_cols = {"GF": ["Floor", "Element Type", "Width"], "L1": ["Floor", "Width"]}
        profile_id = save_profile(
            conn, name="test_profile", fingerprint_hash="abc123",
            column_mapping={"floor": "Floor"}, sheet_structure_type=SheetStructureType.SHEET_PER_FLOOR,
            unit_per_field={"width": "m"}, waste_percentage=Decimal("0"), decimal_precision=28,
            floor_synonyms={}, type_formula_map={}, item_code_is_comparison_key=False,
            comparison_threshold_percentage=Decimal("5"), mismatch_tolerance_percentage=Decimal("2"),
            floor_column_defined=True, expected_columns=expected_cols,
        )
        row = conn.execute("SELECT * FROM template_profiles WHERE id = ?", (profile_id,)).fetchone()
        loaded = load_expected_columns(row)
        assert loaded == expected_cols
        conn.close()


def test_save_profile_without_expected_columns_stores_null_and_loads_none():
    with tempfile.TemporaryDirectory() as tmp:
        conn = db.get_connection(Path(tmp) / "profiles.db")
        db.initialize_schema(conn)

        profile_id = save_profile(
            conn, name="test_profile", fingerprint_hash="xyz789",
            column_mapping={"floor": "Floor"}, sheet_structure_type=SheetStructureType.SHEET_PER_FLOOR,
            unit_per_field={}, waste_percentage=Decimal("0"), decimal_precision=28,
            floor_synonyms={}, type_formula_map={}, item_code_is_comparison_key=False,
            comparison_threshold_percentage=Decimal("5"), mismatch_tolerance_percentage=Decimal("2"),
            floor_column_defined=True,
        )
        row = conn.execute("SELECT * FROM template_profiles WHERE id = ?", (profile_id,)).fetchone()
        assert load_expected_columns(row) is None
        conn.close()
