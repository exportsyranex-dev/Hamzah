from app.utils.fingerprint import compute_fingerprint


def test_fingerprint_ignores_sheet_and_column_order():
    fp1 = compute_fingerprint({"Level 1": ["A", "B"], "Level 2": ["C", "D"]})
    fp2 = compute_fingerprint({"Level 2": ["D", "C"], "Level 1": ["B", "A"]})
    assert fp1 == fp2


def test_fingerprint_changes_if_columns_differ():
    fp1 = compute_fingerprint({"Level 1": ["A", "B"]})
    fp2 = compute_fingerprint({"Level 1": ["A", "B", "C"]})
    assert fp1 != fp2


def test_fingerprint_is_deterministic_sha256_hex():
    fp = compute_fingerprint({"S": ["A"]})
    assert len(fp) == 64
    int(fp, 16)  # must be valid hex
