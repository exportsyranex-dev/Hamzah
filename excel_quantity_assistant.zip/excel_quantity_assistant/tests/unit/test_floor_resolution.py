import pytest

from app.config.codes import SheetStructureType
from app.validation.floor_resolution import FloorUnresolvedError, resolve_floor


def test_case1_floor_column_defined_and_valid():
    floor = resolve_floor(
        sheet_structure_type=SheetStructureType.SINGLE_SHEET,
        floor_column_defined=True,
        floor_column_value="GF",
        sheet_name="Sheet1",
        floor_synonyms={"GF": "Ground Floor"},
    )
    assert floor == "Ground Floor"


def test_case1_floor_column_defined_but_blank_raises():
    with pytest.raises(FloorUnresolvedError):
        resolve_floor(
            sheet_structure_type=SheetStructureType.SINGLE_SHEET,
            floor_column_defined=True,
            floor_column_value="   ",
            sheet_name="Sheet1",
            floor_synonyms={},
        )


def test_case1_never_falls_back_to_sheet_name():
    """Even though sheet_name has a synonym, Case 1 must ignore it once a
    Floor column is defined and blank."""
    with pytest.raises(FloorUnresolvedError):
        resolve_floor(
            sheet_structure_type=SheetStructureType.SHEET_PER_FLOOR,
            floor_column_defined=True,
            floor_column_value="",
            sheet_name="GF",
            floor_synonyms={"GF": "Ground Floor"},
        )


def test_case2_sheet_per_floor_synonym_resolution():
    floor = resolve_floor(
        sheet_structure_type=SheetStructureType.SHEET_PER_FLOOR,
        floor_column_defined=False,
        floor_column_value=None,
        sheet_name="الدور الأرضي",
        floor_synonyms={"الدور الأرضي": "Ground Floor"},
    )
    assert floor == "Ground Floor"


def test_case2_unmapped_sheet_name_raises():
    with pytest.raises(FloorUnresolvedError):
        resolve_floor(
            sheet_structure_type=SheetStructureType.SHEET_PER_FLOOR,
            floor_column_defined=False,
            floor_column_value=None,
            sheet_name="MysterySheet",
            floor_synonyms={"GF": "Ground Floor"},
        )


def test_case2_single_sheet_with_no_floor_column_asserts():
    """This configuration should have been rejected at profile save time
    (see test_profile_store.py) and must never reach resolve_floor()."""
    with pytest.raises(AssertionError):
        resolve_floor(
            sheet_structure_type=SheetStructureType.SINGLE_SHEET,
            floor_column_defined=False,
            floor_column_value=None,
            sheet_name="Sheet1",
            floor_synonyms={},
        )
