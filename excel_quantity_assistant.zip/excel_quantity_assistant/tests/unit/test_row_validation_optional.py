from decimal import Decimal

from app.config.codes import ErrorCode
from app.validation.row_validation import (
    validate_element_type,
    validate_optional_dimension,
    validate_ready_quantity,
)


def test_optional_dimension_blank_is_not_an_error():
    value, issues = validate_optional_dimension(
        sheet="S", row=1, field_name="Width", raw_value=None, unit="m"
    )
    assert value is None
    assert issues == []


def test_optional_dimension_blank_string_is_not_an_error():
    value, issues = validate_optional_dimension(
        sheet="S", row=1, field_name="Width", raw_value="   ", unit="m"
    )
    assert value is None
    assert issues == []


def test_optional_dimension_present_but_garbage_is_an_error():
    # The spec's own example: Width = '-' -> INVALID_NUMERIC_VALUE.
    value, issues = validate_optional_dimension(
        sheet="Level 02", row=17, field_name="Width", raw_value="-", unit="m"
    )
    assert value is None
    assert len(issues) == 1
    assert issues[0].code == ErrorCode.INVALID_NUMERIC_VALUE


def test_optional_dimension_present_and_valid():
    value, issues = validate_optional_dimension(
        sheet="S", row=1, field_name="Width", raw_value="0.30", unit="m"
    )
    assert value == Decimal("0.30")
    assert issues == []


def test_optional_dimension_present_but_zero_is_an_error():
    value, issues = validate_optional_dimension(
        sheet="S", row=1, field_name="Height", raw_value=0, unit="m"
    )
    assert value is None
    assert issues[0].code == ErrorCode.INVALID_DIMENSION_VALUE


def test_element_type_missing_is_an_error():
    value, issues = validate_element_type(sheet="S", row=1, raw_value="")
    assert value is None
    assert issues[0].code == ErrorCode.MISSING_REQUIRED_FIELD


def test_element_type_present():
    value, issues = validate_element_type(sheet="S", row=1, raw_value="COLUMN")
    assert value == "COLUMN"
    assert issues == []


def test_ready_quantity_blank_is_not_present():
    present, valid, value, issues = validate_ready_quantity(
        sheet="S", row=1, raw_value=None, unit="m3"
    )
    assert present is False
    assert valid is False
    assert value is None
    assert issues == []


def test_ready_quantity_valid():
    present, valid, value, issues = validate_ready_quantity(
        sheet="S", row=1, raw_value="4.2", unit="m3"
    )
    assert present is True
    assert valid is True
    assert value == Decimal("4.2")
    assert issues == []


def test_ready_quantity_present_but_negative_is_invalid():
    present, valid, value, issues = validate_ready_quantity(
        sheet="S", row=1, raw_value="-1", unit="m3"
    )
    assert present is True
    assert valid is False
    assert value is None
    assert issues[0].code == ErrorCode.INVALID_READY_QUANTITY


def test_ready_quantity_present_but_non_m3_unit_is_invalid():
    # Section 10: V1 rejects volume units other than m3, never converts.
    present, valid, value, issues = validate_ready_quantity(
        sheet="S", row=1, raw_value="4.2", unit="L"
    )
    assert present is True
    assert valid is False
    assert issues[0].code == ErrorCode.INVALID_READY_QUANTITY
