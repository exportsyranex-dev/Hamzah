from decimal import Decimal

from app.config.codes import ErrorCode
from app.costing.costing_engine import compute_cost


def test_valid_cost_is_net_quantity_times_unit_rate():
    result = compute_cost(net_quantity_m3=Decimal("4.2"), unit_rate=Decimal("450.00"), currency="AED")
    assert result.error_code is None
    assert result.estimated_cost == Decimal("4.2") * Decimal("450.00")
    assert result.currency == "AED"


def test_missing_unit_rate_is_cost_not_available_never_assumes_zero():
    result = compute_cost(net_quantity_m3=Decimal("4.2"), unit_rate=None, currency="AED")
    assert result.error_code == ErrorCode.COST_NOT_AVAILABLE
    assert result.estimated_cost is None


def test_missing_currency_is_currency_not_defined_never_guessed():
    result = compute_cost(net_quantity_m3=Decimal("4.2"), unit_rate=Decimal("450.00"), currency=None)
    assert result.error_code == ErrorCode.CURRENCY_NOT_DEFINED
    assert result.estimated_cost is None


def test_missing_currency_as_empty_string_is_also_rejected():
    result = compute_cost(net_quantity_m3=Decimal("4.2"), unit_rate=Decimal("450.00"), currency="")
    assert result.error_code == ErrorCode.CURRENCY_NOT_DEFINED


def test_missing_both_reports_cost_not_available_first():
    # Deterministic precedence: unit_rate is checked before currency.
    result = compute_cost(net_quantity_m3=Decimal("4.2"), unit_rate=None, currency=None)
    assert result.error_code == ErrorCode.COST_NOT_AVAILABLE


def test_zero_net_quantity_still_computes_zero_cost_not_an_error():
    result = compute_cost(net_quantity_m3=Decimal("0"), unit_rate=Decimal("450.00"), currency="AED")
    assert result.error_code is None
    assert result.estimated_cost == Decimal("0")
