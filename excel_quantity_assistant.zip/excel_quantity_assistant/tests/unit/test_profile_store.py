import pytest

from app.config.codes import SheetStructureType
from app.profiles.profile_store import (
    ProfileInvalidFloorConfigError,
    validate_floor_config_for_save,
)


def test_single_sheet_without_floor_column_rejected_at_save_time():
    with pytest.raises(ProfileInvalidFloorConfigError):
        validate_floor_config_for_save(
            sheet_structure_type=SheetStructureType.SINGLE_SHEET,
            floor_column_defined=False,
        )


def test_single_sheet_with_floor_column_is_valid():
    validate_floor_config_for_save(
        sheet_structure_type=SheetStructureType.SINGLE_SHEET,
        floor_column_defined=True,
    )  # must not raise


def test_sheet_per_floor_without_floor_column_is_valid():
    validate_floor_config_for_save(
        sheet_structure_type=SheetStructureType.SHEET_PER_FLOOR,
        floor_column_defined=False,
    )  # must not raise -- sheet name is the floor source in this case
