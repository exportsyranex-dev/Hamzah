import tempfile
from datetime import datetime
from pathlib import Path

from app.reporting.file_naming import build_report_filename, resolve_output_path


def test_build_report_filename_matches_spec_format():
    ts = datetime(2026, 9, 8, 14, 30, 25)
    name = build_report_filename(prefix="Quantity_Report", timestamp=ts, extension=".xlsx")
    assert name == "Quantity_Report_2026-09-08_143025.xlsx"


def test_build_report_filename_normalizes_extension_without_dot():
    ts = datetime(2026, 1, 1, 0, 0, 0)
    name = build_report_filename(prefix="Quantity_Report", timestamp=ts, extension="pdf")
    assert name.endswith(".pdf")


def test_resolve_output_path_no_collision_returns_plain_name():
    with tempfile.TemporaryDirectory() as tmp:
        p = resolve_output_path(Path(tmp), "report.xlsx")
        assert p == Path(tmp) / "report.xlsx"


def test_resolve_output_path_collision_appends_deterministic_sequence():
    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        (tmp_path / "report.xlsx").write_bytes(b"existing")
        p1 = resolve_output_path(tmp_path, "report.xlsx")
        assert p1.name == "report_001.xlsx"

        (tmp_path / "report_001.xlsx").write_bytes(b"existing too")
        p2 = resolve_output_path(tmp_path, "report.xlsx")
        assert p2.name == "report_002.xlsx"


def test_resolve_output_path_never_overwrites_an_existing_file():
    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        original = tmp_path / "report.xlsx"
        original.write_bytes(b"do-not-touch")
        resolve_output_path(tmp_path, "report.xlsx")
        assert original.read_bytes() == b"do-not-touch"
