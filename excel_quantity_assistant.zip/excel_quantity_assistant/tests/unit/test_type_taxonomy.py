import pytest

from app.taxonomy.type_taxonomy import UnknownElementTypeError, resolve_formula_id


def test_global_column_resolves_to_rectangular_prism():
    assert resolve_formula_id("COLUMN") == "rectangular_prism_volume"


def test_unknown_label_raises():
    with pytest.raises(UnknownElementTypeError):
        resolve_formula_id("Pedestal")


def test_profile_label_override_pedestal_to_foundation():
    """Section 19 example: Profile A overrides Pedestal -> FOUNDATION."""
    formula_id = resolve_formula_id("Pedestal", label_overrides={"Pedestal": "FOUNDATION"})
    assert formula_id == "rectangular_prism_volume"


def test_profile_formula_override_maps_unknown_type_to_existing_formula():
    """Section 19: user may map an unknown type directly to an existing Formula ID."""
    formula_id = resolve_formula_id(
        "Pedestal",
        label_overrides={"Pedestal": "PEDESTAL_CANONICAL"},
        formula_overrides={"PEDESTAL_CANONICAL": "rectangular_prism_volume"},
    )
    assert formula_id == "rectangular_prism_volume"
