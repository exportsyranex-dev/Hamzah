import tempfile
from pathlib import Path

import openpyxl

from app.config.codes import ErrorCode
from app.ingestion.file_validation import FileValidationError, validate_file


def _tmp(suffix: str, content: bytes | None = None) -> Path:
    fd = tempfile.NamedTemporaryFile(suffix=suffix, delete=False)
    if content is not None:
        fd.write(content)
    fd.close()
    return Path(fd.name)


def test_valid_xlsx_passes():
    p = _tmp(".xlsx")
    wb = openpyxl.Workbook()
    wb.active.append(["A", "B"])
    wb.active.append([1, 2])
    wb.save(str(p))
    validate_file(p)  # must not raise


def test_xls_extension_rejected_with_specific_message():
    p = _tmp(".xls", content=b"anything")
    try:
        validate_file(p)
        assert False, "expected FileValidationError"
    except FileValidationError as exc:
        assert exc.code == ErrorCode.UNSUPPORTED_FILE_FORMAT
        assert ".xlsx" in str(exc)


def test_other_extension_rejected():
    p = _tmp(".csv", content=b"a,b\n1,2")
    try:
        validate_file(p)
        assert False, "expected FileValidationError"
    except FileValidationError as exc:
        assert exc.code == ErrorCode.UNSUPPORTED_FILE_FORMAT


def test_empty_file_rejected():
    p = _tmp(".xlsx", content=b"")
    try:
        validate_file(p)
        assert False, "expected FileValidationError"
    except FileValidationError as exc:
        assert exc.code == ErrorCode.EMPTY_FILE


def test_corrupt_workbook_rejected():
    p = _tmp(".xlsx", content=b"this is not a real zip/xlsx payload at all")
    try:
        validate_file(p)
        assert False, "expected FileValidationError"
    except FileValidationError as exc:
        assert exc.code == ErrorCode.CORRUPT_WORKBOOK


def test_workbook_with_no_usable_data_rejected():
    p = _tmp(".xlsx")
    wb = openpyxl.Workbook()  # default sheet, completely empty
    wb.save(str(p))
    try:
        validate_file(p)
        assert False, "expected FileValidationError"
    except FileValidationError as exc:
        assert exc.code == ErrorCode.NO_USABLE_DATA
