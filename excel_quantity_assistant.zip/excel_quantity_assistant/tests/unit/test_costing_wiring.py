from decimal import Decimal

from app.config.codes import ErrorCode, QuantitySource
from app.models.domain import AggregatedGroup
from app.reporting.report_service import compute_costs_for_groups


def _group(key, element_type, item_code, net_qty):
    return AggregatedGroup(
        key=key, floor="Ground Floor", element_type=element_type, item_code=item_code,
        net_quantity_m3=net_qty, boq_quantity_with_waste_m3=net_qty,
        source_composition={QuantitySource.CALCULATED: 1},
    )


def test_element_type_rate_applied_when_no_item_code_override():
    groups = [_group("K1", "COLUMN", "C-01", Decimal("2.0"))]
    result = compute_costs_for_groups(groups, unit_rates={"COLUMN": Decimal("100")}, currency="USD")
    assert result["K1"].estimated_cost == Decimal("200")
    assert result["K1"].error_code is None


def test_item_code_rate_takes_priority_over_element_type_rate():
    groups = [_group("K1", "COLUMN", "C-01", Decimal("2.0"))]
    result = compute_costs_for_groups(
        groups, unit_rates={"COLUMN": Decimal("100"), "C-01": Decimal("999")}, currency="USD"
    )
    assert result["K1"].estimated_cost == Decimal("2.0") * Decimal("999")


def test_group_with_no_matching_rate_gets_cost_not_available():
    groups = [_group("K1", "FOUNDATION", "F-01", Decimal("9.0"))]
    result = compute_costs_for_groups(groups, unit_rates={"COLUMN": Decimal("100")}, currency="USD")
    assert result["K1"].error_code == ErrorCode.COST_NOT_AVAILABLE
    assert result["K1"].estimated_cost is None


def test_multiple_groups_each_resolved_independently():
    groups = [
        _group("K1", "COLUMN", "C-01", Decimal("2.0")),
        _group("K2", "SLAB", "S-01", Decimal("3.0")),
    ]
    result = compute_costs_for_groups(
        groups, unit_rates={"COLUMN": Decimal("100"), "SLAB": Decimal("50")}, currency="USD"
    )
    assert result["K1"].estimated_cost == Decimal("200")
    assert result["K2"].estimated_cost == Decimal("150")
