from decimal import Decimal

from app.comparison.comparison_engine import compare_aggregated_groups
from app.config.codes import ComparisonResult, ComparisonStatus
from app.models.domain import AggregatedGroup


def _group(key, qty):
    return AggregatedGroup(
        key=key, floor="GF", element_type="COLUMN", item_code=None,
        net_quantity_m3=Decimal(qty), boq_quantity_with_waste_m3=Decimal(qty),
        source_composition={},
    )


def test_matched_within_threshold_is_ok():
    ref = {"K1": _group("K1", "10.0")}
    new = {"K1": _group("K1", "10.3")}  # 3% diff
    result = compare_aggregated_groups(reference_groups=ref, new_groups=new, threshold_percentage=Decimal("5.0"))
    assert len(result) == 1
    row = result[0]
    assert row.status == ComparisonStatus.MATCHED
    assert row.result == ComparisonResult.OK
    assert row.percentage_difference == Decimal("3.0")


def test_matched_over_threshold():
    ref = {"K1": _group("K1", "10.0")}
    new = {"K1": _group("K1", "12.0")}  # 20% diff
    result = compare_aggregated_groups(reference_groups=ref, new_groups=new, threshold_percentage=Decimal("5.0"))
    row = result[0]
    assert row.status == ComparisonStatus.MATCHED
    assert row.result == ComparisonResult.OVER_THRESHOLD


def test_new_item_has_no_percentage():
    ref: dict = {}
    new = {"K1": _group("K1", "5.0")}
    result = compare_aggregated_groups(reference_groups=ref, new_groups=new, threshold_percentage=Decimal("5.0"))
    row = result[0]
    assert row.status == ComparisonStatus.NEW_ITEM
    assert row.reference_quantity_m3 is None
    assert row.percentage_difference is None
    assert row.result is None


def test_removed_item_has_no_percentage():
    ref = {"K1": _group("K1", "5.0")}
    new: dict = {}
    result = compare_aggregated_groups(reference_groups=ref, new_groups=new, threshold_percentage=Decimal("5.0"))
    row = result[0]
    assert row.status == ComparisonStatus.REMOVED_ITEM
    assert row.new_quantity_m3 is None
    assert row.percentage_difference is None
    assert row.result is None
