from app.config.codes import SheetStructureType
from app.ingestion.row_mapper import MappingProfile
from app.ingestion.schema_drift import (
    detect_column_drift,
    detect_schema_drift,
    detect_type_drift,
)
from app.models.domain import RawRow


def _profile(**mapping):
    return MappingProfile(
        sheet_structure_type=SheetStructureType.SHEET_PER_FLOOR,
        column_mapping=mapping,
        unit_per_field={"length": "m", "width": "m", "height": "m", "ready_quantity": "m3"},
        floor_synonyms={},
        item_code_is_comparison_key=False,
    )


def test_no_drift_when_structures_are_identical():
    cols = {"GF": ["Floor", "Element Type", "Width"]}
    missing, new, renames = detect_column_drift(cols, cols)
    assert missing == [] and new == [] and renames == []


def test_missing_column_detected():
    expected = {"GF": ["Floor", "Element Type", "Width", "Height"]}
    actual = {"GF": ["Floor", "Element Type", "Width"]}
    missing, new, renames = detect_column_drift(expected, actual)
    assert missing == [("GF", "Height")]
    assert new == []


def test_new_unexpected_column_detected():
    expected = {"GF": ["Floor", "Element Type", "Width"]}
    actual = {"GF": ["Floor", "Element Type", "Width", "Notes"]}
    missing, new, renames = detect_column_drift(expected, actual)
    assert new == [("GF", "Notes")]
    assert missing == []


def test_whole_sheet_missing_counts_every_column_as_missing():
    expected = {"GF": ["Floor", "Width"], "L1": ["Floor", "Width"]}
    actual = {"GF": ["Floor", "Width"]}
    missing, new, renames = detect_column_drift(expected, actual)
    assert set(missing) == {("L1", "Floor"), ("L1", "Width")}


def test_rename_heuristic_pairs_equal_count_missing_and_new():
    expected = {"GF": ["Floor", "Width"]}
    actual = {"GF": ["Floor", "Breadth"]}
    missing, new, renames = detect_column_drift(expected, actual)
    assert missing == [("GF", "Width")]
    assert new == [("GF", "Breadth")]
    assert renames == [("GF", "Width", "Breadth")]


def test_type_drift_detected_when_numeric_column_becomes_mostly_text():
    profile = _profile(width="Width")
    raw_rows = [
        RawRow(source_file="f", sheet_name="GF", row_number=i, raw_values={"Width": v})
        for i, v in enumerate(["not a number", "n/a", "unknown", "0.3"], start=2)
    ]
    drift = detect_type_drift(raw_rows, profile)
    assert len(drift) == 1
    assert drift[0][0] == "GF"
    assert drift[0][1] == "Width"


def test_type_drift_not_flagged_when_column_is_still_mostly_numeric():
    profile = _profile(width="Width")
    raw_rows = [
        RawRow(source_file="f", sheet_name="GF", row_number=i, raw_values={"Width": v})
        for i, v in enumerate([0.3, 0.4, 0.5, "not a number"], start=2)
    ]
    drift = detect_type_drift(raw_rows, profile)
    assert drift == []


def test_type_drift_not_flagged_with_too_few_samples():
    profile = _profile(width="Width")
    raw_rows = [
        RawRow(source_file="f", sheet_name="GF", row_number=2, raw_values={"Width": "garbage"}),
    ]
    drift = detect_type_drift(raw_rows, profile)
    assert drift == []  # only 1 sample -- MIN_SAMPLES_FOR_TYPE_DRIFT not met


def test_type_drift_ignores_unmapped_dimensions():
    profile = _profile()  # nothing mapped
    raw_rows = [
        RawRow(source_file="f", sheet_name="GF", row_number=i, raw_values={"Width": "garbage"})
        for i in range(2, 6)
    ]
    drift = detect_type_drift(raw_rows, profile)
    assert drift == []


def test_full_detect_schema_drift_report_has_drift_and_user_message_is_actionable():
    expected = {"GF": ["Floor", "Element Type", "Width", "Height"]}
    actual = {"GF": ["Floor", "Element Type", "Breadth", "Height"]}
    profile = _profile(width="Breadth")
    raw_rows = [RawRow(source_file="f", sheet_name="GF", row_number=2, raw_values={"Breadth": 0.3})]

    report = detect_schema_drift(
        expected_columns=expected, actual_columns=actual, raw_rows=raw_rows, profile=profile
    )
    assert report.has_drift
    msg = report.user_message()
    assert "Width" in msg
    assert "Breadth" in msg
    assert "traceback" not in msg.lower()
    assert "The file was not processed." in msg


def test_full_detect_schema_drift_no_drift_when_everything_matches():
    cols = {"GF": ["Floor", "Element Type", "Width"]}
    profile = _profile(width="Width")
    raw_rows = [
        RawRow(source_file="f", sheet_name="GF", row_number=i, raw_values={"Width": 0.3})
        for i in range(2, 6)
    ]
    report = detect_schema_drift(
        expected_columns=cols, actual_columns=cols, raw_rows=raw_rows, profile=profile
    )
    assert not report.has_drift
