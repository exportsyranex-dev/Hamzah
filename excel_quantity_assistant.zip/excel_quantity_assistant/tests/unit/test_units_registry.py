from decimal import Decimal

import pytest

from app.units.registry import (
    UnsupportedUnitError,
    normalize_length,
    validate_ready_quantity_unit,
)


def test_normalize_length_mm_to_m():
    assert normalize_length(Decimal("300"), "mm") == Decimal("300") * Decimal("0.001")


def test_normalize_length_m_identity():
    assert normalize_length(Decimal("5.2"), "m") == Decimal("5.2")


def test_normalize_length_unsupported_unit_raises():
    with pytest.raises(UnsupportedUnitError):
        normalize_length(Decimal("1"), "yard")


def test_ready_quantity_m3_accepted():
    validate_ready_quantity_unit("m3")  # must not raise


@pytest.mark.parametrize("unit", ["L", "liters", "ft3", "cm3"])
def test_ready_quantity_other_volume_units_rejected(unit):
    """Section 10: V1 does NOT convert other volume units -- it rejects them."""
    with pytest.raises(UnsupportedUnitError):
        validate_ready_quantity_unit(unit)
