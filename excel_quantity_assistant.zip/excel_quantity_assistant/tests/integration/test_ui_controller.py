"""
This test module calls EXACTLY the functions app/ui/streamlit_app.py calls
(app.ui.controller.*). There is no separate mock pipeline anywhere in this
project -- if these tests pass, the UI is proven to be wired to the real
deterministic pipeline, because it is calling the same code.
"""
import tempfile
from decimal import Decimal
from pathlib import Path

import openpyxl

from app.config.codes import ErrorCode, SheetStructureType
from app.ingestion.row_mapper import MappingProfile
from app.ui.controller import (
    build_identity_floor_synonyms,
    check_floor_configuration,
    get_workbook_headers,
    process_workbook,
    suggest_column_mapping,
    suggest_floor_column_defined,
    summarize_report,
    validate_uploaded_file,
)
from tests.fixtures.generate_reference_workbook import generate as generate_reference
from tests.fixtures.generate_sample_workbook import generate as generate_new

NEW_FIXTURE = generate_new()
REFERENCE_FIXTURE = generate_reference()


def _auto_profile(path: Path) -> MappingProfile:
    headers_by_sheet = get_workbook_headers(path)
    first_sheet_headers = next(iter(headers_by_sheet.values()))
    mapping = suggest_column_mapping(first_sheet_headers)
    floor_defined = suggest_floor_column_defined(mapping)
    sheet_names = list(headers_by_sheet.keys())
    return MappingProfile(
        sheet_structure_type=SheetStructureType.SHEET_PER_FLOOR,
        column_mapping=mapping,
        unit_per_field={"length": "m", "width": "m", "height": "m", "ready_quantity": "m3"},
        floor_synonyms=build_identity_floor_synonyms(sheet_names) if not floor_defined else {},
        item_code_is_comparison_key="item_code" in mapping,
    )


# ---------------------------------------------------------------------------
# Column-mapping suggestion (Section 37 -- deterministic, never auto-applied
# by the caller; here we just verify the suggestion itself is correct)
# ---------------------------------------------------------------------------
def test_suggest_column_mapping_matches_real_fixture_headers_exactly():
    headers = get_workbook_headers(NEW_FIXTURE)["GF"]
    mapping = suggest_column_mapping(headers)
    assert mapping == {
        "floor": "Floor", "element_type": "Element Type", "item_code": "Item Code",
        "length": "Length", "width": "Width", "height": "Height",
        "ready_quantity": "Ready Quantity",
    }


def test_suggest_column_mapping_is_case_insensitive_and_partial():
    headers = ["LEVEL", "type", "Width (m)", "SomeUnrelatedColumn"]
    mapping = suggest_column_mapping(headers)
    assert mapping["floor"] == "LEVEL"
    assert mapping["element_type"] == "type"
    assert mapping["width"] == "Width (m)"
    assert "height" not in mapping
    assert "ready_quantity" not in mapping


def test_build_identity_floor_synonyms():
    assert build_identity_floor_synonyms(["GF", "Level 01"]) == {"GF": "GF", "Level 01": "Level 01"}


def test_check_floor_configuration_rejects_single_sheet_without_floor_column():
    result = check_floor_configuration(
        sheet_structure_type=SheetStructureType.SINGLE_SHEET, floor_column_defined=False
    )
    assert not result.ok
    assert "Floor" in result.message
    assert "Traceback" not in result.message


def test_check_floor_configuration_accepts_valid_combinations():
    assert check_floor_configuration(
        sheet_structure_type=SheetStructureType.SINGLE_SHEET, floor_column_defined=True
    ).ok
    assert check_floor_configuration(
        sheet_structure_type=SheetStructureType.SHEET_PER_FLOOR, floor_column_defined=False
    ).ok


# ---------------------------------------------------------------------------
# File validation -- friendly messages, never a traceback
# ---------------------------------------------------------------------------
def test_validate_uploaded_file_accepts_real_fixture():
    outcome = validate_uploaded_file(NEW_FIXTURE)
    assert outcome.ok


def test_validate_uploaded_file_rejects_empty_file_with_friendly_message():
    with tempfile.TemporaryDirectory() as tmp:
        p = Path(tmp) / "empty.xlsx"
        p.write_bytes(b"")
        outcome = validate_uploaded_file(p)
        assert not outcome.ok
        assert outcome.error_code == ErrorCode.EMPTY_FILE.value
        assert "Traceback" not in outcome.message
        assert "File" in outcome.message or "file" in outcome.message


def test_validate_uploaded_file_rejects_xls_with_friendly_message():
    with tempfile.TemporaryDirectory() as tmp:
        p = Path(tmp) / "old.xls"
        p.write_bytes(b"anything")
        outcome = validate_uploaded_file(p)
        assert not outcome.ok
        assert ".xlsx" in outcome.message


def test_validate_uploaded_file_rejects_corrupt_file():
    with tempfile.TemporaryDirectory() as tmp:
        p = Path(tmp) / "corrupt.xlsx"
        p.write_bytes(b"this is definitely not a real xlsx payload")
        outcome = validate_uploaded_file(p)
        assert not outcome.ok
        assert outcome.error_code == ErrorCode.CORRUPT_WORKBOOK.value


# ---------------------------------------------------------------------------
# Full processing through the controller -- exactly what the "Process file"
# button in streamlit_app.py triggers.
# ---------------------------------------------------------------------------
def test_process_workbook_success_end_to_end_single_file():
    profile = _auto_profile(NEW_FIXTURE)
    with tempfile.TemporaryDirectory() as tmp:
        outcome = process_workbook(
            new_file=NEW_FIXTURE, new_profile=profile, project_name="UI Test",
            profile_name="ui_session_profile", output_dir=Path(tmp),
            item_code_is_comparison_key=profile.item_code_is_comparison_key,
        )
        assert outcome.success
        assert outcome.excel_path.exists()
        assert outcome.pdf_path.exists()
        assert outcome.summary is not None
        assert outcome.summary.total_groups == 4  # C-01, C-02, S-01, F-01 (B-01/C-03 excluded)
        assert outcome.summary.rows_errored == 2

        # Re-open the actual downloadable bytes, exactly as the Streamlit
        # download_button would read them.
        wb = openpyxl.load_workbook(str(outcome.excel_path))
        assert "الكميات المجمعة" in wb.sheetnames
        pdf_bytes = outcome.pdf_path.read_bytes()
        assert pdf_bytes[:4] == b"%PDF"


def test_process_workbook_success_with_reference_comparison():
    profile = _auto_profile(NEW_FIXTURE)
    with tempfile.TemporaryDirectory() as tmp:
        outcome = process_workbook(
            new_file=NEW_FIXTURE, new_profile=profile, project_name="UI Test",
            profile_name="ui_session_profile", output_dir=Path(tmp),
            item_code_is_comparison_key=True,
            reference_file=REFERENCE_FIXTURE, reference_profile=profile,
        )
        assert outcome.success
        assert outcome.summary.comparison is not None
        assert outcome.summary.comparison.matched >= 1
        assert outcome.summary.comparison.removed_items == 1


def test_process_workbook_with_costing_configured():
    profile = _auto_profile(NEW_FIXTURE)
    with tempfile.TemporaryDirectory() as tmp:
        outcome = process_workbook(
            new_file=NEW_FIXTURE, new_profile=profile, project_name="UI Test",
            profile_name="ui_session_profile", output_dir=Path(tmp),
            item_code_is_comparison_key=True,
            unit_rates={"COLUMN": Decimal("450"), "SLAB": Decimal("300")},
            cost_currency="AED",
        )
        assert outcome.success
        assert outcome.summary.total_estimated_cost is not None
        assert outcome.summary.total_estimated_cost > Decimal("0")
        assert outcome.summary.cost_currency == "AED"


def test_process_workbook_bad_file_returns_friendly_outcome_not_exception():
    profile = _auto_profile(NEW_FIXTURE)
    with tempfile.TemporaryDirectory() as tmp:
        bad_path = Path(tmp) / "bad.xlsx"
        bad_path.write_bytes(b"")
        outcome = process_workbook(
            new_file=bad_path, new_profile=profile, project_name="UI Test",
            profile_name="ui_session_profile", output_dir=Path(tmp),
        )
        assert not outcome.success
        assert outcome.error_code == ErrorCode.EMPTY_FILE.value
        assert "Traceback" not in outcome.message
        assert outcome.excel_path is None
        assert outcome.pdf_path is None


def test_process_workbook_schema_drift_returns_friendly_outcome():
    from app.ingestion.excel_reader import read_workbook_structure

    profile = _auto_profile(NEW_FIXTURE)
    expected_columns = read_workbook_structure(NEW_FIXTURE).sheet_columns

    with tempfile.TemporaryDirectory() as tmp:
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "GF"
        ws.append(["Floor", "Element Type", "Item Code", "Length", "Ready Quantity"])  # missing Width/Height
        ws.append(["Ground Floor", "COLUMN", "C-01", 2.0, 4.2])
        drifted_path = Path(tmp) / "drifted.xlsx"
        wb.save(str(drifted_path))

        outcome = process_workbook(
            new_file=drifted_path, new_profile=profile, project_name="UI Test",
            profile_name="ui_session_profile", output_dir=Path(tmp),
            expected_columns=expected_columns,
        )
        assert not outcome.success
        assert outcome.error_code == ErrorCode.SCHEMA_DRIFT_DETECTED.value
        assert "Traceback" not in outcome.message
        assert "Width" in outcome.message


def test_process_workbook_can_run_twice_in_a_row_without_restarting_anything():
    """Mirrors the UI's 'Process another file' flow: calling process_workbook
    again with a different file in the same process must work cleanly."""
    profile = _auto_profile(NEW_FIXTURE)
    with tempfile.TemporaryDirectory() as tmp:
        first = process_workbook(
            new_file=NEW_FIXTURE, new_profile=profile, project_name="Run 1",
            profile_name="p", output_dir=Path(tmp),
        )
        second = process_workbook(
            new_file=NEW_FIXTURE, new_profile=profile, project_name="Run 2",
            profile_name="p", output_dir=Path(tmp),
        )
        assert first.success and second.success
        assert first.excel_path != second.excel_path  # Section 32 -- never overwrite


def test_summarize_report_numbers_trace_back_to_real_pipeline_output():
    profile = _auto_profile(NEW_FIXTURE)
    with tempfile.TemporaryDirectory() as tmp:
        outcome = process_workbook(
            new_file=NEW_FIXTURE, new_profile=profile, project_name="UI Test",
            profile_name="p", output_dir=Path(tmp),
        )
        recomputed = summarize_report(outcome.report_input)
        assert recomputed.total_groups == outcome.summary.total_groups
        assert recomputed.total_net_quantity_m3 == outcome.summary.total_net_quantity_m3
