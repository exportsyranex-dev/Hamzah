from decimal import Decimal
from pathlib import Path

from app.config.codes import ErrorCode, SheetStructureType, WarningCode
from app.ingestion.excel_reader import read_raw_rows, read_workbook_structure
from app.ingestion.file_validation import FileValidationError, validate_file
from app.ingestion.row_mapper import MappingProfile, map_raw_row
from app.services.key_builder import KeyBuilderConfig
from app.services.pipeline_service import run_quantity_pipeline
from app.utils.fingerprint import compute_fingerprint
from tests.fixtures.generate_sample_workbook import generate

FIXTURE = generate()

FLOOR_COLUMN_PROFILE = MappingProfile(
    sheet_structure_type=SheetStructureType.SHEET_PER_FLOOR,
    column_mapping={
        "floor": "Floor", "element_type": "Element Type", "item_code": "Item Code",
        "length": "Length", "width": "Width", "height": "Height",
        "ready_quantity": "Ready Quantity",
    },
    unit_per_field={"length": "m", "width": "m", "height": "m", "ready_quantity": "m3"},
    floor_synonyms={},
    item_code_is_comparison_key=True,
)

# Section 20 Case 2: no Floor column at all -- raw floor identifier is the
# SHEET NAME, resolved via floor_synonyms.
SHEET_NAME_FLOOR_PROFILE = MappingProfile(
    sheet_structure_type=SheetStructureType.SHEET_PER_FLOOR,
    column_mapping={
        "element_type": "Element Type", "item_code": "Item Code",
        "length": "Length", "width": "Width", "height": "Height",
        "ready_quantity": "Ready Quantity",
    },
    unit_per_field={"length": "m", "width": "m", "height": "m", "ready_quantity": "m3"},
    floor_synonyms={"GF": "Ground Floor", "Level 01": "Level 01"},
    item_code_is_comparison_key=True,
)


def _map_all(profile):
    validated, issues = [], []
    for raw_row in read_raw_rows(FIXTURE):
        vr, row_issues = map_raw_row(raw_row, profile)
        issues.extend(row_issues)
        if vr is not None:
            validated.append(vr)
    return validated, issues


def test_file_validation_accepts_the_real_generated_xlsx():
    validate_file(FIXTURE)  # must not raise


def test_file_validation_rejects_xls_extension():
    import tempfile

    with tempfile.TemporaryDirectory() as tmp:
        bad = Path(tmp) / "workbook.xls"
        bad.write_bytes(b"not really an xls, just needs the extension")
        try:
            validate_file(bad)
            assert False, "expected FileValidationError"
        except FileValidationError as exc:
            assert exc.code == ErrorCode.UNSUPPORTED_FILE_FORMAT


def test_fingerprint_matches_structure_extracted_from_the_fixture():
    structure = read_workbook_structure(FIXTURE)
    assert set(structure.sheet_columns.keys()) == {"GF", "Level 01"}
    assert "Ready Quantity" in structure.sheet_columns["GF"]
    fp = compute_fingerprint(structure.sheet_columns)
    assert len(fp) == 64  # sha256 hex digest length


def test_fully_empty_row_is_ignored_during_ingestion():
    raw_rows = list(read_raw_rows(FIXTURE))
    # 5 data rows on GF (the empty 6th row must be skipped) + 1 on Level 01
    gf_rows = [r for r in raw_rows if r.sheet_name == "GF"]
    assert len(gf_rows) == 5


def test_case1_floor_column_end_to_end_all_ready_quantity_states():
    validated, issues = _map_all(FLOOR_COLUMN_PROFILE)

    # C-03 (State C) and B-01 (State D) still produce a ValidatedRow at the
    # ingestion layer -- the Quantity Engine is the one that turns them into
    # errors, not row_mapper (see row_mapper.py docstring).
    assert len(validated) == 6

    by_item = {v.item_code: v for v in validated}
    assert by_item["C-01"].ready_quantity_present is False  # -> State B
    assert by_item["C-02"].ready_quantity_present is True and by_item["C-02"].ready_quantity_m3 == Decimal("4.2")
    assert by_item["C-03"].ready_quantity_present is True and by_item["C-03"].ready_quantity_m3 is None  # invalid, dropped

    # The bad Width='-' value on B-01 must be recorded as a non-blocking issue.
    width_issues = [i for i in issues if i.field == "Width"]
    assert len(width_issues) == 1
    assert width_issues[0].code == ErrorCode.INVALID_NUMERIC_VALUE

    result = run_quantity_pipeline(
        validated,
        key_config=KeyBuilderConfig(item_code_is_comparison_key=True),
        waste_percentage=Decimal("5.0"),
        mismatch_tolerance_percentage=Decimal("2.0"),
    )

    assert result.rows_errored == 2  # B-01 (State D) + C-03 (State C)
    errors_by_item = {rr.item_code: rr.error.code for rr in result.row_results if rr.error}
    assert errors_by_item["B-01"] == ErrorCode.NO_QUANTITY_SOURCE_AVAILABLE
    assert errors_by_item["C-03"] == ErrorCode.INVALID_READY_QUANTITY

    # S-01 (slab, 0.08m thick) must carry the row-level engineering warning.
    slab_result = next(rr for rr in result.row_results if rr.item_code == "S-01")
    assert any(w.code == WarningCode.ENGINEERING_CONSTRAINT_WARNING for w in slab_result.warnings)

    groups_by_key = {g.key: g for g in result.aggregated_groups}
    assert groups_by_key["ITEM::C-01"].net_quantity_m3 == Decimal("2.0") * Decimal("0.3") * Decimal("2.8")
    assert groups_by_key["ITEM::C-02"].net_quantity_m3 == Decimal("4.2")
    assert groups_by_key["ITEM::F-01"].net_quantity_m3 == Decimal("3.0") * Decimal("3.0") * Decimal("1.0")


def test_case2_sheet_name_floor_resolution_end_to_end():
    validated, _issues = _map_all(SHEET_NAME_FLOOR_PROFILE)
    by_item = {v.item_code: v for v in validated}
    # Sheet 'GF' -> synonym -> 'Ground Floor'; sheet 'Level 01' -> itself.
    assert by_item["C-01"].floor == "Ground Floor"
    assert by_item["F-01"].floor == "Level 01"
