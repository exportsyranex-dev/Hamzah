import tempfile
from decimal import Decimal
from pathlib import Path

from app.config.codes import SheetStructureType
from app.ingestion.row_mapper import MappingProfile
from app.reporting.report_service import run_full_report
from tests.fixtures.generate_sample_workbook import generate as generate_new

NEW_FIXTURE = generate_new()
PROFILE = MappingProfile(
    sheet_structure_type=SheetStructureType.SHEET_PER_FLOOR,
    column_mapping={
        "floor": "Floor", "element_type": "Element Type", "item_code": "Item Code",
        "length": "Length", "width": "Width", "height": "Height",
        "ready_quantity": "Ready Quantity",
    },
    unit_per_field={"length": "m", "width": "m", "height": "m", "ready_quantity": "m3"},
    floor_synonyms={},
    item_code_is_comparison_key=True,
)


class _BrokenProvider:
    """Simulates a network error, timeout, bad API key -- anything."""

    def complete(self, system_prompt, user_prompt):
        raise ConnectionError("simulated network failure")

    def is_available(self):
        return True


class _WorkingProvider:
    def complete(self, system_prompt, user_prompt):
        return "Everything looks fine. No issues detected."

    def is_available(self):
        return True


def _run(output_dir, **kwargs):
    return run_full_report(
        new_file=NEW_FIXTURE, new_profile=PROFILE, project_name="AI Test", profile_name="p",
        output_dir=output_dir, item_code_is_comparison_key=True, **kwargs,
    )


def test_no_ai_provider_configured_produces_valid_report_with_fallback_text():
    with tempfile.TemporaryDirectory() as tmp:
        result = _run(Path(tmp))
        assert result.excel_path.exists()
        assert result.pdf_path.exists()
        assert result.report_input.ai_executive_summary_text is None  # PDF renders the fallback text


def test_broken_ai_provider_never_breaks_report_generation():
    """Section 43: 'the application never fails because local AI is
    unavailable' -- a provider that raises must not propagate."""
    with tempfile.TemporaryDirectory() as tmp:
        result = _run(Path(tmp), ai_provider=_BrokenProvider())
        assert result.excel_path.exists()
        assert result.pdf_path.exists()
        # generate_executive_summary swallows the failure and returns the
        # static fallback string rather than None here, since the provider
        # path was actually attempted.
        assert result.report_input.ai_executive_summary_text == "Executive Summary unavailable."


def test_working_ai_provider_text_flows_into_the_report():
    with tempfile.TemporaryDirectory() as tmp:
        result = _run(Path(tmp), ai_provider=_WorkingProvider())
        assert result.report_input.ai_executive_summary_text == "Everything looks fine. No issues detected."


def test_explicit_summary_text_overrides_provider():
    with tempfile.TemporaryDirectory() as tmp:
        result = _run(
            Path(tmp),
            ai_provider=_WorkingProvider(),
            ai_executive_summary_text="Manually written summary.",
        )
        assert result.report_input.ai_executive_summary_text == "Manually written summary."


def test_core_pipeline_produces_identical_quantities_with_or_without_ai():
    """Proves AI involvement (or its absence) has zero effect on any
    engineering number -- Section 2's core guarantee."""
    with tempfile.TemporaryDirectory() as tmp1, tempfile.TemporaryDirectory() as tmp2:
        without_ai = _run(Path(tmp1))
        with_ai = _run(Path(tmp2), ai_provider=_WorkingProvider())
        groups_a = {g.key: g.net_quantity_m3 for g in without_ai.report_input.new_aggregated_groups}
        groups_b = {g.key: g.net_quantity_m3 for g in with_ai.report_input.new_aggregated_groups}
        assert groups_a == groups_b
