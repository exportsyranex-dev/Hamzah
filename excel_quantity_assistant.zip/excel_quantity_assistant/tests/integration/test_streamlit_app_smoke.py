"""
IMPORTANT -- what this test does and does NOT prove:

This sandbox has no network access, so the real `streamlit` package could
not be installed, and therefore `streamlit run app/ui/streamlit_app.py`
could not be launched in a real browser here. This test does NOT claim to
have done that.

What it DOES do: it injects a fake `streamlit` module (tests/fixtures/
fake_streamlit.py) that fakes only the widget layer (file_uploader,
selectbox, button, session_state, etc.) and then calls the REAL
app.ui.streamlit_app.main() function -- the exact same Python code that
runs inside a real Streamlit session. Every button click, file upload, and
selectbox choice is simulated by pre-loading values into the fake module;
everything AFTER that (column-mapping suggestion, Profile Matching,
Schema Drift, the full quantity pipeline, Excel/PDF generation) is 100%
real, using real generated .xlsx files and a real (temporary) SQLite
Profile database.

This proves: main()'s control flow is exception-free, calls the right
controller functions with the right arguments, session_state transitions
correctly across simulated reruns, Profile persistence (Section 15) really
works end-to-end through the UI's own code path (not just through
controller.py directly), and every user-facing message is friendly text,
never a traceback.

This does NOT prove: actual browser rendering, real Streamlit rerun
semantics/timing, or visual layout. That requires a real environment with
network access to install `streamlit` and a browser -- documented in the
README as still needing to happen on a real Windows machine before
packaging.
"""
import sys
import tempfile
from decimal import Decimal
from pathlib import Path
from unittest import mock

from app.config.settings import AppConfig
from tests.fixtures import fake_streamlit
from tests.fixtures.generate_sample_workbook import generate as generate_new

# Inject the fake BEFORE the first import of app.ui.streamlit_app, since
# that module does `import streamlit as st` at the top and calls
# st.set_page_config(...) at module level.
sys.modules.setdefault("streamlit", fake_streamlit)
import app.ui.streamlit_app as streamlit_app  # noqa: E402

NEW_FIXTURE = generate_new()


class FakeUploadedFile:
    """Stands in for Streamlit's UploadedFile: .name, .size, .getvalue()."""

    def __init__(self, path: Path):
        self._data = path.read_bytes()
        self.name = path.name
        self.size = len(self._data)

    def getvalue(self) -> bytes:
        return self._data


def _messages(call_name: str) -> list[str]:
    return [args[0] for name, args, kwargs in fake_streamlit.LOG if name == call_name and args]


def _any_traceback_text() -> bool:
    all_text = " ".join(str(a) for _, args, kwargs in fake_streamlit.LOG for a in args)
    all_text += " ".join(str(v) for _, _, kwargs in fake_streamlit.LOG for v in kwargs.values())
    return "Traceback" in all_text or "traceback" in all_text.lower()


def test_successful_run_end_to_end_through_the_real_streamlit_script_logic():
    fake_streamlit.reset_fake_streamlit()
    with tempfile.TemporaryDirectory() as tmp:
        db_path = Path(tmp) / "profiles.db"
        fake_config = AppConfig(db_path=db_path, reports_dir=Path(tmp) / "reports")

        fake_streamlit.WIDGET_VALUES["new_upload_0"] = FakeUploadedFile(NEW_FIXTURE)
        fake_streamlit.WIDGET_VALUES["profile_save_name"] = "MyTestProfile"
        fake_streamlit.BUTTON_CLICKS.add("Process file")
        fake_streamlit.BUTTON_CLICKS.add("Save as Profile")

        with mock.patch("app.ui.controller.get_default_config", return_value=fake_config):
            streamlit_app.main()

        assert not _any_traceback_text()
        outcome = fake_streamlit.session_state.get("result")
        assert outcome is not None and outcome.success, _messages("error")
        assert outcome.excel_path.exists()
        assert outcome.pdf_path.exists()

        success_messages = " ".join(_messages("success"))
        assert "Processing completed successfully" in success_messages
        assert "MyTestProfile" in success_messages  # save confirmation

        # The profile really was persisted to the (temp) SQLite DB.
        from app.profiles import profile_store
        from app.utils.fingerprint import compute_fingerprint
        from app.ingestion.excel_reader import read_workbook_structure

        conn = fake_config.db_path
        import sqlite3
        raw_conn = sqlite3.connect(str(conn))
        raw_conn.row_factory = sqlite3.Row
        fp = compute_fingerprint(read_workbook_structure(NEW_FIXTURE).sheet_columns)
        match = profile_store.match_profiles(raw_conn, fp)
        assert len(match.matches) == 1
        assert match.matches[0]["name"] == "MyTestProfile"
        raw_conn.close()


def test_second_independent_session_auto_applies_the_saved_profile():
    """Simulates closing and reopening the app entirely (fresh
    session_state) with the SAME on-disk Profile DB from a prior run --
    proves persistence survives across sessions, not just reruns.
    """
    with tempfile.TemporaryDirectory() as tmp:
        db_path = Path(tmp) / "profiles.db"
        fake_config = AppConfig(db_path=db_path, reports_dir=Path(tmp) / "reports")

        # --- Session 1: manual mapping + save ---
        fake_streamlit.reset_fake_streamlit()
        fake_streamlit.WIDGET_VALUES["new_upload_0"] = FakeUploadedFile(NEW_FIXTURE)
        fake_streamlit.WIDGET_VALUES["profile_save_name"] = "ReusableProfile"
        fake_streamlit.BUTTON_CLICKS.add("Process file")
        fake_streamlit.BUTTON_CLICKS.add("Save as Profile")
        with mock.patch("app.ui.controller.get_default_config", return_value=fake_config):
            streamlit_app.main()
        assert fake_streamlit.session_state["result"].success

        # --- Session 2: brand-new fake session_state, same DB on disk ---
        fake_streamlit.reset_fake_streamlit()
        fake_streamlit.WIDGET_VALUES["new_upload_0"] = FakeUploadedFile(NEW_FIXTURE)
        fake_streamlit.BUTTON_CLICKS.add("Process file")
        with mock.patch("app.ui.controller.get_default_config", return_value=fake_config):
            streamlit_app.main()

        assert not _any_traceback_text()
        outcome = fake_streamlit.session_state.get("result")
        assert outcome is not None and outcome.success, _messages("error")

        success_messages = " ".join(_messages("success"))
        assert "ReusableProfile" in success_messages
        assert "mapping applied automatically" in success_messages

        # No manual-mapping selectboxes should have been rendered this time.
        mapping_selectboxes = [
            args for name, args, kwargs in fake_streamlit.LOG
            if name == "selectbox" and kwargs.get("key", "").startswith("map_")
        ]
        assert mapping_selectboxes == []


def test_empty_file_shows_friendly_error_never_a_traceback():
    fake_streamlit.reset_fake_streamlit()
    with tempfile.TemporaryDirectory() as tmp:
        db_path = Path(tmp) / "profiles.db"
        fake_config = AppConfig(db_path=db_path, reports_dir=Path(tmp) / "reports")

        bad_file_path = Path(tmp) / "empty.xlsx"
        bad_file_path.write_bytes(b"")

        fake_streamlit.WIDGET_VALUES["new_upload_0"] = FakeUploadedFile(bad_file_path)

        with mock.patch("app.ui.controller.get_default_config", return_value=fake_config):
            streamlit_app.main()

        assert not _any_traceback_text()
        error_messages = " ".join(_messages("error"))
        assert "cannot be processed" in error_messages
        assert fake_streamlit.session_state.get("result") is None


def test_schema_drift_on_auto_applied_profile_shows_friendly_error():
    """A file with the SAME column names (so the same fingerprint ->
    AUTO_APPLY) but a numeric column now full of text -- impactful type
    drift Section 16 must still catch even through the auto-apply path.
    """
    import openpyxl

    with tempfile.TemporaryDirectory() as tmp:
        db_path = Path(tmp) / "profiles.db"
        fake_config = AppConfig(db_path=db_path, reports_dir=Path(tmp) / "reports")

        # Save a profile first (same flow as the other tests).
        fake_streamlit.reset_fake_streamlit()
        fake_streamlit.WIDGET_VALUES["new_upload_0"] = FakeUploadedFile(NEW_FIXTURE)
        fake_streamlit.WIDGET_VALUES["profile_save_name"] = "DriftTestProfile"
        fake_streamlit.BUTTON_CLICKS.add("Process file")
        fake_streamlit.BUTTON_CLICKS.add("Save as Profile")
        with mock.patch("app.ui.controller.get_default_config", return_value=fake_config):
            streamlit_app.main()
        assert fake_streamlit.session_state["result"].success

        # Build a same-structure-but-drifted-data file.
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "GF"
        ws.append(["Floor", "Element Type", "Item Code", "Length", "Width", "Height", "Ready Quantity"])
        for i in range(4):
            ws.append(["Ground Floor", "COLUMN", f"C-{i}", 2.0, "not numeric", 2.8, None])
        ws2 = wb.create_sheet("Level 01")
        ws2.append(["Floor", "Element Type", "Item Code", "Length", "Width", "Height", "Ready Quantity"])
        ws2.append(["Level 01", "FOUNDATION", "F-01", 3.0, 3.0, 1.0, None])
        drifted_path = Path(tmp) / "drifted_same_columns.xlsx"
        wb.save(str(drifted_path))

        fake_streamlit.reset_fake_streamlit()
        fake_streamlit.WIDGET_VALUES["new_upload_0"] = FakeUploadedFile(drifted_path)
        fake_streamlit.BUTTON_CLICKS.add("Process file")
        with mock.patch("app.ui.controller.get_default_config", return_value=fake_config):
            streamlit_app.main()

        assert not _any_traceback_text()
        # AUTO_APPLY still happens (same fingerprint) -- shown before processing.
        assert "DriftTestProfile" in " ".join(_messages("success"))
        # But processing itself must fail with the friendly drift message.
        error_messages = " ".join(_messages("error"))
        assert "structure no longer matches" in error_messages
        assert "Width" in error_messages
        outcome = fake_streamlit.session_state.get("result")
        assert outcome is not None and not outcome.success


def test_process_another_file_resets_uploader_and_session_state():
    fake_streamlit.reset_fake_streamlit()
    with tempfile.TemporaryDirectory() as tmp:
        db_path = Path(tmp) / "profiles.db"
        fake_config = AppConfig(db_path=db_path, reports_dir=Path(tmp) / "reports")

        fake_streamlit.WIDGET_VALUES["new_upload_0"] = FakeUploadedFile(NEW_FIXTURE)
        fake_streamlit.WIDGET_VALUES["profile_save_name"] = "TempProfile"
        fake_streamlit.BUTTON_CLICKS.add("Process file")
        with mock.patch("app.ui.controller.get_default_config", return_value=fake_config):
            streamlit_app.main()
        assert fake_streamlit.session_state["result"].success
        gen_before = fake_streamlit.session_state["uploader_generation"]

        fake_streamlit.BUTTON_CLICKS.add("Process another file")
        try:
            with mock.patch("app.ui.controller.get_default_config", return_value=fake_config):
                streamlit_app.main()
            raised = False
        except fake_streamlit.RerunException:
            raised = True

        assert raised, "Process another file must call st.rerun()"
        assert fake_streamlit.session_state["result"] is None
        assert fake_streamlit.session_state["uploader_generation"] == gen_before + 1
