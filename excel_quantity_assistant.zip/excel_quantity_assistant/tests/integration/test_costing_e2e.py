import tempfile
from decimal import Decimal
from pathlib import Path

import openpyxl

from app.config.codes import ErrorCode, SheetStructureType
from app.ingestion.row_mapper import MappingProfile
from app.reporting.report_service import run_full_report
from tests.fixtures.generate_sample_workbook import generate as generate_new

NEW_FIXTURE = generate_new()
PROFILE = MappingProfile(
    sheet_structure_type=SheetStructureType.SHEET_PER_FLOOR,
    column_mapping={
        "floor": "Floor", "element_type": "Element Type", "item_code": "Item Code",
        "length": "Length", "width": "Width", "height": "Height",
        "ready_quantity": "Ready Quantity",
    },
    unit_per_field={"length": "m", "width": "m", "height": "m", "ready_quantity": "m3"},
    floor_synonyms={},
    item_code_is_comparison_key=True,
)


def _run(output_dir: Path, **kwargs):
    return run_full_report(
        new_file=NEW_FIXTURE, new_profile=PROFILE, project_name="Costing Test", profile_name="p",
        output_dir=output_dir, item_code_is_comparison_key=True, **kwargs,
    )


def test_costing_columns_absent_when_costing_not_configured():
    with tempfile.TemporaryDirectory() as tmp:
        result = _run(Path(tmp))
        wb = openpyxl.load_workbook(str(result.excel_path))
        ws = wb["الكميات المجمعة"]
        header_row = next(r for r in ws.iter_rows(min_row=1, max_row=10, values_only=True) if r[0] == "Floor")
        assert "Estimated Cost" not in "".join(str(h) for h in header_row if h)


def test_costing_columns_present_and_correct_when_configured():
    with tempfile.TemporaryDirectory() as tmp:
        result = _run(
            Path(tmp),
            unit_rates={"COLUMN": Decimal("450.00"), "SLAB": Decimal("300.00")},
            cost_currency="AED",
        )
        wb = openpyxl.load_workbook(str(result.excel_path))
        ws = wb["الكميات المجمعة"]
        rows = list(ws.iter_rows(min_row=5, values_only=True))
        header_row = next(r for r in ws.iter_rows(min_row=1, max_row=10, values_only=True) if r[0] == "Floor")
        assert any("Estimated Cost" in str(h) for h in header_row if h)

        by_item = {r[2]: r for r in rows}
        # C-01: CALCULATED 2.0*0.3*2.8 = 1.68 m3 * 450 = 756
        assert Decimal(str(by_item["C-01"][7])) == Decimal("756.00")
        # C-02: DIRECT 4.2 m3 * 450 = 1890
        assert Decimal(str(by_item["C-02"][7])) == Decimal("1890.00")
        # F-01 (FOUNDATION): no rate configured -> COST_NOT_AVAILABLE, no cost value
        assert by_item["F-01"][7] is None
        assert by_item["F-01"][8] == ErrorCode.COST_NOT_AVAILABLE.value


def test_costing_skipped_entirely_when_currency_missing_even_with_rates():
    """Section 36: never guess a currency. Rates alone are not enough."""
    with tempfile.TemporaryDirectory() as tmp:
        result = _run(Path(tmp), unit_rates={"COLUMN": Decimal("450.00")}, cost_currency=None)
        assert result.report_input.cost_by_key is None
        wb = openpyxl.load_workbook(str(result.excel_path))
        ws = wb["الكميات المجمعة"]
        header_row = next(r for r in ws.iter_rows(min_row=1, max_row=10, values_only=True) if r[0] == "Floor")
        assert "Estimated Cost" not in "".join(str(h) for h in header_row if h)


def test_pdf_contains_costing_section_when_configured():
    with tempfile.TemporaryDirectory() as tmp:
        result = _run(
            Path(tmp),
            unit_rates={"COLUMN": Decimal("450.00"), "SLAB": Decimal("300.00")},
            cost_currency="AED",
        )
        data = result.pdf_path.read_bytes()
        assert data[:4] == b"%PDF"
        assert len(data) > 1000
