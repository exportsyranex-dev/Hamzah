from decimal import Decimal

from app.config.codes import QuantitySource
from app.models.domain import ValidatedRow
from app.services.key_builder import KeyBuilderConfig
from app.services.pipeline_service import run_quantity_pipeline


def _row(row, floor, elem, ready=None, dims=None, item_code=None):
    return ValidatedRow(
        source_file="new.xlsx", sheet="GF", row=row, floor=floor,
        element_type=elem, item_code=item_code,
        dimensions_m=dims or {}, ready_quantity_m3=ready,
        ready_quantity_present=ready is not None,
    )


def test_aggregation_reports_mixed_source_composition():
    rows = [
        _row(1, "Ground Floor", "COLUMN", ready=Decimal("4.2")),  # DIRECT
        _row(2, "Ground Floor", "COLUMN", dims={
            "length": Decimal("2.0"), "width": Decimal("0.3"), "height": Decimal("2.8"),
        }),  # CALCULATED
    ]
    result = run_quantity_pipeline(
        rows,
        key_config=KeyBuilderConfig(item_code_is_comparison_key=False),
        waste_percentage=Decimal("5.0"),
        mismatch_tolerance_percentage=Decimal("2.0"),
    )
    assert result.rows_errored == 0
    assert len(result.aggregated_groups) == 1
    group = result.aggregated_groups[0]
    assert group.source_composition[QuantitySource.DIRECT] == 1
    assert group.source_composition[QuantitySource.CALCULATED] == 1
    expected_net = Decimal("4.2") + (Decimal("2.0") * Decimal("0.3") * Decimal("2.8"))
    assert group.net_quantity_m3 == expected_net
    assert group.boq_quantity_with_waste_m3 == expected_net * Decimal("1.05")


def test_state_c_and_d_rows_are_excluded_and_counted_as_errored():
    rows = [
        _row(1, "Ground Floor", "COLUMN", ready=None, dims=None),  # State D
        _row(2, "Ground Floor", "COLUMN", ready=Decimal("4.2")),  # DIRECT, valid
    ]
    # Force State C by giving a present-but-invalid ready quantity: model this
    # via ready_quantity_present True but value None is treated as invalid.
    rows[0] = ValidatedRow(
        source_file="new.xlsx", sheet="GF", row=1, floor="Ground Floor",
        element_type="COLUMN", item_code=None, dimensions_m={},
        ready_quantity_m3=None, ready_quantity_present=True,  # present but invalid -> State C
    )
    result = run_quantity_pipeline(
        rows,
        key_config=KeyBuilderConfig(item_code_is_comparison_key=False),
        waste_percentage=Decimal("0"),
        mismatch_tolerance_percentage=Decimal("2.0"),
    )
    assert result.rows_errored == 1
    assert len(result.aggregated_groups) == 1  # only the valid row aggregates
    assert result.aggregated_groups[0].net_quantity_m3 == Decimal("4.2")


def test_unknown_element_type_produces_row_error_not_crash():
    rows = [_row(1, "Ground Floor", "MYSTERY_TYPE", ready=Decimal("1.0"))]
    result = run_quantity_pipeline(
        rows,
        key_config=KeyBuilderConfig(item_code_is_comparison_key=False),
        waste_percentage=Decimal("0"),
        mismatch_tolerance_percentage=Decimal("2.0"),
    )
    assert result.rows_errored == 1
    assert result.row_results[0].error.code.value == "UNKNOWN_ELEMENT_TYPE"
