"""
Section 16 end-to-end: real .xlsx files, through the exact same
run_full_report() entrypoint the UI calls, proving Schema Drift genuinely
stops the file with an actionable message rather than silently continuing
or crashing with a traceback.
"""
import tempfile
from decimal import Decimal
from pathlib import Path

import openpyxl
import pytest

from app.config.codes import SheetStructureType
from app.ingestion.excel_reader import read_workbook_structure
from app.ingestion.row_mapper import MappingProfile
from app.ingestion.schema_drift import SchemaDriftError
from app.reporting.report_service import run_full_report
from tests.fixtures.generate_sample_workbook import generate as generate_new

BASELINE_FIXTURE = generate_new()
PROFILE = MappingProfile(
    sheet_structure_type=SheetStructureType.SHEET_PER_FLOOR,
    column_mapping={
        "floor": "Floor", "element_type": "Element Type", "item_code": "Item Code",
        "length": "Length", "width": "Width", "height": "Height",
        "ready_quantity": "Ready Quantity",
    },
    unit_per_field={"length": "m", "width": "m", "height": "m", "ready_quantity": "m3"},
    floor_synonyms={},
    item_code_is_comparison_key=True,
)
EXPECTED_COLUMNS = read_workbook_structure(BASELINE_FIXTURE).sheet_columns


def _write_workbook(rows_by_sheet: dict[str, tuple[list, list[list]]], path: Path) -> Path:
    wb = openpyxl.Workbook()
    wb.remove(wb.active)
    for sheet_name, (headers, rows) in rows_by_sheet.items():
        ws = wb.create_sheet(sheet_name)
        ws.append(headers)
        for row in rows:
            ws.append(row)
    wb.save(str(path))
    return path


def _run(path: Path, output_dir: Path, expected_columns=EXPECTED_COLUMNS):
    return run_full_report(
        new_file=path, new_profile=PROFILE, project_name="X", profile_name="p",
        output_dir=output_dir, item_code_is_comparison_key=True,
        expected_columns=expected_columns,
    )


def test_identical_structure_processes_successfully_no_drift():
    with tempfile.TemporaryDirectory() as tmp:
        result = _run(BASELINE_FIXTURE, Path(tmp))
        assert result.excel_path.exists()


def test_missing_column_stops_the_file_with_actionable_message():
    with tempfile.TemporaryDirectory() as tmp:
        path = _write_workbook(
            {"GF": (
                ["Floor", "Element Type", "Item Code", "Length", "Ready Quantity"],  # Width, Height missing
                [["Ground Floor", "COLUMN", "C-01", 2.0, 4.2]],
            )},
            Path(tmp) / "missing_cols.xlsx",
        )
        with pytest.raises(SchemaDriftError) as exc_info:
            _run(path, Path(tmp))
        msg = str(exc_info.value)
        assert "SCHEMA_DRIFT_DETECTED" in msg
        assert "Width" in msg
        assert "Height" in msg
        assert "Traceback" not in msg


def test_new_unexpected_column_stops_the_file():
    with tempfile.TemporaryDirectory() as tmp:
        path = _write_workbook(
            {
                "GF": (
                    ["Floor", "Element Type", "Item Code", "Length", "Width", "Height",
                     "Ready Quantity", "Supplier Notes"],
                    [["Ground Floor", "COLUMN", "C-01", 2.0, 0.3, 2.8, None, "extra info"]],
                ),
                "Level 01": (
                    ["Floor", "Element Type", "Item Code", "Length", "Width", "Height", "Ready Quantity"],
                    [["Level 01", "FOUNDATION", "F-01", 3.0, 3.0, 1.0, None]],
                ),
            },
            Path(tmp) / "extra_col.xlsx",
        )
        with pytest.raises(SchemaDriftError) as exc_info:
            _run(path, Path(tmp))
        assert "Supplier Notes" in str(exc_info.value)


def test_renamed_column_reported_as_missing_and_new_with_rename_hint():
    with tempfile.TemporaryDirectory() as tmp:
        path = _write_workbook(
            {
                "GF": (
                    ["Floor", "Element Type", "Item Code", "Length", "Breadth", "Height", "Ready Quantity"],
                    [["Ground Floor", "COLUMN", "C-01", 2.0, 0.3, 2.8, None]],
                ),
                "Level 01": (
                    ["Floor", "Element Type", "Item Code", "Length", "Width", "Height", "Ready Quantity"],
                    [["Level 01", "FOUNDATION", "F-01", 3.0, 3.0, 1.0, None]],
                ),
            },
            Path(tmp) / "renamed_col.xlsx",
        )
        with pytest.raises(SchemaDriftError) as exc_info:
            _run(path, Path(tmp))
        msg = str(exc_info.value)
        assert "Width" in msg and "Breadth" in msg
        assert "renamed" in msg.lower()


def test_impactful_type_drift_stops_the_file():
    # Width column exists with the right header, but its values are now text.
    with tempfile.TemporaryDirectory() as tmp:
        path = _write_workbook(
            {
                "GF": (
                    ["Floor", "Element Type", "Item Code", "Length", "Width", "Height", "Ready Quantity"],
                    [
                        ["Ground Floor", "COLUMN", "C-01", 2.0, "wide", 2.8, None],
                        ["Ground Floor", "COLUMN", "C-02", 2.0, "narrow", 2.8, None],
                        ["Ground Floor", "COLUMN", "C-03", 2.0, "medium", 2.8, None],
                        ["Ground Floor", "COLUMN", "C-04", 2.0, "n/a", 2.8, None],
                    ],
                ),
                "Level 01": (
                    ["Floor", "Element Type", "Item Code", "Length", "Width", "Height", "Ready Quantity"],
                    [["Level 01", "FOUNDATION", "F-01", 3.0, 3.0, 1.0, None]],
                ),
            },
            Path(tmp) / "type_drift.xlsx",
        )
        with pytest.raises(SchemaDriftError) as exc_info:
            _run(path, Path(tmp))
        msg = str(exc_info.value)
        assert "Width" in msg
        assert "not numeric" in msg


def test_no_expected_columns_baseline_means_no_drift_check_performed():
    """A freshly hand-built Profile with no saved baseline (Section 15
    Manual Mapping, first time this template is used) must NOT be blocked
    -- there is nothing to drift from yet.
    """
    with tempfile.TemporaryDirectory() as tmp:
        path = _write_workbook(
            {"GF": (
                ["Floor", "Element Type", "Item Code", "Length", "Ready Quantity"],
                [["Ground Floor", "COLUMN", "C-01", 2.0, 4.2]],
            )},
            Path(tmp) / "no_baseline.xlsx",
        )
        result = _run(path, Path(tmp), expected_columns=None)
        assert result.excel_path.exists()
