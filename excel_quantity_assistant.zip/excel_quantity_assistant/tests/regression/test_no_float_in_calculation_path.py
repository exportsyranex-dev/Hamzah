"""
Section 50: "A regression test asserting no float ever touches the
quantity-calculation path (e.g. a lint rule or static check on the
quantity_engine and units modules)."

This is a simple AST-based static check rather than a full lint rule --
it walks the source of the target modules and fails if it finds:
  - a bare `float(` call, or
  - a float literal (e.g. 0.001) used anywhere outside of a comment/string.

Decimal STRING literals like Decimal("0.001") are fine and expected (Section 8).
"""
from __future__ import annotations

import ast
from pathlib import Path

TARGET_MODULES = [
    "app/quantity_engine/engine.py",
    "app/units/registry.py",
    "app/taxonomy/formula_registry.py",
    "app/aggregation/aggregator.py",
    "app/comparison/comparison_engine.py",
    "app/costing/costing_engine.py",
]

PROJECT_ROOT = Path(__file__).resolve().parents[2]


def _find_float_usage(tree: ast.AST) -> list[str]:
    problems = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == "float":
            problems.append(f"float() call at line {node.lineno}")
        if isinstance(node, ast.Constant) and isinstance(node.value, float):
            problems.append(f"float literal {node.value} at line {node.lineno}")
    return problems


def test_no_float_touches_calculation_path():
    all_problems = {}
    for rel_path in TARGET_MODULES:
        path = PROJECT_ROOT / rel_path
        assert path.exists(), f"expected module missing: {rel_path}"
        tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
        problems = _find_float_usage(tree)
        if problems:
            all_problems[rel_path] = problems

    assert not all_problems, f"float usage found in calculation path: {all_problems}"
