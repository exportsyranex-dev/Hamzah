"""
Section 6 / Section 41 / Section 50/51: automated enforcement of the AI/data
boundary -- ai/ui_advisor/ must have NO import path (direct or transitive)
to app.quantity_engine, app.aggregation, app.comparison, or app.database.

This walks the actual import graph starting from every module under
app/ai/ui_advisor/, following only first-party `app.*` imports, and fails
if any forbidden module is reachable.
"""
from __future__ import annotations

import ast
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[2]
UI_ADVISOR_DIR = PROJECT_ROOT / "app" / "ai" / "ui_advisor"

FORBIDDEN_PREFIXES = (
    "app.quantity_engine",
    "app.aggregation",
    "app.comparison",
    "app.database",
)


def _module_path_for(dotted: str) -> Path | None:
    rel = dotted.replace(".", "/")
    candidate_file = PROJECT_ROOT / f"{rel}.py"
    candidate_pkg = PROJECT_ROOT / rel / "__init__.py"
    if candidate_file.exists():
        return candidate_file
    if candidate_pkg.exists():
        return candidate_pkg
    return None


def _extract_app_imports(py_file: Path) -> set[str]:
    tree = ast.parse(py_file.read_text(encoding="utf-8"), filename=str(py_file))
    imports: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                if alias.name.startswith("app."):
                    imports.add(alias.name)
        elif isinstance(node, ast.ImportFrom):
            if node.module and node.module.startswith("app."):
                imports.add(node.module)
    return imports


def _collect_all_app_py_files(start_dir: Path) -> list[Path]:
    return sorted(start_dir.rglob("*.py"))


def test_ui_advisor_has_no_import_path_to_forbidden_modules():
    assert UI_ADVISOR_DIR.exists(), "app/ai/ui_advisor directory is missing"

    start_files = _collect_all_app_py_files(UI_ADVISOR_DIR)
    assert start_files, "no source files found under app/ai/ui_advisor"

    visited: set[str] = set()
    frontier: set[str] = set()

    for f in start_files:
        frontier |= _extract_app_imports(f)

    violations = []

    while frontier:
        module = frontier.pop()
        if module in visited:
            continue
        visited.add(module)

        if module.startswith(FORBIDDEN_PREFIXES):
            violations.append(module)
            continue

        module_file = _module_path_for(module)
        if module_file is None:
            continue
        for imp in _extract_app_imports(module_file):
            if imp not in visited:
                frontier.add(imp)

    assert not violations, (
        "app/ai/ui_advisor has an import path to forbidden data modules: "
        f"{violations}. This violates Section 6/41's hard architectural boundary."
    )
