"""
Generates tests/fixtures/data/sample_quantities.xlsx -- a small workbook
deliberately covering Ready-Quantity States A-D (Section 22), a Row-Level
Rules warning (Section 30, thin slab), a non-blocking bad-dimension value
(Section 21's own Width='-' example), a fully-empty row (must be ignored),
and a second `sheet_per_floor` sheet with no Floor column, to exercise
Floor Resolution Case 2 (Section 20).

Run standalone: `python tests/fixtures/generate_sample_workbook.py`
Also imported by tests/integration/test_ingestion_pipeline.py so the
fixture is regenerated fresh on every test run rather than committed as an
opaque binary that could silently drift from what the test expects.
"""
from __future__ import annotations

from pathlib import Path

import openpyxl

FIXTURE_PATH = Path(__file__).parent / "data" / "sample_quantities.xlsx"


def generate(path: Path = FIXTURE_PATH) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "GF"
    ws.append(["Floor", "Element Type", "Item Code", "Length", "Width", "Height", "Ready Quantity"])
    ws.append(["Ground Floor", "COLUMN", "C-01", 2.0, 0.3, 2.8, None])      # State B (CALCULATED)
    ws.append(["Ground Floor", "COLUMN", "C-02", None, None, None, 4.2])   # State A (DIRECT)
    ws.append(["Ground Floor", "SLAB", "S-01", 5.0, 4.0, 0.08, None])      # State B + thin-slab warning
    ws.append(["Ground Floor", "BEAM", "B-01", None, "-", None, None])     # State D + bad Width (non-blocking)
    ws.append(["Ground Floor", "COLUMN", "C-03", None, None, None, -1])    # State C (invalid Ready Quantity)
    ws.append([None, None, None, None, None, None, None])                  # fully empty -> ignored

    ws2 = wb.create_sheet("Level 01")
    ws2.append(["Floor", "Element Type", "Item Code", "Length", "Width", "Height", "Ready Quantity"])
    ws2.append(["Level 01", "FOUNDATION", "F-01", 3.0, 3.0, 1.0, None])    # State B, sheet-per-floor, no Floor column

    wb.save(str(path))
    return path


if __name__ == "__main__":
    print("Wrote", generate())
