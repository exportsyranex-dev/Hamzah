"""
Generates tests/fixtures/data/sample_quantities_reference.xlsx -- an
"older revision" counterpart to sample_quantities.xlsx (see
generate_sample_workbook.py), deliberately constructed so comparing the two
by Item Code exercises all three Comparison states (Section 28):

  C-01: identical in both -> MATCHED, OK (within threshold)
  C-02: 3.0 here vs 4.2 in the "new" file -> MATCHED, OVER_THRESHOLD (40% diff)
  C-99: only exists here -> REMOVED_ITEM
  (F-01, S-01 in the "new" file don't exist here -> NEW_ITEM)
"""
from __future__ import annotations

from pathlib import Path

import openpyxl

FIXTURE_PATH = Path(__file__).parent / "data" / "sample_quantities_reference.xlsx"


def generate(path: Path = FIXTURE_PATH) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "GF"
    ws.append(["Floor", "Element Type", "Item Code", "Length", "Width", "Height", "Ready Quantity"])
    ws.append(["Ground Floor", "COLUMN", "C-01", 2.0, 0.3, 2.8, None])    # matches "new" exactly
    ws.append(["Ground Floor", "COLUMN", "C-02", None, None, None, 3.0])  # differs from "new" (4.2) by 40%
    ws.append(["Ground Floor", "COLUMN", "C-99", None, None, None, 1.0])  # absent from "new" -> REMOVED_ITEM
    wb.save(str(path))
    return path


if __name__ == "__main__":
    print("Wrote", generate())
