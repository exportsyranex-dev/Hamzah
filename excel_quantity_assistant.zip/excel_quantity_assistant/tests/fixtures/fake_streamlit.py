"""
A minimal fake `streamlit` module for driving the REAL app/ui/streamlit_app.py
script logic in tests, without a browser and without the real `streamlit`
package (unavailable in this offline sandbox -- see README "How to run").

This is explicitly NOT a claim of having tested the real Streamlit runtime,
reruns, or browser rendering. It only proves that main()'s Python-level
control flow -- which widget appears when, which controller function gets
called with which arguments, session_state transitions across simulated
reruns -- is free of exceptions and behaves as intended, using the REAL
app.ui.controller and REAL pipeline underneath (nothing about the business
logic is faked, only st.* widget calls).

Usage: a test pre-loads `WIDGET_VALUES` (keyed by each widget's `key`
argument) and `BUTTON_CLICKS` (keyed by button label or key) before calling
`app.ui.streamlit_app.main()`, then inspects `LOG` (a list of
(call_name, args) tuples) and the fake `session_state` dict afterward.
"""
from __future__ import annotations

from contextlib import contextmanager


class RerunException(Exception):
    """Raised by the fake st.rerun() -- mirrors real Streamlit stopping
    script execution and restarting from the top on the next run."""


class _SessionState(dict):
    def __getattr__(self, name):
        try:
            return self[name]
        except KeyError as exc:
            raise AttributeError(name) from exc

    def __setattr__(self, name, value):
        self[name] = value


session_state = _SessionState()

LOG: list[tuple[str, tuple, dict]] = []
WIDGET_VALUES: dict[str, object] = {}
BUTTON_CLICKS: set[str] = set()


def reset_fake_streamlit() -> None:
    """Call between independent test scenarios to avoid leaking state."""
    session_state.clear()
    LOG.clear()
    WIDGET_VALUES.clear()
    BUTTON_CLICKS.clear()


def _log(name, *args, **kwargs):
    LOG.append((name, args, kwargs))


def set_page_config(**kwargs):
    _log("set_page_config", **kwargs)


def markdown(*args, **kwargs):
    _log("markdown", *args, **kwargs)


def caption(*args, **kwargs):
    _log("caption", *args, **kwargs)


def divider(*args, **kwargs):
    _log("divider", *args, **kwargs)


def subheader(*args, **kwargs):
    _log("subheader", *args, **kwargs)


def success(*args, **kwargs):
    _log("success", *args, **kwargs)


def error(*args, **kwargs):
    _log("error", *args, **kwargs)


def warning(*args, **kwargs):
    _log("warning", *args, **kwargs)


def info(*args, **kwargs):
    _log("info", *args, **kwargs)


def write(*args, **kwargs):
    _log("write", *args, **kwargs)


def json(*args, **kwargs):
    _log("json", *args, **kwargs)


def code(*args, **kwargs):
    _log("code", *args, **kwargs)


def rerun():
    _log("rerun")
    raise RerunException()


class _FakeColumn:
    def metric(self, *args, **kwargs):
        _log("metric", *args, **kwargs)

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return False


def columns(n, *args, **kwargs):
    return tuple(_FakeColumn() for _ in range(n))


def metric(*args, **kwargs):
    _log("metric", *args, **kwargs)


@contextmanager
def expander(label, *args, **kwargs):
    _log("expander_open", label)
    yield _FakeColumn()


@contextmanager
def spinner(*args, **kwargs):
    _log("spinner", *args, **kwargs)
    yield


def file_uploader(label, type=None, key=None, **kwargs):
    value = WIDGET_VALUES.get(key, None)
    _log("file_uploader", label, key=key, returned=value is not None)
    return value


def text_input(label, value="", key=None, **kwargs):
    result = WIDGET_VALUES.get(key, value)
    _log("text_input", label, key=key, returned=result)
    return result


def number_input(label, min_value=None, value=0.0, step=None, key=None, **kwargs):
    result = WIDGET_VALUES.get(key, value)
    _log("number_input", label, key=key, returned=result)
    return result


def checkbox(label, value=False, key=None, **kwargs):
    result = WIDGET_VALUES.get(key, value)
    _log("checkbox", label, key=key, returned=result)
    return result


def selectbox(label, options, index=0, key=None, **kwargs):
    result = WIDGET_VALUES.get(key, options[index] if options else None)
    _log("selectbox", label, key=key, returned=result)
    return result


def button(label, key=None, **kwargs):
    clicked = (key in BUTTON_CLICKS) or (label in BUTTON_CLICKS)
    _log("button", label, key=key, clicked=clicked)
    return clicked


def download_button(label, data=None, file_name=None, mime=None, **kwargs):
    _log("download_button", label, file_name=file_name, data_len=len(data) if data else 0)
    return False
